<?xml version="1.0" encoding="ISO-8859-1"?>
<!--Edificios de la D.G. del Catastro.-->
<gml:FeatureCollection gml:id="ES.SDGC.BU"  xmlns:ad="urn:x-inspire:specification:gmlas:Addresses:3.0" xmlns:base="urn:x-inspire:specification:gmlas:BaseTypes:3.2" xmlns:bu-base="http://inspire.jrc.ec.europa.eu/schemas/bu-base/3.0" xmlns:bu-core2d="http://inspire.jrc.ec.europa.eu/schemas/bu-core2d/2.0" xmlns:bu-ext2d="http://inspire.jrc.ec.europa.eu/schemas/bu-ext2d/2.0" xmlns:cp="urn:x-inspire:specification:gmlas:CadastralParcels:3.0" xmlns:el-bas="http://inspire.jrc.ec.europa.eu/schemas/el-bas/2.0" xmlns:el-cov="http://inspire.jrc.ec.europa.eu/schemas/el-cov/2.0" xmlns:el-tin="http://inspire.jrc.ec.europa.eu/schemas/el-tin/2.0" xmlns:el-vec="http://inspire.jrc.ec.europa.eu/schemas/el-vec/2.0" xmlns:gco="http://www.isotc211.org/2005/gco" xmlns:gmd="http://www.isotc211.org/2005/gmd" xmlns:gml="http://www.opengis.net/gml/3.2" xmlns:gmlcov="http://www.opengis.net/gmlcov/1.0" xmlns:gn="urn:x-inspire:specification:gmlas:GeographicalNames:3.0" xmlns:gsr="http://www.isotc211.org/2005/gsr" xmlns:gss="http://www.isotc211.org/2005/gss" xmlns:gts="http://www.isotc211.org/2005/gts" xmlns:swe="http://www.opengis.net/swe/2.0" xmlns:xlink="http://www.w3.org/1999/xlink"  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://inspire.jrc.ec.europa.eu/schemas/bu-ext2d/2.0 http://inspire.ec.europa.eu/draft-schemas/bu-ext2d/2.0/BuildingExtended2D.xsd">
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6063503UF1366S">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315936.77 4036153.7</gml:lowerCorner>
         <gml:upperCorner>315984.38 4036235.89</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2018-06-04T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1960-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1960-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6063503&rc2=UF1366S]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6063503UF1366S</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6063503UF1366S</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6063503UF1366S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6063503UF1366S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6063503UF1366S" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5">315936.91 4036229.28 315936.77 4036230.9 315938.95 4036230.9 315938.95 4036229.4 315936.91 4036229.28</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="36">315949.41 4036195.11 315949.15 4036197.6 315950.44 4036199.74 315952.43 4036199.94 315954.42 4036200.15 315956.11 4036198.31 315966.33 4036199.36 315965.28 4036209.56 315966.39 4036210.93 315969.13 4036211.21 315971.86 4036211.49 315973.24 4036210.38 315974.54 4036197.7 315975.66 4036197.81 315975.99 4036197.85 315976.65 4036191.48 315977.25 4036191.54 315977.82 4036185.97 315977.22 4036185.91 315977.43 4036183.92 315977.89 4036179.44 315978.35 4036174.97 315972.38 4036174.35 315971.92 4036178.83 315956.5 4036177.24 315956.6 4036176.25 315950.14 4036175.58 315949.88 4036178.07 315949.37 4036183.04 315949.04 4036183.01 315948.38 4036182.94 315947.83 4036188.21 315947.8 4036188.51 315948.8 4036188.61 315948.14 4036194.98 315949.41 4036195.11</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5">315963.01 4036234.78 315967.23 4036235.89 315967.97 4036233.09 315963.8 4036231.99 315963.01 4036234.78</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="8">315964.73 4036229.16 315971.51 4036229.89 315972.4 4036221.65 315971.61 4036219.78 315965.98 4036219.15 315965.04 4036220.19 315964.21 4036227.91 315964.73 4036229.16</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5">315981.89 4036153.7 315981.05 4036161.15 315983.54 4036161.43 315984.38 4036153.98 315981.89 4036153.7</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6063503UF1366S</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">1345</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6063504UF1366S">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315979.95 4036187.62</gml:lowerCorner>
         <gml:upperCorner>316011.03 4036250.09</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1968-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1998-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6063504&rc2=UF1366S]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6063504UF1366S</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6063504UF1366S</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6063504UF1366S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6063504UF1366S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6063504UF1366S" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="30">315994.54 4036201.19 315997.97 4036201.34 315998.72 4036202.41 316002.36 4036202.52 316003.22 4036201.57 316006.45 4036201.72 316010.4 4036201.9 316010.46 4036200.7 316010.71 4036195.74 316010.82 4036193.63 316010.91 4036191.8 316011.03 4036188.86 316005.3 4036188.58 316005.22 4036190.23 315997.76 4036189.82 315997.85 4036187.94 315991.38 4036187.62 315991.17 4036190.49 315990.99 4036192.61 315990.86 4036194.18 315985.61 4036193.73 315985.44 4036195.74 315984.47 4036206.98 315980.61 4036207.02 315979.95 4036216.7 315985.38 4036216.97 315990.89 4036216.97 315991.12 4036208.42 315991.59 4036201.06 315994.54 4036201.19</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9">315986.34 4036242.34 315985.87 4036242.66 315990.58 4036250.09 315997.55 4036245.61 315992.6 4036238.11 315991.01 4036239.18 315989.39 4036236.6 315984.79 4036239.5 315986.34 4036242.34</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6063504UF1366S</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">818</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6064403UF1366S">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315940.02 4036338.64</gml:lowerCorner>
         <gml:upperCorner>315968.23 4036358.39</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-23T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1968-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>2007-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6064403&rc2=UF1366S]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6064403UF1366S</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6064403UF1366S</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6064403UF1366S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6064403UF1366S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6064403UF1366S" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="20">315949.18 4036355.93 315954.81 4036355.93 315954.8 4036358.32 315966.48 4036358.39 315966.52 4036347.8 315968.23 4036347.77 315968.2 4036342.28 315966.01 4036342.3 315966.01 4036338.72 315956.9 4036338.64 315956.85 4036342.57 315957.28 4036342.65 315957.23 4036347.71 315954.85 4036347.77 315951.85 4036347.91 315951.73 4036344.04 315940.1 4036344.39 315940.02 4036352.25 315940.63 4036352.5 315949.18 4036355.93</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6064403UF1366S</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">458</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6064404UF1366S">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315973.26 4036271</gml:lowerCorner>
         <gml:upperCorner>316000.8 4036297.11</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-07-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1978-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1978-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6064404&rc2=UF1366S]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6064404UF1366S</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6064404UF1366S</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6064404UF1366S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6064404UF1366S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6064404UF1366S" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="14">315975.15 4036289.09 315976.35 4036297.11 315981.67 4036296.32 315991.84 4036294.8 315990.17 4036281.99 315994.72 4036281.48 316000.8 4036280.79 315999.73 4036271 315993.61 4036271.65 315993.84 4036273.7 315989.17 4036274.31 315978.98 4036275.64 315973.26 4036276.38 315975.15 4036289.09</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6064404UF1366S</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">749</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6066404UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315939.63 4036425.59</gml:lowerCorner>
         <gml:upperCorner>315971.99 4036465.72</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1969-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>2001-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6066404&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6066404UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6066404UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6066404UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6066404UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6066404UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9">315940.27 4036428.89 315939.71 4036430.17 315946.13 4036432.97 315948.15 4036432.32 315949.47 4036429.3 315942.31 4036426.18 315940.94 4036425.59 315939.63 4036428.61 315940.27 4036428.89</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="37">315951.15 4036460.05 315949.98 4036460.8 315951.69 4036463.27 315953.63 4036462.02 315953.87 4036461.86 315956.24 4036465.49 315956.91 4036465.05 315957.35 4036465.72 315962.2 4036462.54 315962.15 4036462.46 315961.76 4036461.87 315964.27 4036460.23 315968.96 4036457.16 315967.86 4036455.49 315970.71 4036453.62 315968.02 4036449.52 315971.99 4036446.98 315966.87 4036438.98 315959.54 4036443.67 315962.27 4036447.67 315960.6 4036448.77 315961.03 4036449.44 315957.69 4036451.63 315957.25 4036450.96 315952.23 4036454.25 315952.44 4036454.57 315952.3 4036454.66 315948.9 4036456.84 315948.75 4036453.25 315945.21 4036453.47 315945.32 4036455.2 315942.71 4036455.36 315942.93 4036458.9 315942.95 4036459.15 315950.29 4036458.68 315951.03 4036459.87 315951.15 4036460.05</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6066404UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">468</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6066405UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315945.56 4036386.65</gml:lowerCorner>
         <gml:upperCorner>315985.46 4036417.99</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1968-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1968-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6066405&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6066405UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6066405UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6066405UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6066405UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6066405UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="15">315949.9 4036406.31 315945.56 4036416.01 315952.62 4036417.76 315953.58 4036413.71 315957.61 4036414.72 315957.88 4036413.48 315976.2 4036417.99 315979.65 4036404.6 315972.93 4036403.02 315972.16 4036405.73 315965.78 4036404.21 315966.47 4036401.33 315959.56 4036399.6 315957.67 4036408.23 315949.9 4036406.31</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">315981.04 4036391.42 315984.56 4036392.26 315985.46 4036388.57 315980.91 4036387.45 315977.65 4036386.65 315976.74 4036390.39 315981.04 4036391.42</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">315981.57 4036406.51 315985.02 4036407.28 315985.46 4036404.99 315981.55 4036404.1 315981.49 4036404.36 315981.09 4036406.41 315981.57 4036406.51</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6066405UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">347</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6068602UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315994.42 4036662.63</gml:lowerCorner>
         <gml:upperCorner>316006.92 4036677.12</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-06-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1986-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1986-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6068602&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6068602UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6068602UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6068602UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6068602UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6068602UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5">315994.42 4036674.18 316002.93 4036677.12 316006.92 4036665.57 315998.41 4036662.63 315994.42 4036674.18</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6068602UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">220</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6068603UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315987.2 4036668.54</gml:lowerCorner>
         <gml:upperCorner>315995 4036674.59</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-06-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1936-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1936-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6068603&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6068603UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6068603UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6068603UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6068603UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6068603UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="6">315987.33 4036671.71 315987.2 4036672.05 315993.85 4036674.59 315995 4036671.02 315988.47 4036668.54 315987.33 4036671.71</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6068603UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">52</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6068604UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315982.79 4036658.46</gml:lowerCorner>
         <gml:upperCorner>315990.05 4036671.75</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-06-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1977-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1977-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6068604&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6068604UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6068604UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6068604UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6068604UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6068604UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">315988.33 4036668.95 315988.47 4036668.54 315989.35 4036665.92 315989.74 4036664.72 315988.36 4036664.22 315990.05 4036659.6 315989.91 4036659.55 315986.92 4036658.46 315986.8 4036658.82 315982.79 4036670.15 315987.32 4036671.75 315987.33 4036671.71 315988.33 4036668.95</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6068604UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">112</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6068606UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315957.75 4036654.21</gml:lowerCorner>
         <gml:upperCorner>315972.02 4036665.29</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1960-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1960-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6068606&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6068606UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6068606UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6068606UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6068606UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6068606UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5">315972.02 4036658.6 315960.29 4036654.21 315957.75 4036661.02 315969.44 4036665.29 315972.02 4036658.6</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>3_industrial</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>0</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6068606UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">84</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6068608UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315973.67 4036627.09</gml:lowerCorner>
         <gml:upperCorner>315988.61 4036640</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-06-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1950-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1950-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6068608&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6068608UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6068608UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6068608UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6068608UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6068608UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="18">315977.25 4036638 315977.64 4036638.1 315984 4036639.56 315985.95 4036640 315988.61 4036630.37 315977.02 4036627.18 315976.68 4036627.09 315976.55 4036627.56 315975.98 4036629.45 315976.41 4036629.56 315978 4036630.02 315977.35 4036632.81 315975.55 4036632.39 315975.12 4036632.32 315974.87 4036633.17 315973.67 4036637.13 315974.02 4036637.22 315977.25 4036638</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6068608UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">174</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6068609UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315976.2 4036638.29</gml:lowerCorner>
         <gml:upperCorner>315985.95 4036648.56</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-06-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1986-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1986-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6068609&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6068609UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6068609UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6068609UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6068609UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6068609UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">315985.95 4036640 315984 4036639.56 315978.48 4036638.29 315976.2 4036646.88 315983.2 4036648.56 315983.52 4036647.59 315985.95 4036640</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>3_industrial</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>0</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6068609UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">66</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6068614UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315988.36 4036659.6</gml:lowerCorner>
         <gml:upperCorner>315996.27 4036671.02</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-06-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1936-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1936-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6068614&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6068614UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6068614UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6068614UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6068614UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6068614UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="10">315989.74 4036664.72 315988.47 4036668.54 315995 4036671.02 315996.27 4036667.09 315991.19 4036665.17 315991.28 4036664.94 315992.93 4036660.62 315990.05 4036659.6 315988.36 4036664.22 315989.74 4036664.72</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6068614UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">72</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6068615UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315968.14 4036646.88</gml:lowerCorner>
         <gml:upperCorner>315983.2 4036671.28</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-06-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1986-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1986-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6068615&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6068615UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6068615UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6068615UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6068615UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6068615UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="15">315974.81 4036670.99 315975.35 4036671.28 315983.2 4036648.56 315982.38 4036648.37 315976.2 4036646.88 315974.46 4036651.35 315972.02 4036658.6 315969.44 4036665.29 315968.42 4036668.26 315968.3 4036668.59 315968.29 4036668.62 315968.25 4036668.72 315968.22 4036668.82 315968.14 4036669.07 315974.81 4036670.99</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>3_industrial</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>0</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6068615UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">175</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6068616UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315967.46 4036625.76</gml:lowerCorner>
         <gml:upperCorner>315974.62 4036637.13</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-06-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1940-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1940-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6068616&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6068616UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6068616UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6068616UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6068616UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6068616UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5">315968.49 4036632.3 315967.46 4036635.59 315973.67 4036637.13 315974.62 4036633.99 315968.49 4036632.3</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5">315973.45 4036626.63 315970.54 4036625.76 315968.77 4036631.41 315971.76 4036632.23 315973.45 4036626.63</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>3_industrial</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>0</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6068616UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">20</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6165501UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316068.45 4036356.49</gml:lowerCorner>
         <gml:upperCorner>316109.72 4036405.66</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1980-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1980-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6165501&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6165501UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6165501UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6165501UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6165501UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6165501UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="61">316103.86 4036398.02 316105.65 4036394.88 316108.09 4036390.61 316107.6 4036390.33 316108.31 4036389.07 316109.72 4036386.6 316106.25 4036384.62 316106.33 4036384.47 316106.45 4036384.25 316104.9 4036383.41 316102.33 4036382.02 316102.69 4036381.33 316100.31 4036380.09 316099.06 4036379.43 316098.72 4036380.07 316095.07 4036378.02 316094.97 4036378.18 316091 4036375.92 316090.74 4036375.77 316090.36 4036376.52 316086.9 4036374.57 316087.38 4036373.84 316087.35 4036373.82 316086.16 4036373.16 316083.51 4036371.67 316083.23 4036371.51 316083.15 4036371.62 316079.38 4036369.51 316077.28 4036373.01 316076.77 4036372.73 316074.4 4036377.04 316073.88 4036376.74 316073.62 4036377.18 316072.19 4036379.75 316072.83 4036380.11 316070.37 4036384.46 316070.53 4036384.55 316070.44 4036384.72 316070.65 4036384.8 316068.45 4036388.74 316072.35 4036390.91 316076.01 4036392.95 316076.16 4036393.04 316076.6 4036392.2 316080.14 4036394.18 316079.66 4036395.04 316079.88 4036395.16 316083.75 4036397.32 316087.69 4036399.52 316088.12 4036398.73 316091.54 4036400.72 316091.02 4036401.62 316094.9 4036403.75 316095.04 4036403.52 316099.06 4036405.66 316100.98 4036402.08 316101.18 4036402.16 316101.42 4036402.29 316103.01 4036399.5 316103.45 4036398.73 316103.86 4036398.02</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                <gml:interior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="26">316081.96 4036381.69 316082.69 4036382.11 316083.24 4036381.15 316086.16 4036382.79 316086.65 4036383.07 316086.16 4036383.94 316085.97 4036384.28 316086.16 4036384.39 316093.95 4036388.79 316094.56 4036387.71 316097.83 4036389.54 316097.45 4036390.22 316098.32 4036390.72 316098.12 4036391.07 316096.56 4036393.83 316095.75 4036393.37 316095.14 4036394.44 316091.87 4036392.55 316092.49 4036391.48 316086.16 4036387.84 316084.51 4036386.89 316083.86 4036388.06 316080.63 4036386.17 316081.24 4036385.13 316080.29 4036384.58 316081.96 4036381.69</gml:posList>
                    </gml:LinearRing>
                </gml:interior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="14">316091.47 4036356.49 316091.4 4036356.61 316087.03 4036364.31 316087.15 4036364.38 316087.02 4036364.6 316087.33 4036364.77 316091.2 4036366.95 316094.92 4036369.05 316098.73 4036371.2 316098.82 4036371.03 316099.19 4036371.24 316103.54 4036363.57 316103.62 4036363.45 316091.47 4036356.49</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>18</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>18</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6165501UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">1993</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6165502UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316092.07 4036410.03</gml:lowerCorner>
         <gml:upperCorner>316101.71 4036418.27</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1980-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1980-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6165502&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6165502UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6165502UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6165502UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6165502UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6165502UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">316094.03 4036410.03 316093.96 4036410.28 316092.07 4036415.13 316100.07 4036418.27 316101.65 4036414.64 316101.71 4036414.45 316094.03 4036410.03</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>0</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6165502UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">41</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6165801UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315978.64 4036363.48</gml:lowerCorner>
         <gml:upperCorner>316003.87 4036380.56</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1968-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1968-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6165801&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6165801UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6165801UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6165801UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6165801UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6165801UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5">315978.64 4036370.51 315982.65 4036372.33 315983.74 4036370.15 315979.59 4036368.55 315978.64 4036370.51</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="22">315993.57 4036376.31 315994.13 4036376.56 315994.23 4036376.34 315998.05 4036377.88 315997.51 4036379.2 316000.93 4036380.56 316001.4 4036379.41 316003.87 4036373.44 316000.87 4036372.36 316002.37 4036368.9 315997.89 4036366.87 315997.56 4036367.68 315997.1 4036367.47 315992.58 4036365.41 315990.14 4036364.3 315989.87 4036364.75 315987.09 4036363.48 315985.35 4036367.42 315983.49 4036371.64 315986.5 4036372.87 315986.4 4036373.06 315993.57 4036376.31</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6165801UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">241</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6165802UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316014.64 4036271.95</gml:lowerCorner>
         <gml:upperCorner>316056.84 4036330.89</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2013-10-08T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1968-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1968-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6165802&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6165802UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6165802UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6165802UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6165802UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6165802UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="10">316022.77 4036283.61 316026.69 4036275 316025.76 4036274.56 316020.21 4036271.95 316018.6 4036275.68 316018.86 4036275.77 316014.64 4036284.74 316023.34 4036288.87 316025.18 4036284.74 316022.77 4036283.61</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="20">316030.42 4036310.57 316041.58 4036313.89 316040.44 4036317.26 316046.72 4036319.12 316048 4036319.5 316051.5 4036307.85 316052.31 4036308.07 316053.39 4036304.46 316054.64 4036304.86 316056.84 4036297.64 316047.39 4036294.71 316046.08 4036298.88 316039.79 4036296.89 316039.27 4036298.81 316034.07 4036297.26 316031.22 4036307.17 316023.64 4036304.94 316021.87 4036311.57 316029.57 4036313.78 316030.42 4036310.57</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5">316035.56 4036324.45 316034.21 4036329.25 316039.65 4036330.89 316041.08 4036325.95 316035.56 4036324.45</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6165802UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">628</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6165804UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316075.27 4036252.57</gml:lowerCorner>
         <gml:upperCorner>316102.88 4036307.54</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-10-30T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1990-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6165804&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6165804UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6165804UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6165804UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6165804UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6165804UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5">316080.48 4036252.57 316075.27 4036252.79 316075.47 4036257.8 316080.66 4036257.42 316080.48 4036252.57</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="19">316094.03 4036291.16 316094.36 4036291.36 316095.32 4036289.16 316097.97 4036290.3 316100.89 4036284.23 316097.44 4036282.59 316099.82 4036277.77 316100.42 4036278.03 316102.88 4036272.76 316094.19 4036268.56 316092.04 4036273.81 316092.63 4036274.02 316089.89 4036279.43 316089.09 4036279.02 316089.24 4036278.71 316083.23 4036275.8 316077.67 4036287.12 316092.42 4036294.4 316094.03 4036291.16</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="12">316087.32 4036302.89 316087.86 4036302.89 316087 4036304.56 316091.03 4036306.63 316092.81 4036307.54 316094.64 4036303.99 316092.86 4036303.07 316095.2 4036298.53 316090.69 4036296.08 316087.88 4036294.83 316084.51 4036301.5 316087.32 4036302.89</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6165804UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">698</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6166302UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315961.29 4036495.45</gml:lowerCorner>
         <gml:upperCorner>316004.51 4036533.62</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1968-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1968-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6166302&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6166302UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6166302UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6166302UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6166302UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6166302UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="25">315962.64 4036524.36 315964.12 4036528.77 315964.92 4036528.49 315966.74 4036533.62 315970.09 4036532.68 315968.28 4036527.29 315972.89 4036525.65 315975.61 4036532.87 315978.92 4036531.62 315976.01 4036523.91 315975.74 4036524.01 315974.57 4036520.22 315973.29 4036516.07 315973.04 4036516.17 315969.84 4036517.31 315969.88 4036517.28 315969.46 4036515.99 315969.38 4036515.74 315964.26 4036517.55 315964.35 4036517.81 315964.78 4036519.09 315964.81 4036519.09 315961.65 4036520.21 315961.29 4036520.33 315962.64 4036524.36</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="6">316000.43 4036495.45 315998.68 4036499.31 316002.55 4036501.12 316002.69 4036501.19 316004.51 4036497.33 316000.43 4036495.45</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6166302UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">201</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6166305UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316014.55 4036406.75</gml:lowerCorner>
         <gml:upperCorner>316042.32 4036428.3</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-06-01T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1968-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>2001-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6166305&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6166305UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6166305UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6166305UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6166305UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6166305UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="19">316035.61 4036411.14 316032.61 4036409.93 316032 4036411.37 316026 4036408.75 316021.42 4036406.75 316020.62 4036408.73 316018.86 4036413.07 316021.23 4036414.05 316019.49 4036418.3 316016.87 4036417.23 316014.55 4036422.9 316017.42 4036424.05 316017.3 4036424.34 316026.26 4036428.3 316026.58 4036427.76 316036.54 4036427.38 316042.32 4036413.86 316035.69 4036411.18 316035.61 4036411.14</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                <gml:interior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5">316030.7 4036422.81 316028.85 4036422.13 316029.49 4036420.41 316031.33 4036421.09 316030.7 4036422.81</gml:posList>
                    </gml:LinearRing>
                </gml:interior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6166305UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">403</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6167901UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315949.25 4036565.52</gml:lowerCorner>
         <gml:upperCorner>315976.61 4036581.14</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1983-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1983-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6167901&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6167901UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6167901UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6167901UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6167901UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6167901UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="23">315970.42 4036573.3 315970.55 4036568.91 315967.82 4036568.82 315967.82 4036567.84 315967.75 4036565.8 315955.56 4036565.52 315955.53 4036568.54 315953.04 4036568.53 315952.94 4036576.38 315949.25 4036576.3 315949.37 4036581.14 315960.79 4036580.49 315960.84 4036576.58 315967.18 4036576.74 315967.27 4036580.1 315971.85 4036580.12 315971.82 4036580.45 315975.2 4036580.42 315976.61 4036576.97 315970.76 4036576.83 315970.73 4036574.14 315970.4 4036574.02 315970.42 4036573.3</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6167901UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">281</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6167902UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315974.66 4036540.39</gml:lowerCorner>
         <gml:upperCorner>316013.25 4036594.77</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2021-12-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1968-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>2016-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6167902&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6167902UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6167902UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6167902UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6167902UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6167902UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="30">315981.98 4036562.76 315982.54 4036563.02 315981.33 4036565.61 315986.41 4036568.18 315988.16 4036564.21 315986.34 4036563.37 315988.26 4036559.06 315988.79 4036559.3 315992.77 4036550.55 315992.19 4036550.3 315993.69 4036547.23 315989.1 4036544.92 315987.39 4036548.32 315984.23 4036546.9 315986.39 4036542.6 315986.28 4036542.55 315986.23 4036542.53 315981.99 4036540.39 315980.92 4036542.56 315980.5 4036542.36 315976.02 4036552.39 315974.78 4036555.34 315974.66 4036555.6 315978.73 4036557.75 315977.92 4036559.51 315978.85 4036559.92 315978.54 4036560.65 315979.75 4036561.16 315979.54 4036561.62 315981.98 4036562.76</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">315978.32 4036572.46 315976.92 4036576.05 315983.72 4036578.97 315984.72 4036576.63 315982.42 4036575.44 315982.92 4036574.45 315978.32 4036572.46</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="28">316010.17 4036579.55 316012.19 4036575.61 316013.25 4036573.45 316008.87 4036571.3 316008.74 4036571.56 316003.91 4036569.2 316003.29 4036570.46 316002.8 4036570.22 315999.97 4036576.01 315999.22 4036575.66 315999.1 4036575.88 315998.1 4036578.08 315996.02 4036577.08 315994.29 4036580.58 315997.06 4036581.88 315995.73 4036585 315998.67 4036586.25 315997.74 4036588 316000.32 4036589.19 315999.81 4036590.47 316001.44 4036591.26 316000.91 4036592.54 316002.95 4036594.77 316005.57 4036589.3 316008.07 4036584.3 316007.9 4036584.27 316009.62 4036580.62 316010.17 4036579.55</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>4_2_retail</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>0</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6167902UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">786</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6167904UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316021.85 4036566.87</gml:lowerCorner>
         <gml:upperCorner>316049.46 4036592.38</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1973-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>2001-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6167904&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6167904UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6167904UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6167904UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6167904UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6167904UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="27">316025.61 4036579.07 316033.01 4036579.68 316032.6 4036585.87 316032.52 4036586.6 316037.44 4036586.92 316037.13 4036587.7 316036.19 4036589.98 316042.17 4036592.38 316044.34 4036588.01 316043.4 4036588.03 316043.43 4036587.7 316043.53 4036586.27 316043.74 4036583.27 316044.29 4036583.33 316044.61 4036578.45 316044.68 4036577.35 316044.27 4036577.36 316044.54 4036573.22 316049.05 4036573.52 316049.31 4036572.28 316049.46 4036569.23 316044.9 4036568.83 316042.51 4036568.62 316027.57 4036567.3 316022.73 4036566.87 316021.85 4036578.76 316025.61 4036579.07</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6167904UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">643</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6167905UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316079.97 4036454.66</gml:lowerCorner>
         <gml:upperCorner>316106.45 4036474.97</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-06-01T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1979-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1998-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6167905&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6167905UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6167905UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6167905UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6167905UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6167905UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5">316079.97 4036458.56 316083.17 4036460.09 316085.03 4036456.19 316081.83 4036454.66 316079.97 4036458.56</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="19">316091.04 4036471.29 316092.76 4036472.13 316097.32 4036474.35 316097.65 4036473.66 316100.35 4036474.97 316106.45 4036462.52 316101.8 4036460.29 316099.7 4036464.64 316097.24 4036463.45 316095.31 4036462.51 316095.53 4036462.06 316086.83 4036457.84 316085.23 4036461.13 316085 4036461.6 316083.86 4036463.96 316083.63 4036464.43 316082.02 4036467.73 316090.72 4036471.96 316091.04 4036471.29</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6167905UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">242</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6263501UF1366S">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316162.84 4036172.03</gml:lowerCorner>
         <gml:upperCorner>316199.21 4036214.2</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1983-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1983-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6263501&rc2=UF1366S]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6263501UF1366S</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6263501UF1366S</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6263501UF1366S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6263501UF1366S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6263501UF1366S" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="38">316177.01 4036174.85 316174.13 4036179.67 316175.53 4036180.41 316175.27 4036180.81 316176.4 4036181.3 316174.8 4036183.99 316174.06 4036183.58 316171.57 4036188.1 316172.11 4036188.41 316170.03 4036192.08 316169.46 4036191.73 316167.16 4036195.74 316162.84 4036203.27 316165.41 4036204.72 316165.23 4036205.07 316170.8 4036208.24 316171.2 4036207.44 316173.98 4036209.09 316173.54 4036209.86 316179.04 4036212.89 316179.21 4036212.61 316181.82 4036214.2 316183.89 4036210.31 316184.29 4036210.54 316188.55 4036203.07 316188.08 4036202.86 316190.43 4036198.86 316190.74 4036199.09 316192.4 4036195.74 316192.84 4036194.86 316192.29 4036194.58 316194.12 4036191.45 316194.99 4036191.91 316197.38 4036187.69 316197.09 4036187.54 316199.21 4036183.7 316178.71 4036172.03 316177.01 4036174.85</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                <gml:interior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="23">316181.51 4036195.74 316180.05 4036198.3 316180.35 4036198.43 316177.94 4036202.79 316174.61 4036200.9 316176.98 4036196.57 316177.36 4036196.75 316177.95 4036195.74 316181.97 4036188.82 316181.58 4036188.44 316181.81 4036188.09 316181.36 4036187.84 316182.98 4036185.11 316183.33 4036185.31 316183.56 4036184.98 316187.14 4036186.96 316186.89 4036187.39 316187.4 4036187.69 316185.83 4036190.42 316185.31 4036190.19 316185.11 4036190.5 316184.63 4036190.29 316181.51 4036195.74</gml:posList>
                    </gml:LinearRing>
                </gml:interior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>15</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>15</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6263501UF1366S</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">1698</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6264401UF1366S">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316127.16 4036246.11</gml:lowerCorner>
         <gml:upperCorner>316176.19 4036290.61</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1980-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1980-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6264401&rc2=UF1366S]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6264401UF1366S</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6264401UF1366S</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6264401UF1366S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6264401UF1366S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6264401UF1366S" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="60">316170.16 4036278.74 316171.75 4036276.1 316174.2 4036271.58 316173.87 4036271.4 316176.19 4036267.5 316172.29 4036265.17 316172.21 4036265.36 316168.46 4036263.22 316168.32 4036263.14 316167.92 4036263.85 316164.5 4036261.92 316164.93 4036261.2 316164.67 4036261.05 316160.78 4036258.85 316157.02 4036256.72 316153 4036254.44 316149.37 4036252.38 316149.28 4036252.33 316148.85 4036253.06 316145.37 4036251.09 316145.86 4036250.23 316145.4 4036249.97 316141.96 4036248.02 316141.71 4036247.88 316141.63 4036248.29 316137.88 4036246.11 316135.8 4036249.78 316135.52 4036249.58 316132.98 4036254.03 316131.41 4036256.81 316128.92 4036261.22 316129.23 4036261.37 316127.16 4036265.14 316130.89 4036267.13 316130.74 4036267.39 316130.81 4036267.43 316134.53 4036269.6 316134.71 4036269.71 316135.04 4036269.03 316138.76 4036271.14 316138.47 4036271.67 316138.66 4036271.78 316142.33 4036273.87 316139.57 4036278.53 316147.35 4036282.97 316145.5 4036286.25 316153.03 4036290.61 316155.37 4036286.53 316147.73 4036282.27 316150.01 4036278.18 316154.06 4036280.56 316154.34 4036279.95 316157.66 4036281.88 316157.31 4036282.54 316161.2 4036284.55 316161.1 4036284.76 316165.13 4036287 316167.36 4036282.95 316167.72 4036283.13 316170.16 4036278.74</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                <gml:interior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="25">316160.14 4036269.54 316160.65 4036268.55 316164.35 4036270.66 316163.85 4036271.53 316164.63 4036271.84 316163.02 4036274.81 316162.24 4036274.4 316161.78 4036275.35 316158.11 4036273.26 316158.67 4036272.2 316154.64 4036269.94 316153.11 4036272.8 316145.27 4036268.35 316146.96 4036265.6 316142.98 4036263.32 316142.42 4036264.4 316138.84 4036262.4 316139.33 4036261.36 316138.57 4036261 316140.17 4036258.05 316141.07 4036258.51 316141.51 4036257.66 316145.04 4036259.67 316144.5 4036260.68 316160.14 4036269.54</gml:posList>
                    </gml:LinearRing>
                </gml:interior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>20</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>20</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6264401UF1366S</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">2272</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6264501UF1366S">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316167.93 4036268.92</gml:lowerCorner>
         <gml:upperCorner>316209.72 4036316.06</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1980-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1980-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6264501&rc2=UF1366S]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6264501UF1366S</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6264501UF1366S</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6264501UF1366S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6264501UF1366S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6264501UF1366S" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="33">316179.2 4036268.92 316167.93 4036288.68 316175.47 4036292.92 316174.81 4036294.13 316176.63 4036295.14 316178.98 4036296.44 316179.64 4036295.38 316186.84 4036299.47 316186.21 4036300.64 316190.42 4036303.06 316191.08 4036301.9 316194.52 4036303.95 316198.47 4036306.31 316203.53 4036297.31 316204.75 4036295.14 316205.04 4036294.63 316209.72 4036286.38 316205.77 4036284.06 316202.38 4036282.07 316202.96 4036281.01 316202.73 4036280.88 316198.95 4036278.75 316198.77 4036278.65 316198.25 4036279.71 316194.6 4036277.66 316190.83 4036275.55 316191.44 4036274.44 316191.31 4036274.37 316187.46 4036272.22 316187.25 4036272.1 316186.76 4036273.21 316183 4036271.08 316179.2 4036268.92</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                <gml:interior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">316195.43 4036293.24 316192.48 4036291.51 316192.74 4036291.07 316183.93 4036286.02 316183.7 4036286.52 316180.56 4036284.73 316182.14 4036281.9 316185.23 4036283.62 316184.93 4036284.16 316193.84 4036289.25 316194.17 4036288.7 316197.08 4036290.39 316195.43 4036293.24</gml:posList>
                    </gml:LinearRing>
                </gml:interior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="24">316184.79 4036303.11 316183.63 4036302.45 316182.88 4036303.74 316182.51 4036303.52 316181.28 4036305.57 316181.79 4036305.87 316181.13 4036306.98 316180.72 4036306.73 316179.54 4036308.66 316179.89 4036308.88 316179.23 4036310.22 316189.48 4036316.06 316190.16 4036314.85 316190.57 4036315.08 316191.72 4036313.01 316191.25 4036312.75 316191.55 4036312.21 316191.91 4036311.55 316192.41 4036311.82 316193.51 4036309.77 316193.19 4036309.6 316193.87 4036308.34 316192.56 4036307.58 316184.79 4036303.11</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>20</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>20</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6264501UF1366S</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">1494</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6264601UF1366S">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316144.15 4036214.6</gml:lowerCorner>
         <gml:upperCorner>316190 4036254.44</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2005-09-14T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1983-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1983-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6264601&rc2=UF1366S]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6264601UF1366S</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6264601UF1366S</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6264601UF1366S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6264601UF1366S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6264601UF1366S" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="29">316152.21 4036240.65 316155.63 4036242.47 316171.18 4036251.33 316171.77 4036250.39 316179.36 4036254.44 316180.66 4036251.94 316181.1 4036252.17 316184.33 4036246.54 316188.98 4036238.3 316188.56 4036238.06 316190 4036235.52 316182.7 4036231.17 316183.24 4036230.13 316175.46 4036225.76 316175.74 4036225.25 316175.53 4036225.13 316176.02 4036224.27 316173.65 4036222.93 316168.5 4036219.83 316168.1 4036220.64 316164.51 4036218.89 316162.15 4036217.58 316156.8 4036214.6 316151.56 4036223.73 316149.51 4036227.29 316147.24 4036231.24 316144.15 4036236.62 316151.99 4036241.06 316152.21 4036240.65</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                <gml:interior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="20">316161.4 4036233.52 316160.95 4036233.27 316160.37 4036234.28 316157.12 4036232.41 316157.54 4036231.67 316157.29 4036231.52 316159.17 4036228.37 316159.37 4036228.49 316159.77 4036227.81 316162.52 4036229.43 316162.18 4036230 316162.81 4036230.38 316162.74 4036230.57 316164.59 4036231.63 316168.01 4036233.58 316170.94 4036235.25 316178.46 4036239.62 316176.93 4036242.33 316172.58 4036239.85 316161.4 4036233.52</gml:posList>
                    </gml:LinearRing>
                </gml:interior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>17</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>17</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6264601UF1366S</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">2095</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6265201UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316092.86 4036325.16</gml:lowerCorner>
         <gml:upperCorner>316143.19 4036366.2</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1980-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1980-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6265201&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6265201UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6265201UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6265201UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6265201UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6265201UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">316094.34 4036352.6 316092.86 4036355.24 316100.7 4036359.68 316102.94 4036355.65 316098.91 4036353.31 316095.17 4036351.14 316094.34 4036352.6</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="61">316120.8 4036359.52 316120.35 4036360.26 316123.62 4036362.27 316124.09 4036361.47 316124.32 4036361.6 316128.09 4036363.83 316131.97 4036366.2 316134.26 4036362.2 316136.85 4036357.91 316136.9 4036357.82 316137.65 4036358.24 316139.32 4036355.38 316138.62 4036354.97 316141.16 4036350.76 316140.81 4036350.63 316143.19 4036346.61 316139.33 4036344.45 316139.06 4036344.3 316138.91 4036344.46 316135.26 4036342.38 316134.76 4036343.27 316131.25 4036341.27 316131.9 4036340.4 316131.74 4036340.31 316127.86 4036338.14 316127.77 4036338.09 316127.6 4036338.35 316123.93 4036336.15 316120.11 4036333.86 316116.21 4036331.53 316116.14 4036331.49 316115.68 4036332.17 316112.17 4036330.18 316112.75 4036329.35 316112.53 4036329.22 316108.73 4036327.04 316108.43 4036327.39 316104.76 4036325.16 316102.67 4036328.91 316102.37 4036328.73 316099.86 4036333.14 316098.38 4036335.92 316095.82 4036340.27 316096.17 4036340.43 316093.95 4036344.15 316097.88 4036346.36 316097.76 4036346.55 316101.5 4036348.72 316101.64 4036348.8 316102.02 4036348.05 316105.41 4036349.97 316105.01 4036350.73 316105.3 4036350.88 316109.16 4036352.95 316106.32 4036357.72 316110.22 4036359.95 316114.08 4036362.17 316115.83 4036359.17 316116.88 4036357.37 316116.94 4036357.27 316120.8 4036359.52</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                <gml:interior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="25">316107.35 4036337.25 316108.03 4036337.88 316108.59 4036336.89 316111.97 4036338.76 316111.4 4036339.79 316127.09 4036348.6 316127.6 4036347.68 316130.95 4036349.5 316130.37 4036350.57 316131.31 4036351.09 316129.8 4036353.81 316128.85 4036353.28 316128.21 4036354.41 316124.91 4036352.53 316125.6 4036351.32 316121.54 4036349.05 316119.96 4036351.87 316112.25 4036347.53 316113.87 4036344.65 316109.89 4036342.42 316109.28 4036343.51 316105.89 4036341.59 316106.49 4036340.53 316105.74 4036340.11 316107.35 4036337.25</gml:posList>
                    </gml:LinearRing>
                </gml:interior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>22</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>22</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6265201UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">2248</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6265401UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316133.37 4036348.84</gml:lowerCorner>
         <gml:upperCorner>316174.42 4036397.91</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1981-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1981-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6265401&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6265401UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6265401UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6265401UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6265401UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6265401UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="64">316141.56 4036391.82 316141.74 4036391.92 316144.37 4036393.59 316146.17 4036394.54 316148.85 4036395.96 316149 4036395.65 316152.96 4036397.91 316154.94 4036394.54 316155.12 4036394.24 316155.26 4036394 316155.08 4036393.9 316157.15 4036390.34 316157.36 4036389.99 316156.7 4036389.59 316158.55 4036386.5 316159.16 4036386.86 316159.48 4036386.28 316161.48 4036382.71 316161.5 4036382.67 316161.31 4036382.56 316163.51 4036378.75 316165.65 4036375.04 316165.77 4036374.84 316165.96 4036374.94 316168.03 4036371.16 316168.15 4036370.94 316167.53 4036370.56 316169.51 4036367.17 316170.29 4036367.65 316170.35 4036367.54 316172.42 4036363.82 316172.57 4036363.55 316172.36 4036363.44 316174.42 4036359.7 316170.72 4036357.66 316170.9 4036357.28 316170.96 4036357.12 316166.44 4036354.65 316166.81 4036353.87 316164.08 4036352.42 316163.75 4036353.01 316159.28 4036350.51 316159.04 4036350.93 316155.4 4036348.84 316153.31 4036352.42 316152.95 4036352.21 316150.51 4036356.37 316151.46 4036356.9 316149.54 4036360.35 316148.9 4036359.94 316146.52 4036363.83 316141.96 4036361.04 316137.72 4036368.86 316142.27 4036371.39 316142.12 4036371.68 316139.94 4036375.52 316139.06 4036375.02 316137.08 4036378.48 316137.83 4036378.91 316133.37 4036386.67 316133.71 4036386.88 316137.46 4036389.01 316137.24 4036389.36 316141.56 4036391.82</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                <gml:interior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="27">316159.45 4036360.72 316162.29 4036362.31 316161.9 4036363.01 316162.81 4036363.52 316160.93 4036366.89 316159.86 4036366.29 316150.92 4036382.03 316152 4036382.62 316150.14 4036385.9 316149.16 4036385.34 316148.6 4036386.31 316145.75 4036384.64 316146.26 4036383.77 316145.36 4036383.25 316145.11 4036383.17 316147.03 4036379.77 316147.06 4036379.72 316148.33 4036380.45 316150.56 4036376.55 316147.84 4036375 316152.28 4036367.18 316154.94 4036368.75 316157.19 4036364.75 316156.16 4036364.23 316157.95 4036360.73 316159.07 4036361.38 316159.45 4036360.72</gml:posList>
                    </gml:LinearRing>
                </gml:interior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>20</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>20</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6265401UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">2238</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6265501UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316141.58 4036400.17</gml:lowerCorner>
         <gml:upperCorner>316191.52 4036452.22</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1975-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1975-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6265501&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6265501UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6265501UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6265501UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6265501UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6265501UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="37">316150.95 4036436.57 316152.86 4036437.59 316156.13 4036431.91 316157.68 4036432.81 316159.05 4036433.61 316162.47 4036427.8 316161.08 4036426.95 316161.01 4036426.91 316162.52 4036423.96 316162.14 4036423.76 316163.77 4036420.81 316164.32 4036421.11 316165.87 4036421.96 316169.1 4036416.04 316167.64 4036415.16 316166.34 4036414.37 316169.43 4036408.5 316168.16 4036407.76 316167.55 4036407.41 316169.1 4036404.49 316161.4 4036400.17 316158.12 4036405.96 316161.84 4036408.17 316160.24 4036411.11 316163.09 4036412.59 316161.5 4036415.32 316157.58 4036413.28 316154.3 4036419.19 316151.05 4036425.06 316154.63 4036427.12 316152.98 4036430.06 316150.11 4036428.32 316148.38 4036431.24 316144.76 4036429.18 316141.58 4036435 316149.32 4036439.42 316150.95 4036436.57</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="37">316167.53 4036446.06 316165.95 4036448.98 316171.53 4036452.22 316174.98 4036446.29 316172.74 4036445.14 316174.46 4036442.2 316170.82 4036440.26 316172.26 4036437.53 316173.37 4036438.12 316175.25 4036439.11 316178.71 4036432.93 316182.01 4036427.14 316180.1 4036426.09 316179.13 4036425.56 316180.71 4036422.65 316183.74 4036424.43 316185.3 4036421.59 316188.15 4036423.14 316191.52 4036417.25 316185.96 4036414.08 316184.48 4036417.01 316183.13 4036416.26 316181.37 4036415.28 316178.1 4036421.12 316176.75 4036420.33 316174.94 4036419.27 316171.67 4036425.14 316172.71 4036425.75 316174.81 4036426.99 316171.52 4036432.85 316169.35 4036431.65 316168.33 4036431.09 316165.02 4036437.04 316166.91 4036438.09 316167.83 4036438.6 316164.49 4036444.35 316167.53 4036446.06</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>20</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>20</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6265501UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">1876</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6265601UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316143.23 4036314.33</gml:lowerCorner>
         <gml:upperCorner>316192.2 4036355.34</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1980-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1980-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6265601&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6265601UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6265601UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6265601UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6265601UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6265601UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="78">316147.67 4036325.29 316145.23 4036329.63 316145.58 4036329.8 316143.23 4036333.81 316147.21 4036336.07 316147.31 4036335.92 316150.85 4036337.95 316151.08 4036338.08 316151.26 4036337.63 316154.94 4036339.64 316154.6 4036340.22 316154.66 4036340.25 316158.45 4036342.36 316158.52 4036342.2 316162.44 4036344.45 316166.27 4036346.64 316166.2 4036346.76 316170.11 4036348.98 316170.22 4036349.04 316170.63 4036348.26 316170.74 4036348.33 316174.04 4036350.22 316173.51 4036351.16 316173.73 4036351.28 316177.51 4036353.29 316177.66 4036353.37 316177.77 4036353.21 316178.57 4036353.69 316178.26 4036354.18 316180.15 4036355.25 316180.33 4036354.75 316181.46 4036355.34 316183.52 4036351.54 316183.88 4036351.77 316186.34 4036347.37 316185.47 4036346.88 316186.99 4036344.1 316187.91 4036344.66 316190.4 4036340.2 316190.12 4036340.05 316192.2 4036336.33 316191.21 4036335.79 316191.52 4036335.21 316189.54 4036334.18 316189.23 4036334.73 316188.48 4036334.29 316188.66 4036333.99 316188.53 4036333.92 316184.66 4036331.78 316184.6 4036331.75 316184.22 4036332.58 316180.66 4036330.62 316181.16 4036329.8 316180.9 4036329.65 316177.11 4036327.54 316179.55 4036323.37 316179.8 4036322.95 316179.33 4036322.68 316179.56 4036322.26 316177.46 4036321.11 316177.24 4036321.49 316174.57 4036319.94 316174.76 4036319.59 316172.68 4036318.46 316172.51 4036318.76 316172.05 4036318.5 316169.39 4036323.05 316165.53 4036320.84 316161.99 4036318.88 316158.27 4036316.83 316158.42 4036316.59 316154.34 4036314.33 316152.04 4036318.31 316151.73 4036318.15 316149.29 4036322.59 316150.21 4036323.07 316148.66 4036325.87 316147.67 4036325.29</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                <gml:interior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="34">316170.18 4036330.89 316171.6 4036331.72 316171.42 4036332.03 316173.28 4036333.16 316173.51 4036332.78 316173.97 4036333.05 316172.36 4036335.82 316176.28 4036338.1 316176.82 4036337.17 316180.35 4036339.19 316179.84 4036340.08 316180.58 4036340.51 316179.02 4036343.25 316178.27 4036342.82 316177.69 4036343.83 316174.29 4036341.85 316174.9 4036340.8 316159.22 4036331.8 316158.51 4036333.02 316154.88 4036330.8 316155.43 4036329.9 316154.7 4036329.46 316156.43 4036326.59 316157.18 4036327.04 316157.76 4036326.08 316161.29 4036328.18 316160.75 4036329.09 316164.66 4036331.44 316166.34 4036328.64 316166.91 4036328.98 316166.7 4036329.34 316168.53 4036330.45 316168.76 4036330.07 316170.18 4036330.89</gml:posList>
                    </gml:LinearRing>
                </gml:interior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>20</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>20</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6265601UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">2208</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6265801UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316111.8 4036282.47</gml:lowerCorner>
         <gml:upperCorner>316152.72 4036331.49</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-09-17T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1980-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1980-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6265801&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6265801UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6265801UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6265801UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6265801UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6265801UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="60">316119.75 4036325.71 316122.45 4036327.33 316126.86 4036329.79 316127.04 4036329.41 316130.71 4036331.49 316132.8 4036327.75 316133.1 4036327.93 316135.18 4036324.24 316135.37 4036323.9 316136.15 4036324.33 316138.03 4036320.92 316137.22 4036320.46 316137.41 4036320.12 316139.46 4036316.47 316143.62 4036318.84 316144.15 4036319.16 316146.34 4036315.31 316148.56 4036311.39 316143.97 4036308.7 316146.2 4036304.78 316145.61 4036304.43 316147.55 4036301 316148.11 4036301.35 316150.27 4036297.51 316150.43 4036297.62 316151.84 4036295.14 316152.72 4036293.61 316148.64 4036291.35 316148.82 4036291.09 316144.48 4036288.53 316141.75 4036287.01 316137.32 4036284.5 316137.2 4036284.73 316133.19 4036282.47 316131 4036286.5 316131.21 4036286.63 316131.17 4036286.7 316129.18 4036289.99 316128.99 4036290.3 316128.12 4036289.79 316126.12 4036293.36 316126.91 4036293.75 316126.78 4036293.97 316126.12 4036295.14 316124.75 4036297.55 316122.47 4036301.58 316120.29 4036305.43 316118.03 4036309.41 316117.94 4036309.58 316117.17 4036309.13 316115.17 4036312.62 316115.85 4036313.01 316115.75 4036313.18 316113.7 4036316.78 316113.62 4036316.93 316114 4036317.09 316111.8 4036320.78 316115.55 4036322.89 316115.32 4036323.19 316119.75 4036325.71</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                <gml:interior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="27">316138.64 4036295.14 316140.26 4036295.98 316139.89 4036296.69 316140.84 4036297.2 316138.97 4036300.69 316137.8 4036300.06 316135.59 4036304.13 316138.3 4036305.61 316133.98 4036313.51 316131.24 4036311.87 316128.92 4036315.75 316130.09 4036316.45 316128.05 4036319.89 316127.09 4036319.32 316126.54 4036320.25 316123.71 4036318.56 316124.16 4036317.81 316123.23 4036317.27 316125.3 4036313.72 316126.25 4036314.27 316135.21 4036298.63 316134.22 4036298.07 316135.83 4036295.14 316136.18 4036294.51 316137.13 4036295.03 316137.42 4036294.5 316138.64 4036295.14</gml:posList>
                    </gml:LinearRing>
                </gml:interior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>21</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>21</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6265801UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">2129</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6266601UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316101.05 4036387.73</gml:lowerCorner>
         <gml:upperCorner>316150.22 4036428.73</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1975-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1975-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6266601&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6266601UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6266601UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6266601UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6266601UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6266601UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="60">316143.3 4036420.38 316144.93 4036417.61 316145.91 4036418.12 316148.41 4036413.67 316148.14 4036413.52 316150.15 4036409.88 316150.22 4036409.76 316146.56 4036407.73 316146.73 4036407.41 316142.55 4036405.19 316142.2 4036405.88 316138.88 4036404.12 316139.36 4036403.26 316139.27 4036403.21 316139.05 4036403.09 316135.21 4036401.02 316137.84 4036396.43 316130 4036391.93 316127.41 4036396.42 316123.49 4036394.16 316122.93 4036395.09 316119.5 4036393.18 316120.08 4036392.16 316112.25 4036387.73 316110 4036391.7 316109.59 4036391.46 316108.2 4036393.83 316107.52 4036394.99 316106.05 4036394.31 316105.8 4036394.62 316103.53 4036398.59 316104.91 4036399.45 316102.83 4036403 316103.19 4036403.21 316103.44 4036403.35 316103.42 4036403.39 316101.05 4036407.3 316105.1 4036409.55 316108.68 4036411.55 316109 4036411.73 316109.57 4036410.72 316112.96 4036412.61 316112.33 4036413.65 316116.39 4036415.95 316116.58 4036415.6 316124.31 4036420.02 316124.13 4036420.36 316127.85 4036422.46 316128.14 4036422.62 316128.56 4036421.9 316132.11 4036423.83 316131.55 4036424.85 316135.38 4036427.02 316135.62 4036427.16 316135.92 4036426.74 316139.33 4036428.73 316141.45 4036424.98 316141.93 4036425.25 316144.36 4036420.97 316143.3 4036420.38</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                <gml:interior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="26">316114.65 4036400.06 316115.4 4036400.48 316115.98 4036399.44 316117.04 4036400.05 316119.4 4036401.41 316118.66 4036402.63 316122.63 4036405 316124.33 4036402.15 316131.87 4036406.64 316130.28 4036409.31 316134.41 4036411.79 316135.09 4036410.63 316138.41 4036412.48 316137.92 4036413.36 316138.67 4036413.78 316137.04 4036416.71 316136.09 4036416.18 316135.54 4036417.16 316132.37 4036415.34 316133.06 4036414.18 316117.26 4036405.19 316116.54 4036406.4 316113.25 4036404.46 316113.83 4036403.48 316112.94 4036402.96 316114.65 4036400.06</gml:posList>
                    </gml:LinearRing>
                </gml:interior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>18</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>18</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6266601UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">2030</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6266801UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316168.37 4036370.44</gml:lowerCorner>
         <gml:upperCorner>316207.56 4036409.17</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1980-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1980-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6266801&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6266801UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6266801UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6266801UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6266801UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6266801UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="20">316184.12 4036376.21 316178.16 4036372.69 316175.45 4036377.27 316175.86 4036377.51 316175.13 4036378.81 316177.73 4036380.26 316174.51 4036385.72 316171.89 4036384.32 316171.24 4036385.51 316170.97 4036385.36 316168.37 4036390.03 316174.2 4036393.37 316175.85 4036390.52 316178.91 4036392.18 316180.43 4036389.46 316182.1 4036386.47 316183.7 4036383.62 316185.39 4036380.6 316182.53 4036378.97 316184.12 4036376.21</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="24">316174.2 4036393.37 316173.55 4036394.54 316170.95 4036399.22 316175.81 4036401.93 316176.86 4036399.99 316178.06 4036400.68 316178.57 4036399.76 316184.11 4036402.9 316183.58 4036403.83 316184.72 4036404.48 316183.69 4036406.5 316188.44 4036409.17 316191.74 4036403.38 316188.88 4036401.75 316190.44 4036398.87 316187.56 4036397.2 316184.66 4036395.51 316182.98 4036394.54 316181.82 4036393.87 316178.91 4036392.18 316177.48 4036394.54 316177.17 4036395.06 316176.26 4036394.54 316174.2 4036393.37</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="20">316201.68 4036386.12 316204.93 4036380.39 316200.13 4036377.63 316199.03 4036379.58 316197.89 4036378.93 316197.38 4036379.77 316191.72 4036376.72 316192.2 4036375.67 316191.08 4036375.02 316192.14 4036373.16 316187.41 4036370.44 316184.12 4036376.21 316186.96 4036377.81 316185.39 4036380.6 316188.34 4036382.28 316191.18 4036383.89 316194.15 4036385.58 316197.05 4036387.23 316198.64 4036384.41 316201.68 4036386.12</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="19">316197.05 4036387.23 316195.29 4036390.32 316192.9 4036394.54 316192.14 4036395.88 316190.44 4036398.87 316193.37 4036400.5 316191.74 4036403.38 316197.72 4036406.85 316200.79 4036400.78 316198.17 4036399.38 316200.89 4036394.54 316201.37 4036393.68 316202.9 4036394.54 316204.29 4036395.32 316204.73 4036394.54 316207.56 4036389.48 316201.68 4036386.12 316200.12 4036389 316197.05 4036387.23</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>20</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>20</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6266801UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">2118</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6267301UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316028.53 4036457.64</gml:lowerCorner>
         <gml:upperCorner>316142.3 4036637.51</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2024-02-20T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>2023-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>2023-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6267301&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6267301UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6267301UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6267301UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6267301UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6267301UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="30">316108.85 4036457.64 316107.83 4036459.7 316107.29 4036460.79 316106.45 4036462.52 316100.35 4036474.97 316099.96 4036475.77 316095.32 4036485.22 316092.9 4036490.14 316083.31 4036509.46 316075.57 4036525.04 316069.67 4036536.98 316069.68 4036536.98 316069.58 4036537.18 316067.08 4036542.26 316052.17 4036572.12 316044.34 4036588.01 316041.91 4036592.91 316040.7 4036595.34 316039.65 4036597.45 316028.53 4036621.45 316046.65 4036632.04 316058.75 4036637.51 316065.24 4036624.62 316079.65 4036595.34 316086.16 4036582.48 316130.47 4036494.94 316142.3 4036471.58 316135.28 4036467.97 316133.96 4036470.54 316108.85 4036457.64</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>4_2_retail</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>0</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6267301UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">6481</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6267302UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316142.35 4036473.62</gml:lowerCorner>
         <gml:upperCorner>316164.58 4036504.79</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1983-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1998-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6267302&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6267302UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6267302UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6267302UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6267302UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6267302UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5">316144.55 4036496.96 316142.35 4036501.35 316148.98 4036504.79 316151.24 4036500.67 316144.55 4036496.96</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">316159.54 4036488.62 316160.32 4036487.17 316160.07 4036487.03 316164.58 4036478.83 316153.9 4036473.62 316149.99 4036481.63 316146.43 4036488.91 316144.22 4036492.87 316148.18 4036494.94 316154.39 4036498.18 316156.14 4036494.94 316156.69 4036493.92 316159.54 4036488.62</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>4_2_retail</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>0</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6267302UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">287</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6268801UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316049.19 4036687.43</gml:lowerCorner>
         <gml:upperCorner>316067.96 4036706.84</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1985-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1985-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6268801&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6268801UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6268801UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6268801UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6268801UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6268801UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="30">316056.04 4036702.47 316058.12 4036703.52 316059.26 4036703.92 316059.62 4036703.98 316059.98 4036703.97 316060.34 4036703.91 316060.68 4036703.78 316061 4036703.6 316061.28 4036703.36 316061.51 4036703.08 316061.7 4036702.76 316061.82 4036702.42 316061.88 4036702.06 316061.89 4036701.7 316061.49 4036700.89 316060.88 4036700.32 316060.64 4036700.17 316062.48 4036696.75 316065.14 4036698.11 316066.34 4036695.74 316067.96 4036692.52 316063.8 4036690.41 316061.27 4036695.67 316058.96 4036694.45 316061.66 4036689.33 316057.9 4036687.43 316053.66 4036695.74 316049.19 4036704.49 316053.87 4036706.84 316056.04 4036702.47</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>4_3_publicServices</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>5</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>0</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6268801UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">448</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6268802UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316086.01 4036663.34</gml:lowerCorner>
         <gml:upperCorner>316125.27 4036713.83</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-09-03T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1985-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1985-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6268802&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6268802UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6268802UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6268802UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6268802UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6268802UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="71">316094.24 4036707.9 316094.04 4036708.3 316096.82 4036709.68 316097.04 4036709.38 316102.43 4036712.07 316102.51 4036711.81 316106.42 4036713.83 316107.08 4036712.56 316107.81 4036712.9 316108.97 4036710.43 316108.72 4036710.25 316110.91 4036706.03 316112.22 4036706.65 316113.21 4036707.13 316115.15 4036703.27 316114.16 4036702.91 316114.31 4036702.62 316116.11 4036699.17 316116.8 4036699.6 316121.17 4036691.26 316120.28 4036690.91 316122.16 4036687.42 316123.18 4036687.84 316125.27 4036683.92 316124.24 4036683.47 316124.36 4036683.25 316124.04 4036683.09 316120.67 4036681.43 316122.85 4036677.25 316122.52 4036677.12 316124.52 4036673.35 316120.63 4036671.43 316120.81 4036671.12 316116.24 4036668.85 316116.24 4036668.44 316113.52 4036666.93 316113.41 4036667.34 316108.93 4036665.12 316108.78 4036665.35 316104.95 4036663.34 316103.04 4036667.16 316102.83 4036667.01 316100.64 4036671.06 316099.82 4036670.75 316097.85 4036674.69 316098.8 4036675.2 316098.64 4036675.51 316096.9 4036678.86 316096.05 4036678.4 316091.85 4036686.73 316092.65 4036687.11 316090.85 4036690.61 316090.69 4036690.92 316089.77 4036690.45 316087.96 4036694.04 316088.89 4036694.5 316088.78 4036694.74 316089.82 4036695.25 316089.58 4036695.74 316087.84 4036699.34 316088.03 4036699.44 316087.88 4036699.72 316087.3 4036699.43 316086.1 4036701.79 316086.65 4036702.09 316086.17 4036703.02 316086.01 4036703.33 316086.17 4036703.41 316089.91 4036705.25 316089.78 4036705.63 316094.24 4036707.9</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                <gml:interior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="32">316098.66 4036695.24 316099.28 4036695.48 316101.47 4036691.23 316101.31 4036691.06 316105.1 4036683.58 316105.45 4036683.68 316107.55 4036679.39 316107.04 4036679.06 316108.92 4036675.42 316109.37 4036675.63 316109.06 4036676.39 316111.65 4036677.72 316112.06 4036677.08 316116.21 4036679.2 316114.27 4036682.93 316113.78 4036682.67 316111.56 4036686.94 316111.82 4036687.07 316109.95 4036690.75 316108.09 4036694.41 316107.85 4036694.28 316107.08 4036695.74 316105.53 4036698.69 316105.96 4036698.9 316104.24 4036702.49 316101.31 4036701.1 316101.69 4036700.39 316098.81 4036698.96 316098.5 4036699.6 316096.85 4036698.8 316098.41 4036695.74 316098.66 4036695.24</gml:posList>
                    </gml:LinearRing>
                </gml:interior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>30</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>30</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6268802UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">3169</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6268803UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316106.21 4036612</gml:lowerCorner>
         <gml:upperCorner>316149.09 4036669.78</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-09-03T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1985-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1985-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6268803&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6268803UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6268803UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6268803UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6268803UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6268803UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="74">316106.21 4036660.59 316110.07 4036662.62 316109.94 4036662.96 316114.51 4036665.42 316114.93 4036664.57 316117.87 4036666.13 316117.42 4036666.96 316122.07 4036669.24 316122.23 4036668.75 316124.09 4036669.78 316126.25 4036665.49 316125.97 4036665.39 316128.04 4036661.4 316126.57 4036660.63 316126.81 4036660.22 316124.99 4036659.42 316124.69 4036659.55 316121.95 4036658.12 316121.57 4036658.96 316118.69 4036657.48 316119.06 4036656.6 316118.28 4036656.19 316120.28 4036652.5 316121.2 4036652.96 316123.24 4036648.62 316122.88 4036648.46 316124.71 4036644.69 316124.39 4036644.56 316126.54 4036640.4 316128.75 4036636.14 316129.12 4036636.33 316131.03 4036632.63 316131.56 4036632.93 316133.71 4036628.72 316132.81 4036628.22 316134.69 4036624.5 316135.44 4036624.94 316135.97 4036623.99 316138.81 4036625.49 316138.34 4036626.28 316141.08 4036627.57 316141.17 4036628.12 316142.83 4036628.92 316143.01 4036628.49 316144.59 4036629.23 316146.6 4036625.31 316146.86 4036625.5 316149.09 4036621.17 316147.33 4036620.3 316147.46 4036619.9 316142.94 4036617.62 316142.49 4036618.35 316139.53 4036616.94 316140 4036615.99 316135.31 4036613.67 316135.05 4036614.01 316131.2 4036612 316129.24 4036615.92 316128.92 4036615.77 316126.67 4036620.27 316127.45 4036620.71 316125.71 4036623.94 316125.17 4036623.59 316120.83 4036632.03 316121.44 4036632.3 316116.95 4036640.74 316116.47 4036640.45 316112.12 4036648.89 316112.7 4036649.2 316111.01 4036652.34 316110.31 4036651.92 316107.98 4036656.51 316108.22 4036656.65 316106.21 4036660.59</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>18</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>18</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6268803UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">2352</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6268804UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316133.94 4036570.79</gml:lowerCorner>
         <gml:upperCorner>316175.04 4036620.64</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-09-03T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1985-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1985-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6268804&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6268804UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6268804UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6268804UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6268804UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6268804UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="78">316134.73 4036608.88 316134.1 4036610.17 316137.95 4036612.04 316137.89 4036612.3 316142.47 4036614.75 316142.86 4036613.85 316145.43 4036615.15 316145.02 4036616 316150.54 4036618.88 316150.64 4036618.65 316153.47 4036620.11 316154.49 4036620.64 316155.07 4036619.51 316155.98 4036619.94 316157.21 4036617.32 316156.76 4036617.09 316156.96 4036616.72 316158.95 4036612.96 316160.17 4036613.6 316160.27 4036613.41 316161.21 4036613.89 316163.21 4036609.99 316162.15 4036609.58 316162.25 4036609.37 316162.46 4036609.48 316164.27 4036605.96 316168.49 4036597.73 316169.69 4036595.34 316170.23 4036594.26 316170.33 4036594.07 316171.2 4036594.52 316173.13 4036590.77 316172.33 4036590.01 316170.91 4036589.36 316172.81 4036585.68 316173.05 4036585.21 316173.66 4036585.52 316175.04 4036582.9 316174.17 4036582.47 316174.73 4036581.36 316173.93 4036580.95 316170.91 4036579.44 316171.04 4036579.08 316165.57 4036576.23 316165.2 4036577.15 316162.52 4036575.72 316163 4036574.85 316158.35 4036572.57 316158.22 4036572.85 316155.02 4036571.1 316154.45 4036570.79 316153.8 4036571.99 316152.89 4036571.54 316151.53 4036574.25 316152.17 4036574.56 316150.06 4036578.49 316148.95 4036577.96 316147.93 4036577.76 316145.91 4036581.77 316146.55 4036582.1 316144.9 4036585.55 316144.25 4036585.13 316139.98 4036593.47 316140.59 4036593.77 316139.77 4036595.34 316138.8 4036597.2 316139.04 4036597.33 316138.5 4036598.38 316137.55 4036597.89 316136 4036600.88 316137.11 4036601.06 316136.84 4036601.57 316137.88 4036602.09 316135.76 4036606.22 316135.97 4036606.32 316135.19 4036605.99 316133.94 4036608.49 316134.73 4036608.88</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                <gml:interior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="31">316159.11 4036595.34 316156.1 4036601.29 316155.82 4036601.19 316153.67 4036605.46 316154.05 4036605.71 316152.21 4036609.32 316149.43 4036607.9 316149.01 4036608.71 316146.14 4036607.19 316146.52 4036606.31 316144.96 4036605.55 316146.78 4036601.96 316147.35 4036602.22 316149.65 4036597.71 316149.48 4036597.58 316150.63 4036595.34 316153.24 4036590.27 316153.47 4036590.33 316155.43 4036586.19 316155.05 4036585.99 316157.01 4036582.31 316158.59 4036583.08 316158.98 4036582.25 316161.88 4036583.81 316161.51 4036584.61 316164.23 4036585.96 316162.29 4036589.67 316161.94 4036589.47 316159.75 4036593.69 316159.89 4036593.79 316159.11 4036595.34</gml:posList>
                    </gml:LinearRing>
                </gml:interior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>26</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>26</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6268804UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">3161</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6268805UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316164.92 4036523.96</gml:lowerCorner>
         <gml:upperCorner>316194.12 4036580.86</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1986-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1986-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6268805&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6268805UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6268805UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6268805UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6268805UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6268805UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5">316166.46 4036523.96 316164.92 4036526.91 316168.55 4036528.8 316170.09 4036525.85 316166.46 4036523.96</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="75">316181.85 4036579.17 316185.11 4036580.86 316187.1 4036576.87 316183.85 4036575.22 316184.31 4036574.32 316183.05 4036573.75 316184.84 4036570.24 316186.14 4036570.83 316189.14 4036572.41 316191.59 4036567.5 316192.07 4036567.71 316194.12 4036563.52 316192.34 4036562.69 316193.57 4036560.23 316192.65 4036559.77 316192.33 4036560.02 316191.61 4036560.24 316190.61 4036560.49 316190.48 4036560.83 316190.64 4036561.21 316191.1 4036561.88 316191.27 4036562.2 316191.24 4036562.24 316191.15 4036562.55 316191.03 4036562.78 316190.78 4036562.99 316190.23 4036563.53 316189.64 4036564.11 316189.09 4036564.74 316189.17 4036564.13 316189.19 4036563.52 316189.15 4036562.91 316189.05 4036562.31 316188.88 4036561.73 316188.65 4036561.16 316188.36 4036560.62 316188.02 4036560.12 316187.63 4036559.65 316187.19 4036559.23 316186.71 4036558.86 316186.17 4036558.55 316185.61 4036558.31 316185.02 4036558.13 316184.41 4036558.02 316183.8 4036557.99 316183.18 4036558.02 316182.57 4036558.13 316181.98 4036558.3 316181.42 4036558.54 316180.88 4036558.84 316180.39 4036559.21 316180.08 4036559.5 316179.79 4036559.81 316179.51 4036560.13 316179.23 4036560.45 316178.97 4036560.79 316178.72 4036561.13 316178.48 4036561.48 316178.25 4036561.84 316178.03 4036562.2 316177.83 4036562.58 316177.64 4036562.96 316176.31 4036564.67 316175.1 4036566.02 316172.69 4036568.51 316172.1 4036569.09 316171.46 4036569.63 316170.75 4036570.13 316170.04 4036570.56 316169.29 4036570.88 316168.56 4036571.24 316167.63 4036571.64 316167.1 4036571.81 316181.72 4036579.44 316181.85 4036579.17</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>4_3_publicServices</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>0</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6268805UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">682</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6268806UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316183.49 4036477.68</gml:lowerCorner>
         <gml:upperCorner>316216.8 4036504.69</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1985-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1985-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6268806&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6268806UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6268806UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6268806UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6268806UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6268806UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="24">316192.92 4036494.91 316192.97 4036494.94 316205.52 4036501.41 316210.05 4036503.81 316210.99 4036502.02 316216.16 4036504.69 316216.8 4036503.18 316216.41 4036501.06 316216.22 4036500.26 316215.96 4036499.39 316215.68 4036498.52 316215.37 4036497.65 316214.85 4036496.65 316213.47 4036497.27 316208.79 4036495.04 316208.84 4036494.94 316210.73 4036491.48 316208.01 4036490.17 316209.16 4036487.95 316199.39 4036482.92 316199.52 4036482.71 316189.8 4036477.68 316183.49 4036490.05 316192.92 4036494.91</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>3</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>2</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6268806UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">1861</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6364201UF1366S">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316179.34 4036229.08</gml:lowerCorner>
         <gml:upperCorner>316231.07 4036278.69</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2005-09-14T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1983-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1983-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6364201&rc2=UF1366S]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6364201UF1366S</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6364201UF1366S</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6364201UF1366S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6364201UF1366S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6364201UF1366S" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="54">316186.71 4036259.42 316189.62 4036261.16 316191 4036258.52 316193.71 4036260.05 316192.41 4036262.43 316197.17 4036265.13 316198.4 4036265.83 316198.58 4036265.28 316204.58 4036268.78 316205.86 4036266.47 316208.68 4036267.97 316206.94 4036270.96 316209.79 4036272.61 316208.85 4036274.13 316208.12 4036275.31 316214.17 4036278.69 316217.94 4036272.01 316217.33 4036271.65 316215.11 4036270.33 316217.72 4036265.74 316216.45 4036265.05 316216.22 4036265.45 316214.41 4036264.46 316213.93 4036265.3 316213.67 4036265.76 316210.99 4036264.24 316212.74 4036261.15 316209.86 4036259.5 316209.59 4036259.92 316206.98 4036258.39 316206.73 4036258.24 316206.62 4036258.17 316206.45 4036258.45 316205.57 4036259.98 316204.92 4036261.1 316199.06 4036257.82 316199.7 4036256.73 316200.52 4036255.34 316197.49 4036253.46 316197.65 4036253.13 316194.84 4036251.46 316193.97 4036252.9 316193.21 4036254.17 316190.59 4036252.68 316191.35 4036251.36 316189.55 4036250.4 316189.78 4036249.97 316188.51 4036249.24 316188.19 4036249.8 316185.95 4036253.76 316183.1 4036252.14 316179.34 4036258.75 316185.23 4036262.2 316186.71 4036259.42</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="48">316195.26 4036237.51 316192.72 4036241.89 316193.99 4036242.65 316194.18 4036242.15 316194.92 4036242.6 316196.06 4036243.27 316196.73 4036241.94 316199.5 4036243.73 316198.03 4036246.26 316200.74 4036247.8 316201.01 4036247.33 316204.13 4036249.06 316205.35 4036246.75 316208.34 4036248.45 316208.11 4036248.85 316210.96 4036250.49 316209.64 4036252.83 316212.63 4036254.53 316212.27 4036255.21 316215.18 4036256.72 316217 4036253.63 316219.71 4036255.11 316219.02 4036256.43 316220.77 4036257.32 316220.59 4036257.75 316221.93 4036258.56 316222.47 4036257.55 316224.35 4036254.03 316227.12 4036255.63 316231.07 4036249.02 316225.25 4036245.55 316223.7 4036248.13 316220.75 4036246.51 316219.12 4036249.53 316216.43 4036248.01 316217.65 4036245.74 316211.8 4036242.18 316212 4036241.8 316205.97 4036238.33 316204.74 4036240.88 316202.06 4036239.32 316203.53 4036236.78 316200.66 4036235.07 316200.68 4036235.02 316202.16 4036232.56 316196.22 4036229.08 316192.5 4036235.69 316195.26 4036237.51</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>25</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>25</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6364201UF1366S</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">1549</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6364401UF1366S">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316221.76 4036254.32</gml:lowerCorner>
         <gml:upperCorner>316261.91 4036295.09</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1975-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1975-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6364401&rc2=UF1366S]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6364401UF1366S</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6364401UF1366S</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6364401UF1366S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6364401UF1366S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6364401UF1366S" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="46">316231.93 4036285.22 316234.9 4036286.85 316235.06 4036286.42 316237.88 4036288 316235.75 4036291.76 316236.48 4036292.18 316241.62 4036295.09 316245.47 4036288.26 316246.86 4036289.05 316252.09 4036292.04 316255.37 4036286.12 316252.24 4036284.3 316253.74 4036281.42 316253.46 4036281.2 316254.91 4036278.58 316255.91 4036279.09 316258.64 4036280.5 316258.94 4036279.96 316261.91 4036274.73 316255.42 4036270.95 316256.54 4036268.92 316259.18 4036264.16 316253.36 4036260.84 316251.6 4036264.17 316248.61 4036262.46 316248.41 4036262.91 316245.63 4036261.24 316247.66 4036257.78 316241.87 4036254.32 316239.63 4036258.25 316238.09 4036260.94 316234.32 4036258.89 316231.53 4036257.37 316228.32 4036263.07 316228.26 4036263.18 316231.45 4036265.01 316229.79 4036267.89 316230.21 4036268.1 316228.59 4036270.99 316224.96 4036268.91 316221.76 4036274.78 316225.95 4036277.19 316228.23 4036278.49 316224.33 4036285.29 316230.12 4036288.59 316231.93 4036285.22</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                <gml:interior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">316232.57 4036277.16 316231.54 4036278.96 316231.24 4036279.48 316229.43 4036278.34 316230.69 4036276.1 316231.14 4036276.35 316232.57 4036277.16</gml:posList>
                    </gml:LinearRing>
                </gml:interior>
                <gml:interior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="15">316232.57 4036277.16 316234.26 4036274.21 316235.86 4036271.42 316237.58 4036268.41 316239.24 4036265.52 316242.05 4036267.12 316247.97 4036270.5 316250.86 4036272.15 316249.18 4036275.12 316247.51 4036278.07 316245.87 4036280.96 316244.28 4036283.76 316241.3 4036282.08 316235.69 4036278.92 316232.57 4036277.16</gml:posList>
                    </gml:LinearRing>
                </gml:interior>
                <gml:interior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">316239.24 4036265.52 316237.82 4036264.7 316237.27 4036264.39 316238.49 4036262.22 316240.48 4036263.37 316240.18 4036263.88 316239.24 4036265.52</gml:posList>
                    </gml:LinearRing>
                </gml:interior>
                <gml:interior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">316250.86 4036272.15 316251.84 4036270.43 316252.07 4036270.04 316254.04 4036271.17 316252.84 4036273.27 316252.02 4036272.8 316250.86 4036272.15</gml:posList>
                    </gml:LinearRing>
                </gml:interior>
                <gml:interior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">316244.28 4036283.76 316245.42 4036284.4 316246.25 4036284.87 316244.97 4036287.13 316242.99 4036286.04 316243.28 4036285.53 316244.28 4036283.76</gml:posList>
                    </gml:LinearRing>
                </gml:interior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>23</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>23</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6364401UF1366S</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">1506</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6364501UF1366S">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316230.23 4036256.87</gml:lowerCorner>
         <gml:upperCorner>316330.76 4036349.55</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2009-08-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1985-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>2022-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6364501&rc2=UF1366S]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6364501UF1366S</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6364501UF1366S</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6364501UF1366S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6364501UF1366S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6364501UF1366S" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="44">316274.25 4036335.96 316267.27 4036346.15 316268.82 4036347.09 316269.78 4036345.63 316271.42 4036346.57 316272.53 4036344.85 316274.95 4036341.14 316277.2 4036338.12 316277.34 4036337.92 316279.16 4036335.38 316281.33 4036332.81 316283.76 4036330.29 316285.76 4036328.27 316286.28 4036327.72 316286.28 4036325.1 316286.28 4036321.37 316283.71 4036319.18 316278.69 4036319.57 316274.86 4036319.87 316269.94 4036317.77 316266.73 4036314.68 316262.99 4036311.09 316260.55 4036306.19 316257.98 4036298.86 316258.49 4036294.23 316259.91 4036291.78 316258.27 4036290.83 316257.9 4036291.48 316255.75 4036295.14 316253.67 4036298.8 316252.15 4036301.52 316250.91 4036303.75 316245.22 4036313.91 316235.23 4036331.19 316230.23 4036339.88 316243.59 4036347.47 316243.85 4036346.73 316244.11 4036346.82 316243.99 4036347.13 316248.12 4036349.55 316260.36 4036328.32 316273.2 4036335.74 316273.33 4036335.41 316274.25 4036335.96</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                <gml:interior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5">316245.06 4036346.24 316246.39 4036343.98 316249.29 4036345.7 316247.96 4036347.96 316245.06 4036346.24</gml:posList>
                    </gml:LinearRing>
                </gml:interior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="19">316281.4 4036256.87 316281.33 4036256.93 316280.98 4036257.2 316280.62 4036257.44 316280.23 4036257.66 316279.84 4036257.84 316279.43 4036258 316279.01 4036258.13 316278.58 4036258.23 316278.14 4036258.29 316277.71 4036258.33 316277.33 4036258.32 316275.57 4036261.47 316280.06 4036263.77 316282.45 4036260.01 316282.79 4036259.28 316282.83 4036258.56 316282.76 4036258.14 316281.4 4036256.87</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="10">316301.86 4036311.6 316299.28 4036309.15 316292.33 4036316.48 316287.96 4036320.08 316288.34 4036322.66 316289.54 4036324.29 316290.19 4036323.61 316292.6 4036321.08 316300.85 4036312.66 316301.86 4036311.6</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="8">316317.04 4036286.22 316321.68 4036290.12 316324.15 4036287.18 316330.76 4036279.31 316321 4036271.11 316319.8 4036272.54 316311.92 4036281.92 316317.04 4036286.22</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>4_2_retail</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>2</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>0</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6364501UF1366S</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">2074</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6364601UF1366S">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316236.91 4036235.87</gml:lowerCorner>
         <gml:upperCorner>316275.24 4036262.86</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1975-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1975-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6364601&rc2=UF1366S]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6364601UF1366S</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6364601UF1366S</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6364601UF1366S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6364601UF1366S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6364601UF1366S" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="40">316244.43 4036243.35 316247.35 4036245.02 316248.99 4036242.02 316251.8 4036243.67 316250.18 4036246.43 316255.84 4036249.74 316261.92 4036253.29 316263.51 4036250.48 316266.35 4036252.09 316266.15 4036252.43 316264.66 4036254.96 316267.62 4036256.64 316265.98 4036259.34 316271.77 4036262.86 316275.24 4036256.88 316272.38 4036255.19 316272.32 4036255.16 316273.87 4036252.57 316270.99 4036250.94 316271.2 4036250.56 316268.27 4036248.91 316269.97 4036246.11 316266.98 4036244.32 316266.66 4036244.62 316263.93 4036243.05 316262.15 4036245.87 316256.39 4036242.52 316258.02 4036239.65 316255.14 4036237.98 316255.4 4036237.65 316252.31 4036235.87 316250.7 4036238.9 316247.86 4036237.17 316247.63 4036237.57 316244.73 4036235.92 316243.16 4036238.71 316240.33 4036237.09 316236.91 4036242.89 316242.8 4036246.34 316244.43 4036243.35</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>12</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>12</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6364601UF1366S</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">1033</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6364801UF1366S">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316202.75 4036205.34</gml:lowerCorner>
         <gml:upperCorner>316243.57 4036244.48</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1983-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1983-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6364801&rc2=UF1366S]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6364801UF1366S</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6364801UF1366S</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6364801UF1366S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6364801UF1366S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6364801UF1366S" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="60">316221.95 4036237.34 316225.6 4036239.45 316225.39 4036239.92 316229.1 4036242.1 316233.16 4036244.48 316234.24 4036242.26 316234.75 4036242.59 316237.09 4036238.28 316236.2 4036237.69 316237.71 4036235.1 316238.61 4036235.61 316241.69 4036230.22 316241.36 4036230.07 316242.88 4036227.31 316243.57 4036226.11 316242.91 4036225.75 316243.23 4036225.21 316236.09 4036221.32 316236.9 4036219.95 316233.23 4036217.8 316233.59 4036217.14 316226.19 4036212.97 316226.8 4036211.96 316225.81 4036211.4 316225.45 4036211.99 316223.36 4036210.87 316223.68 4036210.33 316223 4036209.88 316223.64 4036208.67 316223.78 4036208.22 316223.82 4036207.75 316223.76 4036207.29 316223.6 4036206.85 316223.35 4036206.45 316223.02 4036206.12 316222.63 4036205.87 316222.19 4036205.71 316221.72 4036205.64 316221.26 4036205.68 316220.81 4036205.82 316220.4 4036206.05 316220.06 4036206.36 316219.79 4036206.75 316219.09 4036207.62 316215.33 4036205.34 316214.33 4036207.03 316209.48 4036215.33 316209.78 4036215.5 316207.63 4036219.15 316207.28 4036218.97 316202.75 4036226.38 316205.67 4036228.01 316205.45 4036228.41 316210.93 4036231.58 316211.34 4036230.73 316214.12 4036232.25 316213.62 4036233.12 316217.97 4036235.61 316218.18 4036235.26 316221.95 4036237.34</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                <gml:interior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="15">316228.34 4036233.04 316226.52 4036232.07 316227.59 4036230.26 316218.64 4036225.13 316218.51 4036225.41 316215.28 4036223.68 316217.41 4036219.84 316220.41 4036221.49 316220.18 4036221.97 316228.02 4036226.43 316227.94 4036226.67 316231.75 4036228.92 316230.56 4036230.99 316229.78 4036230.54 316228.34 4036233.04</gml:posList>
                    </gml:LinearRing>
                </gml:interior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>13</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>13</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6364801UF1366S</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">1545</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6365101UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316195.01 4036286.69</gml:lowerCorner>
         <gml:upperCorner>316246.71 4036336.05</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1975-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1975-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6365101&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6365101UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6365101UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6365101UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6365101UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6365101UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="48">316230.79 4036327.74 316231.97 4036325.79 316229.03 4036324.07 316229.33 4036323.64 316226.35 4036322.02 316226.61 4036321.58 316227.96 4036319.24 316225.14 4036317.53 316224.92 4036317.91 316221.89 4036316.19 316221.1 4036317.57 316220.21 4036319.14 316214.42 4036315.89 316214.93 4036315 316216.12 4036312.94 316213.1 4036311.03 316212.85 4036311.48 316209.99 4036309.74 316209.02 4036311.57 316208.78 4036312.02 316205.88 4036310.15 316205.56 4036310.63 316202.79 4036309.1 316202.02 4036310.51 316201.19 4036312.02 316198.36 4036310.37 316195.01 4036316.19 316195.18 4036316.28 316199.66 4036318.84 316199.74 4036318.69 316200.98 4036319.35 316202.41 4036316.61 316205.42 4036318.31 316206.91 4036315.5 316209.69 4036317.02 316208.13 4036319.93 316220.11 4036326.5 316221.65 4036323.74 316224.47 4036325.28 316222.73 4036328.26 316225.65 4036329.88 316224.13 4036332.49 316225.28 4036333.16 316225.13 4036333.4 316229.91 4036336.05 316233.18 4036330.28 316230.27 4036328.61 316230.79 4036327.74</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="45">316215.05 4036301.18 316213.67 4036303.55 316216.46 4036305.19 316216.82 4036304.56 316219.95 4036306.35 316220.95 4036304.52 316221.43 4036303.65 316227.2 4036306.88 316226.64 4036307.92 316225.57 4036309.9 316228.48 4036311.47 316228.14 4036312.09 316231.17 4036313.75 316232.52 4036311.28 316235.26 4036312.82 316234.7 4036313.85 316236.49 4036314.87 316236.29 4036315.27 316237.53 4036315.98 316240.22 4036311.34 316243.04 4036312.87 316246.71 4036306.57 316240.87 4036303.15 316239.12 4036306.13 316236.27 4036304.46 316234.69 4036307.33 316231.93 4036305.72 316233.45 4036303.11 316221.59 4036296.16 316220.11 4036298.96 316217.3 4036297.3 316218.56 4036295.14 316218.94 4036294.49 316216.13 4036292.92 316217.53 4036290.27 316216.41 4036289.68 316216.57 4036289.37 316211.8 4036286.69 316208.5 4036292.55 316211.35 4036294.15 316210.78 4036295.14 316209.77 4036296.93 316212.7 4036298.59 316212.17 4036299.5 316215.05 4036301.18</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>22</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>22</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6365101UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">2229</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6365201UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316183.23 4036326.63</gml:lowerCorner>
         <gml:upperCorner>316234.44 4036379.43</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-09-17T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1975-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1975-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6365201&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6365201UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6365201UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6365201UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6365201UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6365201UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="45">316194.44 4036364.05 316196 4036361.15 316196.42 4036361.4 316198.09 4036358.53 316199.33 4036359.24 316200.99 4036360.2 316202.67 4036357.23 316202.62 4036357.16 316202.31 4036357.03 316204.01 4036354.03 316202.84 4036353.3 316202.17 4036352.89 316203.77 4036349.99 316205.32 4036347.18 316206 4036347.57 316207.3 4036348.31 316208.98 4036345.4 316209.45 4036345.65 316211.11 4036342.66 316209.38 4036341.67 316208.03 4036340.9 316209.62 4036338.15 316209.39 4036337.97 316211.08 4036335.11 316210.06 4036334.46 316209.05 4036333.82 316210.7 4036331.07 316203.03 4036326.63 316199.8 4036332.42 316203.38 4036334.65 316201.73 4036337.3 316204.71 4036339 316203.13 4036341.78 316202.16 4036341.25 316199.38 4036339.77 316196.08 4036345.52 316192.54 4036351.7 316196.25 4036353.89 316194.7 4036356.53 316192 4036354.79 316190.28 4036357.83 316186.63 4036355.6 316183.23 4036361.44 316192.82 4036366.85 316194.44 4036364.05</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="44">316214.18 4036371.38 316215.81 4036368.51 316212.88 4036367.02 316214.51 4036364.15 316218.39 4036366.33 316225.07 4036354.53 316221.58 4036352.58 316223.09 4036349.63 316225.77 4036351.09 316227.37 4036348.4 316231.17 4036350.48 316234.44 4036344.59 316228.31 4036341.09 316226.67 4036340.15 316225.18 4036342.94 316224.25 4036342.44 316223.24 4036341.9 316221.53 4036345.12 316221.18 4036344.87 316219.66 4036347.43 316218.14 4036346.67 316216.97 4036346.08 316215.39 4036348.98 316215.06 4036348.82 316213.55 4036351.87 316214.91 4036352.59 316215.41 4036352.86 316215.71 4036353.03 316212.31 4036358.9 316211.42 4036358.41 316210.39 4036357.84 316208.89 4036360.6 316208.51 4036360.42 316206.85 4036363.55 316208.02 4036364.24 316209.35 4036365.02 316207.85 4036367.9 316208.27 4036368.1 316206.59 4036371.06 316207.33 4036371.47 316205.75 4036374.33 316214.6 4036379.43 316218 4036373.59 316214.18 4036371.38</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>18</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>18</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6365201UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">1669</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6366901UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316234.94 4036435.45</gml:lowerCorner>
         <gml:upperCorner>316263.99 4036470.83</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-09-03T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6366901&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6366901UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6366901UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6366901UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6366901UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6366901UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16">316249.76 4036469 316251.23 4036469.72 316263.99 4036444.2 316262.98 4036443.5 316249.48 4036436.81 316246.45 4036435.45 316244.99 4036438.44 316247 4036439.32 316248.06 4036439.78 316246.83 4036442.39 316247.28 4036442.64 316244.14 4036448.83 316234.94 4036467.69 316241.62 4036470.83 316243.73 4036466.29 316249.76 4036469</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>89</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>89</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6366901UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">5926</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6367901UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316224.72 4036525.48</gml:lowerCorner>
         <gml:upperCorner>316247.79 4036553.1</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2005-09-14T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6367901&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6367901UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6367901UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6367901UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6367901UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6367901UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="8">316238.59 4036553.1 316242.48 4036545.28 316247.79 4036534.26 316229.54 4036525.48 316226.13 4036533.24 316229.7 4036534.97 316224.72 4036546.49 316238.59 4036553.1</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>4_1_office</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>0</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6367901UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">331</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6368301UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316127.71 4036541.03</gml:lowerCorner>
         <gml:upperCorner>316326.27 4036766.65</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2018-11-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1989-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>2007-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6368301&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6368301UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6368301UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6368301UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6368301UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6368301UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="21">316140.42 4036709.55 316137.38 4036707.89 316136.64 4036709.23 316134.31 4036707.94 316135.04 4036706.6 316132.16 4036705.03 316130.66 4036707.77 316129.41 4036707.09 316127.89 4036709.88 316129.23 4036710.61 316127.71 4036713.38 316130.67 4036715 316131.44 4036713.58 316133.67 4036714.79 316132.91 4036716.17 316135.88 4036717.8 316137.39 4036715.04 316138.77 4036715.79 316140.28 4036713 316138.96 4036712.28 316140.42 4036709.55</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                <gml:interior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5">316134.68 4036713.54 316131.95 4036712.04 316133.49 4036709.26 316136.21 4036710.76 316134.68 4036713.54</gml:posList>
                    </gml:LinearRing>
                </gml:interior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5">316150.28 4036702.62 316133.84 4036732.44 316197.83 4036766.65 316213.88 4036736.62 316150.28 4036702.62</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="212">316152.78 4036681.99 316153.28 4036682.27 316152.58 4036683.56 316156.23 4036685.59 316156.6 4036684.89 316159.44 4036686.35 316159.24 4036686.74 316159.71 4036686.99 316159.17 4036688 316162.77 4036689.97 316163.56 4036688.51 316167.01 4036690.35 316166.24 4036691.87 316169.84 4036693.83 316170.39 4036692.82 316171.02 4036693.15 316171.21 4036692.78 316174.06 4036694.28 316173.64 4036695.06 316174.98 4036695.74 316177.36 4036696.95 316178.04 4036695.71 316178.1 4036695.74 316178.59 4036696 316179.16 4036696.31 316178.87 4036696.85 316180.95 4036697.93 316181.94 4036698.45 316182.44 4036697.55 316183.02 4036697.87 316182.72 4036698.41 316186.15 4036700.17 316186.83 4036698.92 316187.74 4036697.25 316187.24 4036696.95 316187.49 4036696.41 316187.77 4036695.82 316188.99 4036696.42 316189.36 4036695.74 316190.97 4036692.76 316190.24 4036692.42 316191.79 4036689.66 316192.15 4036689.84 316192.4 4036689.41 316193.65 4036689.98 316195.61 4036686.33 316194.5 4036685.69 316195.32 4036684.18 316195.65 4036684.36 316196.72 4036682.31 316196.03 4036681.95 316197.84 4036678.55 316198.54 4036678.97 316199.69 4036676.94 316199.39 4036676.78 316201.17 4036673.36 316201.57 4036673.54 316202.61 4036671.5 316201.91 4036671.13 316203.65 4036667.69 316204.48 4036668.1 316205.6 4036666.05 316205.34 4036665.89 316206.09 4036664.45 316207.24 4036665.06 316209.22 4036661.32 316208.05 4036660.7 316208.26 4036660.2 316207.98 4036660.05 316209.46 4036657.22 316210.2 4036657.58 316212.17 4036653.82 316210.94 4036653.15 316211.15 4036652.74 316211.49 4036652.08 316212.12 4036652.36 316212.68 4036651.29 316213.78 4036649.2 316210.13 4036647.31 316209.82 4036648.05 316208.63 4036647.46 316209.18 4036646.38 316208.81 4036646.18 316208.49 4036646.01 316206.37 4036644.88 316206.59 4036644.43 316206.07 4036644.14 316206.72 4036642.99 316206.77 4036642.97 316203.04 4036640.98 316203.02 4036640.94 316202.84 4036641.31 316198.8 4036639.17 316198.56 4036639.61 316197.32 4036638.93 316195.53 4036637.96 316194.54 4036639.82 316193.53 4036641.74 316196.53 4036643.34 316195.3 4036645.61 316198.86 4036647.45 316196.97 4036651.08 316200.93 4036653.16 316199.64 4036655.58 316199.19 4036655.34 316196.75 4036659.86 316189.17 4036673.9 316185.67 4036680.23 316183.09 4036684.9 316183.49 4036685.11 316182.29 4036687.54 316178.23 4036685.35 316178.03 4036685.87 316177.98 4036685.84 316175.02 4036684.14 316174.78 4036684.59 316171.62 4036682.86 316172.8 4036680.69 316172.34 4036680.44 316173.62 4036678.13 316170.13 4036676.26 316168.89 4036678.51 316168.48 4036678.28 316167.19 4036680.57 316164.19 4036678.86 316164.43 4036678.44 316161.62 4036676.91 316161.95 4036676.49 316157.84 4036674.17 316159.11 4036671.86 316159.64 4036672.15 316162.2 4036667.45 316169.75 4036653.56 316173.21 4036647.23 316175.74 4036642.61 316174.91 4036642.15 316176.16 4036639.82 316180.57 4036642.15 316182.45 4036638.59 316186.02 4036640.46 316187.14 4036638.3 316190.16 4036639.97 316191.19 4036637.99 316192.15 4036636.16 316190.37 4036635.18 316189.09 4036634.47 316189.35 4036634 316185.42 4036631.9 316185.65 4036631.47 316181.94 4036629.5 316181.31 4036630.79 316180.78 4036630.53 316180.64 4036630.81 316177.54 4036629.15 316176.87 4036628.79 316176.28 4036629.82 316175.73 4036629.5 316176.16 4036628.76 316172.84 4036626.99 316171.91 4036628.81 316171.17 4036630.25 316171.53 4036630.49 316171.26 4036631.01 316170.96 4036631.58 316169.68 4036630.85 316167.7 4036634.55 316168.42 4036634.98 316166.97 4036637.79 316166.57 4036637.57 316166.26 4036638.05 316165 4036637.32 316162.98 4036641.04 316164.28 4036641.71 316163.54 4036643.15 316163.08 4036642.91 316161.96 4036645.05 316162.74 4036645.47 316160.97 4036648.79 316160.18 4036648.35 316158.99 4036650.47 316159.46 4036650.66 316157.53 4036654.07 316157.09 4036653.84 316156.04 4036655.87 316156.75 4036656.24 316155.03 4036659.61 316154.17 4036659.17 316153.05 4036661.37 316153.44 4036661.57 316152.72 4036662.98 316151.49 4036662.34 316149.59 4036665.94 316150.72 4036666.54 316150.43 4036667.09 316150.95 4036667.37 316149.42 4036670.22 316148.57 4036669.76 316146.51 4036673.52 316147.82 4036674.24 316147.61 4036674.62 316147.28 4036675.23 316146.81 4036674.97 316146.08 4036676.3 316145.23 4036677.87 316148.45 4036679.63 316148.69 4036679.19 316149.44 4036679.59 316148.87 4036680.66 316149.43 4036680.96 316151.79 4036682.22 316152.13 4036681.63 316152.78 4036681.99</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="214">316186.45 4036620.09 316186.96 4036620.37 316186.25 4036621.66 316189.9 4036623.69 316190.27 4036623 316193.11 4036624.46 316192.91 4036624.85 316193.37 4036625.1 316192.71 4036626.36 316196.31 4036628.32 316197.22 4036626.63 316200.66 4036628.47 316199.75 4036630.28 316203.38 4036632.19 316204.05 4036630.95 316204.68 4036631.28 316204.86 4036630.91 316207.71 4036632.42 316207.29 4036633.2 316211 4036635.09 316211.69 4036633.85 316212.24 4036634.15 316212.81 4036634.46 316212.51 4036634.99 316214.6 4036636.08 316215.59 4036636.6 316216.08 4036635.7 316216.66 4036636.02 316216.35 4036636.57 316219.74 4036638.43 316220.48 4036637.07 316221.39 4036635.41 316220.89 4036635.11 316221.14 4036634.57 316221.42 4036633.98 316222.63 4036634.58 316224.62 4036630.92 316223.89 4036630.59 316225.45 4036627.83 316225.81 4036628.01 316226.06 4036627.57 316227.31 4036628.15 316229.27 4036624.5 316228.17 4036623.86 316228.99 4036622.35 316229.31 4036622.53 316230.4 4036620.48 316229.7 4036620.12 316231.51 4036616.73 316232.22 4036617.15 316233.37 4036615.13 316233.07 4036614.97 316234.85 4036611.55 316235.26 4036611.73 316236.31 4036609.7 316235.6 4036609.33 316237.34 4036605.89 316238.18 4036606.29 316239.3 4036604.24 316239.04 4036604.09 316239.79 4036602.65 316240.94 4036603.26 316242.92 4036599.52 316241.76 4036598.9 316241.96 4036598.4 316241.69 4036598.25 316243.17 4036595.42 316243.91 4036595.78 316244.14 4036595.34 316245.89 4036592.03 316244.66 4036591.36 316244.87 4036590.95 316245.21 4036590.29 316245.85 4036590.57 316246.42 4036589.5 316247.54 4036587.39 316243.87 4036585.54 316243.56 4036586.27 316242.38 4036585.68 316242.93 4036584.6 316242.56 4036584.4 316242.37 4036584.29 316242.24 4036584.22 316240.12 4036583.09 316240.34 4036582.64 316239.82 4036582.35 316240.47 4036581.2 316240.52 4036581.18 316236.79 4036579.19 316236.77 4036579.14 316236.6 4036579.51 316232.56 4036577.37 316232.32 4036577.81 316231.08 4036577.13 316229.29 4036576.15 316228.31 4036578 316227.29 4036579.93 316230.28 4036581.53 316229.05 4036583.8 316232.61 4036585.65 316230.71 4036589.27 316234.65 4036591.35 316233.36 4036593.77 316232.91 4036593.53 316231.93 4036595.34 316230.46 4036598.04 316222.86 4036612.07 316219.34 4036618.39 316216.75 4036623.05 316217.16 4036623.27 316215.96 4036625.69 316211.9 4036623.49 316211.7 4036624.01 316211.65 4036623.98 316208.69 4036622.27 316208.44 4036622.73 316205.29 4036620.99 316206.48 4036618.82 316206.01 4036618.57 316207.3 4036616.28 316203.82 4036614.4 316202.56 4036616.65 316202.16 4036616.42 316200.87 4036618.7 316197.87 4036616.98 316198.11 4036616.57 316195.3 4036615.03 316195.64 4036614.61 316191.53 4036612.3 316192.81 4036609.99 316193.34 4036610.28 316195.9 4036605.59 316201.5 4036595.34 316203.48 4036591.71 316206.96 4036585.38 316209.49 4036580.77 316208.67 4036580.31 316209.92 4036577.97 316214.32 4036580.32 316216.21 4036576.76 316219.78 4036578.64 316220.9 4036576.48 316223.92 4036578.15 316224.96 4036576.18 316225.92 4036574.35 316224.13 4036573.36 316222.85 4036572.65 316223.12 4036572.18 316219.19 4036570.07 316219.42 4036569.65 316215.72 4036567.67 316215.08 4036568.96 316214.56 4036568.69 316214.41 4036568.97 316211.4 4036567.35 316210.65 4036566.94 316210.06 4036567.98 316209.5 4036567.66 316209.94 4036566.92 316206.62 4036565.14 316205.67 4036566.99 316204.95 4036568.4 316205.3 4036568.65 316205.03 4036569.15 316204.75 4036569.67 316203.42 4036569.05 316201.47 4036572.69 316202.19 4036573.12 316200.73 4036575.93 316200.33 4036575.7 316200.02 4036576.19 316198.76 4036575.45 316196.74 4036579.18 316198.03 4036579.85 316197.3 4036581.28 316196.83 4036581.04 316195.71 4036583.18 316196.49 4036583.6 316194.71 4036586.92 316193.92 4036586.49 316192.73 4036588.6 316193.2 4036588.79 316191.26 4036592.2 316190.83 4036591.96 316189.77 4036593.99 316190.48 4036594.37 316189.98 4036595.34 316188.75 4036597.73 316187.9 4036597.29 316186.77 4036599.49 316187.16 4036599.69 316186.43 4036601.1 316185.21 4036600.46 316183.29 4036604.05 316184.43 4036604.65 316184.13 4036605.21 316184.66 4036605.49 316183.11 4036608.33 316182.27 4036607.87 316180.21 4036611.63 316181.52 4036612.35 316181.31 4036612.73 316180.98 4036613.34 316180.51 4036613.08 316179.79 4036614.4 316178.94 4036615.97 316182.14 4036617.72 316182.37 4036617.28 316183.11 4036617.69 316182.55 4036618.75 316183.11 4036619.05 316185.46 4036620.32 316185.81 4036619.73 316186.45 4036620.09</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="216">316203.78 4036709.61 316204.29 4036709.9 316203.58 4036711.18 316207.22 4036713.21 316207.6 4036712.52 316210.44 4036713.99 316210.23 4036714.37 316210.7 4036714.63 316210.15 4036715.65 316213.77 4036717.6 316214.55 4036716.16 316217.99 4036718 316217.24 4036719.47 316220.86 4036721.42 316221.38 4036720.48 316222 4036720.8 316222.19 4036720.44 316225.04 4036721.94 316224.62 4036722.72 316228.33 4036724.62 316229.01 4036723.38 316229.56 4036723.68 316230.13 4036723.99 316229.84 4036724.52 316231.92 4036725.61 316232.91 4036726.13 316233.41 4036725.23 316233.99 4036725.55 316233.69 4036726.05 316237.08 4036727.87 316237.8 4036726.59 316238.72 4036724.94 316238.16 4036724.61 316238.43 4036724.08 316238.73 4036723.5 316239.96 4036724.11 316241.95 4036720.45 316241.22 4036720.12 316242.78 4036717.36 316243.13 4036717.54 316243.39 4036717.11 316244.64 4036717.68 316246.6 4036714.03 316245.5 4036713.39 316246.32 4036711.89 316246.64 4036712.07 316247.72 4036710.02 316247.03 4036709.65 316248.84 4036706.27 316249.55 4036706.68 316250.7 4036704.66 316250.4 4036704.5 316252.18 4036701.09 316252.59 4036701.26 316253.64 4036699.23 316252.94 4036698.86 316254.52 4036695.74 316254.68 4036695.42 316255.33 4036695.74 316255.51 4036695.83 316255.56 4036695.74 316256.64 4036693.78 316256.37 4036693.62 316257.13 4036692.19 316258.27 4036692.8 316260.26 4036689.06 316259.1 4036688.44 316259.3 4036687.94 316259.03 4036687.79 316260.51 4036684.96 316261.25 4036685.32 316263.23 4036681.57 316262 4036680.9 316262.21 4036680.49 316262.55 4036679.83 316263.19 4036680.11 316263.75 4036679.05 316264.99 4036676.69 316261.3 4036674.92 316260.9 4036675.8 316259.72 4036675.21 316260.27 4036674.13 316259.89 4036673.94 316259.57 4036673.76 316257.46 4036672.63 316257.68 4036672.18 316257.16 4036671.89 316257.74 4036670.85 316257.81 4036670.73 316257.86 4036670.72 316254.13 4036668.72 316254.11 4036668.68 316253.94 4036669.05 316249.9 4036666.9 316249.66 4036667.34 316248.43 4036666.67 316246.63 4036665.69 316245.65 4036667.54 316244.63 4036669.46 316247.62 4036671.07 316246.39 4036673.33 316249.95 4036675.18 316248.05 4036678.81 316251.99 4036680.89 316250.7 4036683.3 316250.25 4036683.07 316247.8 4036687.58 316243.37 4036695.74 316240.19 4036701.6 316236.67 4036707.92 316234.08 4036712.58 316234.49 4036712.8 316233.28 4036715.22 316229.23 4036713.02 316229.02 4036713.54 316228.97 4036713.51 316226.02 4036711.8 316225.77 4036712.25 316222.62 4036710.52 316223.81 4036708.35 316223.34 4036708.1 316224.63 4036705.8 316221.15 4036703.93 316219.89 4036706.17 316219.49 4036705.94 316218.2 4036708.22 316215.2 4036706.51 316215.44 4036706.09 316212.63 4036704.56 316212.97 4036704.14 316208.86 4036701.82 316210.14 4036699.51 316210.67 4036699.8 316212.89 4036695.74 316213.23 4036695.12 316220.82 4036681.23 316224.29 4036674.91 316226.83 4036670.29 316226.01 4036669.84 316227.26 4036667.5 316231.66 4036669.85 316233.55 4036666.29 316237.12 4036668.17 316238.25 4036666.01 316241.26 4036667.69 316242.3 4036665.71 316243.26 4036663.88 316241.48 4036662.89 316240.2 4036662.18 316240.46 4036661.72 316236.53 4036659.6 316236.77 4036659.18 316233.06 4036657.2 316232.43 4036658.48 316231.9 4036658.22 316231.76 4036658.5 316228.67 4036656.83 316227.99 4036656.47 316227.36 4036657.56 316226.8 4036657.25 316227.12 4036656.72 316223.76 4036655.05 316223.02 4036656.49 316222.29 4036657.92 316222.65 4036658.17 316222.38 4036658.68 316222.1 4036659.19 316220.79 4036658.52 316218.81 4036662.22 316219.53 4036662.65 316218.07 4036665.46 316217.67 4036665.23 316217.36 4036665.71 316216.1 4036664.98 316214.08 4036668.7 316215.37 4036669.37 316214.64 4036670.81 316214.17 4036670.57 316213.05 4036672.71 316213.83 4036673.13 316212.05 4036676.45 316211.26 4036676.01 316210.07 4036678.12 316210.54 4036678.32 316208.6 4036681.72 316208.16 4036681.49 316207.11 4036683.51 316207.82 4036683.89 316206.09 4036687.25 316205.23 4036686.82 316204.11 4036689.01 316204.49 4036689.21 316203.77 4036690.62 316202.54 4036689.98 316200.62 4036693.57 316201.76 4036694.18 316201.46 4036694.73 316201.99 4036695.01 316201.59 4036695.74 316200.45 4036697.85 316199.6 4036697.39 316197.54 4036701.15 316198.85 4036701.87 316198.64 4036702.25 316198.31 4036702.86 316197.84 4036702.6 316197.12 4036703.92 316196.27 4036705.49 316199.47 4036707.24 316199.7 4036706.8 316200.44 4036707.21 316199.88 4036708.27 316200.44 4036708.57 316202.79 4036709.84 316203.14 4036709.25 316203.78 4036709.61</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">316212.23 4036744.01 316201.56 4036763.83 316204.25 4036765.26 316207.99 4036757.87 316208.43 4036758.08 316215.06 4036745.53 316212.23 4036744.01</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="210">316237.38 4036647.82 316237.88 4036648.11 316237.16 4036649.39 316240.78 4036651.47 316241.19 4036650.7 316244.21 4036652.3 316244.03 4036652.63 316244.54 4036652.91 316243.88 4036654.09 316247.54 4036656.13 316248.48 4036654.43 316252.66 4036656.74 316251.74 4036658.4 316255.61 4036660.54 316256.32 4036659.23 316256.82 4036659.5 316257.02 4036659.12 316259.79 4036660.58 316259.34 4036661.42 316263.06 4036663.41 316263.72 4036662.16 316264.34 4036662.48 316264.9 4036662.78 316264.61 4036663.31 316266.88 4036664.55 316267.36 4036664.81 316267.89 4036663.82 316268.5 4036664.14 316268.21 4036664.67 316271.68 4036666.57 316271.99 4036665.99 316273.29 4036663.61 316272.9 4036663.4 316273.23 4036662.78 316273.55 4036662.18 316274.97 4036662.93 316276.82 4036659.42 316275.98 4036658.98 316277.54 4036655.99 316277.89 4036656.17 316278.07 4036655.81 316279.41 4036656.48 316281.42 4036652.71 316280.11 4036652.01 316280.18 4036651.9 316282.01 4036648.53 316282.29 4036648.01 316281.99 4036647.84 316282.66 4036646.62 316283.54 4036644.96 316284.34 4036645.34 316285.46 4036643.29 316285.08 4036643.13 316286.57 4036640.25 316286.85 4036639.71 316287.29 4036639.94 316288.3 4036637.86 316287.62 4036637.46 316288.61 4036635.62 316289.32 4036634.08 316290.33 4036634.57 316291.41 4036632.54 316290.99 4036632.34 316291.72 4036630.83 316293.03 4036631.51 316295.03 4036627.81 316293.68 4036627.17 316293.79 4036626.93 316293.4 4036626.75 316295.16 4036623.55 316295.94 4036623.96 316297.9 4036620.3 316296.91 4036619.74 316299.21 4036615.66 316295.95 4036613.83 316295.57 4036614.51 316294.68 4036613.99 316295.27 4036612.97 316292.12 4036611.32 316292.39 4036610.79 316291.77 4036610.46 316292.37 4036609.34 316288.72 4036607.4 316288.52 4036607.75 316286.56 4036606.63 316284.76 4036605.6 316284.43 4036606.16 316283.08 4036605.42 316281.19 4036604.39 316280.22 4036606.23 316279.2 4036608.18 316282.33 4036609.84 316281.09 4036612.15 316284.55 4036613.94 316282.7 4036617.47 316286.56 4036619.6 316286.62 4036619.63 316286.56 4036619.75 316285.35 4036622.11 316284.83 4036621.88 316282.27 4036626.43 316275.74 4036638.45 316273.21 4036643.13 316269.09 4036650.78 316267.82 4036650.04 316266.22 4036652.94 316264.03 4036651.6 316263.57 4036652.34 316260.78 4036650.59 316260.5 4036651.11 316257.33 4036649.35 316258.56 4036647.07 316258.02 4036646.78 316259.23 4036644.7 316254.77 4036642.32 316253.58 4036644.45 316253.18 4036644.25 316251.82 4036646.61 316248.84 4036644.85 316249.09 4036644.45 316246.29 4036642.88 316246.64 4036642.46 316242.54 4036640.09 316243.86 4036637.8 316244.39 4036638.1 316246.7 4036633.98 316247 4036633.43 316255.28 4036617.95 316257.86 4036613.06 316260.33 4036608.37 316259.98 4036608.19 316261.25 4036605.88 316265.31 4036608.03 316267.14 4036604.61 316270.7 4036606.49 316271.9 4036604.16 316274.94 4036605.81 316275.98 4036603.91 316277 4036602.06 316275.14 4036601.06 316273.96 4036600.43 316274.12 4036600 316270.28 4036597.9 316270.48 4036597.4 316266.68 4036595.47 316266.09 4036596.55 316265.55 4036596.33 316265.35 4036596.71 316262.91 4036595.34 316262.41 4036595.06 316262.15 4036594.91 316261.9 4036595.34 316261.55 4036595.95 316260.48 4036595.33 316260.89 4036594.61 316258.03 4036592.98 316256.99 4036594.79 316256.68 4036595.34 316256.2 4036596.18 316256.47 4036596.33 316256.1 4036596.99 316255.82 4036597.48 316254.48 4036596.71 316252.43 4036600.4 316253.33 4036600.83 316251.73 4036603.73 316251.36 4036603.53 316251.12 4036603.96 316249.83 4036603.26 316247.77 4036607.03 316249.13 4036607.75 316248.37 4036609.16 316247.85 4036608.91 316246.75 4036610.93 316247.51 4036611.37 316245.76 4036614.72 316245.21 4036614.43 316244.05 4036616.41 316244.52 4036616.61 316242.54 4036619.99 316242.11 4036619.75 316241.03 4036621.76 316241.74 4036622.15 316239.96 4036625.49 316239.11 4036625.04 316237.96 4036627.22 316238.34 4036627.43 316237.6 4036628.83 316236.38 4036628.17 316234.42 4036631.74 316235.55 4036632.36 316235.24 4036632.91 316235.76 4036633.2 316234.19 4036636.02 316233.35 4036635.55 316231.24 4036639.28 316232.54 4036640.01 316232.33 4036640.39 316231.99 4036641 316231.52 4036640.74 316230.78 4036642.05 316229.91 4036643.61 316233.1 4036645.39 316233.34 4036644.96 316234.07 4036645.37 316233.5 4036646.43 316234.05 4036646.73 316236.39 4036648.04 316236.74 4036647.45 316237.38 4036647.82</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="61">316236.27 4036562.46 316234.4 4036565.89 316233.86 4036566.89 316234.24 4036567.09 316233.56 4036568.37 316237.36 4036570.43 316238.05 4036569.13 316238.51 4036569.37 316238.73 4036568.93 316241.58 4036570.56 316241.15 4036571.34 316244.85 4036573.44 316245.56 4036572.1 316246.04 4036572.34 316246.79 4036572.71 316246.48 4036573.3 316249.33 4036574.81 316249.84 4036573.79 316250.74 4036574.3 316250.52 4036574.67 316253.61 4036576.5 316255.17 4036573.58 316254.66 4036573.3 316255.03 4036572.7 316255.31 4036572.24 316256.61 4036572.83 316258.6 4036569.15 316257.77 4036568.7 316259.28 4036565.87 316259.69 4036566.09 316259.95 4036565.59 316261.29 4036566.28 316263.2 4036562.55 316261.96 4036561.91 316262.81 4036560.34 316263.33 4036560.6 316264.35 4036558.64 316263.61 4036558.28 316265.35 4036554.89 316266.15 4036555.29 316267.25 4036553.27 316266.82 4036553.06 316268.56 4036549.83 316269.07 4036550.14 316270.07 4036548.06 316269.41 4036547.7 316270.25 4036546.03 316270.36 4036545.81 316261.59 4036541.03 316253.12 4036556.41 316250.53 4036561.11 316251.09 4036561.42 316249.79 4036563.76 316245.84 4036561.54 316245.49 4036562.12 316243.08 4036560.83 316243.48 4036560.34 316238.75 4036557.74 316235.16 4036555.9 316232.74 4036560.5 316236.27 4036562.46</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="149">316271.32 4036586.08 316271.72 4036586.29 316271.01 4036587.64 316274.62 4036589.6 316275.12 4036588.88 316278.07 4036590.38 316277.81 4036590.86 316278.24 4036591.04 316277.58 4036592.26 316281.3 4036594.23 316282.27 4036592.43 316286.56 4036594.76 316287.63 4036595.34 316289.08 4036596.13 316288.16 4036598.01 316291.82 4036599.95 316292.45 4036598.77 316293.09 4036599.08 316293.25 4036598.7 316296.05 4036600.23 316295.62 4036601.01 316299.39 4036602.97 316300.01 4036601.72 316300.62 4036602.02 316301.21 4036602.31 316300.8 4036603.09 316303.64 4036604.57 316304.21 4036603.45 316304.91 4036603.8 316304.72 4036604.34 316308.07 4036606.2 316308.13 4036606.19 316308.25 4036605.94 316309.59 4036603.27 316309.17 4036603.06 316309.52 4036602.36 316309.79 4036601.81 316311.04 4036602.42 316313.02 4036598.87 316312.22 4036598.36 316313.7 4036595.51 316314.2 4036595.77 316314.42 4036595.33 316315.75 4036595.99 316316.11 4036595.34 316317.78 4036592.34 316316.56 4036591.64 316317.42 4036590.11 316317.75 4036590.31 316318.75 4036588.28 316318.18 4036587.98 316319.06 4036586.29 316319.97 4036584.56 316320.7 4036584.96 316321.82 4036582.91 316321.75 4036582.91 316321.42 4036582.69 316321.91 4036581.84 316323.17 4036579.65 316323.6 4036579.81 316324.6 4036577.78 316324.24 4036577.58 316324.47 4036577.2 316323.2 4036576.49 316323.55 4036575.79 316324.31 4036576.24 316324.7 4036575.48 316326.27 4036572.46 316324.58 4036571.44 316325.06 4036570.57 316324.64 4036570.35 316320.58 4036568.23 316320.12 4036569.07 316317.57 4036567.82 316310.19 4036581.3 316307.55 4036586.14 316305 4036590.82 316305.45 4036591.06 316304.15 4036593.41 316300.22 4036591.22 316299.96 4036591.82 316297.09 4036590.17 316296.76 4036590.66 316293.55 4036588.98 316294.95 4036586.58 316294.4 4036586.26 316295.64 4036584.12 316288.65 4036580.22 316287.43 4036582.4 316286.98 4036582.14 316286.56 4036582.97 316285.78 4036584.51 316282.88 4036582.91 316283.16 4036582.47 316280.05 4036580.86 316280.33 4036580.3 316276.33 4036578.3 316277.68 4036575.92 316278.25 4036576.2 316280.68 4036571.48 316286.56 4036560.99 316289.72 4036555.36 316286.56 4036553.64 316284.82 4036552.69 316284.37 4036553.48 316282.79 4036552.58 316283.2 4036551.85 316280.73 4036550.48 316280.33 4036551.28 316279.64 4036552.65 316279.2 4036552.43 316278.87 4036553.03 316278.52 4036552.83 316277.49 4036554.86 316277.81 4036555.01 316276.66 4036557.15 316276.13 4036558.15 316275.69 4036557.91 316274.62 4036559.86 316275.39 4036560.28 316274.41 4036562.07 316273.52 4036563.7 316272.79 4036563.3 316271.72 4036565.24 316272.09 4036565.44 316271.23 4036567.01 316270.07 4036566.37 316268.05 4036570.02 316269.24 4036570.68 316268.92 4036571.25 316269.46 4036571.53 316268.03 4036574.32 316267.1 4036573.84 316267 4036574.01 316265.09 4036577.41 316266.37 4036578.15 316266.06 4036578.68 316265.71 4036579.29 316265.15 4036578.97 316263.94 4036581.42 316263.71 4036581.88 316266.75 4036583.6 316267.01 4036583.12 316267.81 4036583.55 316267.23 4036584.61 316267.91 4036584.98 316269.94 4036586.09 316270.24 4036585.52 316271.32 4036586.08</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>123</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>122</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6368301UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">19077</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465301UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316273.27 4036333.05</gml:lowerCorner>
         <gml:upperCorner>316327.98 4036396.66</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465301&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465301UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465301UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465301UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465301UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465301UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="24">316279.35 4036386.43 316276.94 4036389.13 316286.03 4036396.66 316286.56 4036396.01 316287.76 4036394.54 316291.4 4036390.08 316306.42 4036371.68 316323.69 4036350.82 316327.98 4036345.65 316312.85 4036333.05 316311.23 4036334.83 316310.72 4036334.39 316309.37 4036335.99 316321.19 4036346.02 316319.97 4036347.55 316309.73 4036339.02 316308.45 4036337.96 316304.42 4036342.63 316304.91 4036343.12 316294.14 4036356.11 316286.56 4036365.35 316273.27 4036381.56 316274.15 4036382.27 316279.35 4036386.43</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9">316283.44 4036344.11 316281.53 4036346.25 316278.19 4036350.26 316280.94 4036352.4 316275.43 4036359.13 316276.87 4036360.27 316277.79 4036361.08 316288.12 4036348.48 316283.44 4036344.11</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>47</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>46</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465301UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">4457</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465501UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316299.21 4036395.16</gml:lowerCorner>
         <gml:upperCorner>316308.13 4036401.26</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465501&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465501UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465501UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465501UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465501UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465501UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="11">316307.3 4036398.54 316308.13 4036398.22 316308.02 4036397.95 316306.85 4036395.16 316306.46 4036395.28 316306.02 4036395.45 316299.21 4036398.14 316300.44 4036401.26 316300.92 4036401.06 316304.22 4036399.78 316307.3 4036398.54</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465501UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">30</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465502UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316300.92 4036398.22</gml:lowerCorner>
         <gml:upperCorner>316309.71 4036404.78</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465502&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465502UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465502UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465502UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465502UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465502UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="11">316308.95 4036402.53 316309.71 4036402.23 316308.13 4036398.22 316307.3 4036398.54 316304.22 4036399.78 316300.92 4036401.06 316302.47 4036404.78 316305.57 4036403.66 316305.61 4036403.92 316308.77 4036402.6 316308.95 4036402.53</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465502UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">38</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465503UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316301.48 4036402.6</gml:lowerCorner>
         <gml:upperCorner>316309.81 4036408.35</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465503&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465503UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465503UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465503UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465503UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465503UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">316309.32 4036405.46 316309.81 4036405.26 316308.77 4036402.6 316308.23 4036402.83 316305.61 4036403.92 316305.57 4036403.66 316302.47 4036404.78 316301.48 4036405.18 316302.76 4036408.35 316303.29 4036408.13 316306.55 4036406.79 316306.51 4036406.62 316309.32 4036405.46</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465503UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">28</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465504UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316303.29 4036405.03</gml:lowerCorner>
         <gml:upperCorner>316312.09 4036411.82</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465504&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465504UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465504UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465504UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465504UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465504UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="12">316311.52 4036409.41 316312.09 4036409.18 316310.4 4036405.03 316309.81 4036405.26 316306.51 4036406.62 316306.55 4036406.79 316303.29 4036408.13 316304.82 4036411.82 316307.92 4036410.7 316308.01 4036410.94 316311.13 4036409.57 316311.52 4036409.41</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465504UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">36</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465505UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316303.84 4036409.57</gml:lowerCorner>
         <gml:upperCorner>316312.2 4036415.4</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465505&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465505UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465505UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465505UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465505UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465505UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">316311.51 4036412.54 316312.2 4036412.25 316311.13 4036409.57 316310.47 4036409.86 316308.01 4036410.94 316307.92 4036410.7 316304.82 4036411.82 316303.84 4036412.22 316305.14 4036415.4 316305.6 4036415.21 316308.99 4036413.85 316308.92 4036413.63 316311.51 4036412.54</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465505UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">29</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465506UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316305.6 4036412.04</gml:lowerCorner>
         <gml:upperCorner>316314.41 4036419.09</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465506&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465506UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465506UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465506UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465506UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465506UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9">316313.79 4036416.37 316314.41 4036416.11 316312.73 4036412.04 316312.2 4036412.25 316308.92 4036413.63 316308.99 4036413.85 316305.6 4036415.21 316307.2 4036419.09 316313.79 4036416.37</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465506UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">35</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465507UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316323.29 4036407.56</gml:lowerCorner>
         <gml:upperCorner>316331.58 4036415.91</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465507&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465507UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465507UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465507UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465507UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465507UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="11">316330.62 4036410.56 316331.58 4036409.2 316331.11 4036408.85 316330.54 4036409.6 316328.02 4036407.56 316327.53 4036408.21 316323.29 4036413.88 316326.01 4036415.91 316326.65 4036415.04 316327.2 4036415.44 316330.62 4036410.56</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465507UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">29</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465508UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316327.2 4036409.2</gml:lowerCorner>
         <gml:upperCorner>316334.7 4036417.41</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465508&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465508UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465508UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465508UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465508UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465508UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="10">316334.15 4036412.27 316334.44 4036411.87 316334.7 4036411.52 316331.58 4036409.2 316330.99 4036410.05 316327.2 4036415.44 316329.88 4036417.41 316332.1 4036414.7 316332.29 4036414.87 316334.15 4036412.27</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465508UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">41</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465509UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316329.53 4036411.87</gml:lowerCorner>
         <gml:upperCorner>316337.68 4036420.68</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465509&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465509UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465509UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465509UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465509UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465509UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">316337.21 4036414.97 316337.68 4036414.37 316334.44 4036411.87 316333.91 4036412.61 316332.29 4036414.87 316332.1 4036414.7 316329.88 4036417.41 316329.53 4036417.88 316333.29 4036420.68 316333.6 4036420.25 316335.64 4036417.54 316335.41 4036417.3 316337.21 4036414.97</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465509UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">37</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465510UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316333.6 4036414.02</gml:lowerCorner>
         <gml:upperCorner>316341.62 4036422.58</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465510&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465510UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465510UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465510UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465510UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465510UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">316341.23 4036417.3 316341.62 4036416.79 316337.95 4036414.02 316337.68 4036414.37 316337.45 4036414.67 316335.41 4036417.3 316335.64 4036417.54 316333.6 4036420.25 316336.83 4036422.58 316338.83 4036420.05 316339.09 4036420.25 316340.97 4036417.65 316341.23 4036417.3</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465510UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">39</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465511UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316336.06 4036417.65</gml:lowerCorner>
         <gml:upperCorner>316343.97 4036426.1</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465511&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465511UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465511UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465511UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465511UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465511UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="12">316343.66 4036420.54 316343.97 4036420.13 316343.41 4036419.53 316340.97 4036417.65 316340.54 4036418.24 316339.09 4036420.25 316338.83 4036420.05 316336.83 4036422.58 316336.06 4036423.64 316338.73 4036425.58 316339.49 4036426.1 316343.66 4036420.54</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465511UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">29</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465512UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316348.78 4036421.9</gml:lowerCorner>
         <gml:upperCorner>316353.63 4036430.07</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465512&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465512UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465512UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465512UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465512UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465512UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="10">316353.49 4036423.22 316353.63 4036422.46 316353.17 4036422.46 316350.12 4036421.9 316349.99 4036422.66 316348.78 4036429.48 316352.16 4036430.07 316352.32 4036429.15 316353.02 4036425.62 316353.49 4036423.22</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465512UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">29</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465513UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316352.32 4036421.64</gml:lowerCorner>
         <gml:upperCorner>316357.93 4036429.83</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465513&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465513UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465513UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465513UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465513UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465513UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="11">316357.81 4036423.06 316357.84 4036422.86 316357.93 4036422.24 316353.79 4036421.64 316353.63 4036422.46 316353.02 4036425.62 316352.32 4036429.15 316356.24 4036429.83 316356.88 4036426.28 316357.26 4036426.34 316357.81 4036423.06</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465513UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">39</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465514UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316356.14 4036422.86</gml:lowerCorner>
         <gml:upperCorner>316362.03 4036430.95</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465514&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465514UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465514UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465514UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465514UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465514UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="14">316361.93 4036424.39 316361.96 4036424.21 316361.92 4036424.08 316362.03 4036423.5 316357.84 4036422.86 316357.7 4036423.68 316357.26 4036426.34 316356.88 4036426.28 316356.24 4036429.83 316356.14 4036430.36 316360.46 4036430.95 316361.07 4036427.52 316361.45 4036427.55 316361.93 4036424.39</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465514UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">35</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465515UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316360.37 4036424.21</gml:lowerCorner>
         <gml:upperCorner>316366.06 4036432.21</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465515&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465515UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465515UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465515UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465515UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465515UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">316365.93 4036425.56 316366.06 4036424.87 316361.96 4036424.21 316361.85 4036424.93 316361.45 4036427.55 316361.07 4036427.52 316360.46 4036430.95 316360.37 4036431.58 316364.83 4036432.21 316364.94 4036431.42 316365.77 4036428.04 316365.48 4036428.01 316365.93 4036425.56</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465515UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">37</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465516UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316364.94 4036424.13</gml:lowerCorner>
         <gml:upperCorner>316370.4 4036431.95</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465516&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465516UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465516UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465516UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465516UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465516UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="11">316370.27 4036425.53 316370.4 4036424.87 316366.2 4036424.13 316366.06 4036424.87 316365.48 4036428.01 316365.77 4036428.04 316364.94 4036431.42 316367.36 4036431.75 316368.62 4036431.95 316369.03 4036431.92 316370.27 4036425.53</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465516UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">32</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465517UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316386.96 4036438.35</gml:lowerCorner>
         <gml:upperCorner>316392.34 4036446.85</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465517&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465517UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465517UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465517UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465517UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465517UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9">316387.14 4036439.96 316389.31 4036446.85 316392.34 4036445.86 316391.32 4036442.35 316391.47 4036442.29 316390.26 4036438.84 316390.1 4036438.35 316386.96 4036439.41 316387.14 4036439.96</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465517UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">32</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465518UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316390.26 4036437.45</gml:lowerCorner>
         <gml:upperCorner>316396.59 4036446.3</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465518&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465518UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465518UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465518UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465518UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465518UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">316390.51 4036439.55 316391.47 4036442.29 316391.32 4036442.35 316392.34 4036445.86 316392.5 4036446.3 316396.59 4036444.99 316395.58 4036441.66 316395.75 4036441.62 316394.79 4036438.47 316394.67 4036438.09 316394.45 4036437.45 316390.26 4036438.84 316390.51 4036439.55</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465518UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">37</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465519UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316394.79 4036437.12</gml:lowerCorner>
         <gml:upperCorner>316401.01 4036445.93</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465519&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465519UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465519UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465519UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465519UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465519UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">316394.97 4036439.05 316395.75 4036441.62 316395.58 4036441.66 316396.59 4036444.99 316396.8 4036445.93 316401.01 4036444.6 316399.94 4036441.16 316400.19 4036441.07 316399.07 4036437.75 316399.02 4036437.6 316398.86 4036437.12 316394.79 4036438.47 316394.97 4036439.05</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465519UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">36</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465520UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316399.02 4036436.59</gml:lowerCorner>
         <gml:upperCorner>316404.03 4036445.04</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465520&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465520UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465520UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465520UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465520UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465520UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">316399.24 4036438.25 316400.19 4036441.07 316399.94 4036441.16 316401.01 4036444.6 316401.17 4036445.04 316404.03 4036444.07 316403.1 4036440.93 316403.29 4036440.88 316402.32 4036437.39 316402.24 4036437.15 316402.05 4036436.59 316399.02 4036437.6 316399.24 4036438.25</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465520UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">31</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465521UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316402.32 4036436.4</gml:lowerCorner>
         <gml:upperCorner>316407.25 4036444.79</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465521&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465521UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465521UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465521UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465521UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465521UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">316402.49 4036437.98 316403.29 4036440.88 316403.1 4036440.93 316404.03 4036444.07 316404.27 4036444.79 316407.25 4036443.79 316406.27 4036440.51 316406.43 4036440.47 316405.53 4036437.2 316405.47 4036437.01 316405.26 4036436.4 316402.32 4036437.39 316402.49 4036437.98</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465521UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">26</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465522UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316405.53 4036435.94</gml:lowerCorner>
         <gml:upperCorner>316411.77 4036444.61</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465522&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465522UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465522UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465522UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465522UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465522UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="10">316405.69 4036437.76 316406.43 4036440.47 316406.27 4036440.51 316407.25 4036443.79 316407.52 4036444.61 316411.77 4036443.2 316409.53 4036436.45 316409.36 4036435.94 316405.53 4036437.2 316405.69 4036437.76</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465522UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">38</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465523UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316409.33 4036407.3</gml:lowerCorner>
         <gml:upperCorner>316416.48 4036416.04</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465523&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465523UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465523UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465523UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465523UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465523UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="10">316409.59 4036409.45 316412.2 4036416.04 316416.48 4036414.34 316416.27 4036413.82 316414.96 4036410.64 316414.64 4036410.75 316413.44 4036407.92 316413.18 4036407.3 316409.33 4036408.8 316409.59 4036409.45</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465523UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">38</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465524UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316413.05 4036405.76</gml:lowerCorner>
         <gml:upperCorner>316419.14 4036413.82</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465524&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465524UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465524UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465524UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465524UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465524UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">316413.32 4036407.62 316414.64 4036410.75 316414.96 4036410.64 316416.27 4036413.82 316419.14 4036412.66 316418.74 4036411.69 316417.53 4036408.49 316417.17 4036408.65 316416.24 4036406.38 316415.99 4036405.76 316413.05 4036406.97 316413.18 4036407.3 316413.32 4036407.62</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465524UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">28</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465525UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316415.6 4036403.19</gml:lowerCorner>
         <gml:upperCorner>316422.64 4036411.69</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465525&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465525UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465525UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465525UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465525UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465525UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">316415.84 4036405.38 316415.99 4036405.76 316417.17 4036408.65 316417.53 4036408.49 316418.74 4036411.69 316422.64 4036410.07 316422.47 4036409.66 316421.28 4036406.41 316420.86 4036406.49 316419.75 4036403.78 316419.5 4036403.19 316415.6 4036404.82 316415.84 4036405.38</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465525UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">33</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465526UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316419.29 4036401.33</gml:lowerCorner>
         <gml:upperCorner>316425.07 4036409.66</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465526&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465526UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465526UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465526UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465526UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465526UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16">316419.6 4036403.42 316420.86 4036406.49 316421.28 4036406.41 316422.47 4036409.66 316423.16 4036409.37 316425.07 4036408.58 316423.97 4036405.45 316424.12 4036405.34 316423.29 4036403.35 316422.87 4036402.32 316422.71 4036401.94 316422.44 4036401.33 316419.29 4036402.69 316419.45 4036403.07 316419.5 4036403.19 316419.6 4036403.42</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465526UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">31</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465527UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316422.87 4036400.59</gml:lowerCorner>
         <gml:upperCorner>316429.53 4036409.61</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465527&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465527UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465527UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465527UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465527UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465527UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="15">316423.11 4036402.9 316423.29 4036403.35 316424.12 4036405.34 316423.97 4036405.45 316425.07 4036408.58 316425.5 4036409.61 316429.53 4036407.92 316428.29 4036404.59 316428.46 4036404.54 316427.17 4036401.28 316427.1 4036401.12 316426.87 4036400.59 316423.32 4036402.12 316422.87 4036402.32 316423.11 4036402.9</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465527UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">35</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465528UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316427.1 4036399.9</gml:lowerCorner>
         <gml:upperCorner>316432.61 4036408.39</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465528&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465528UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465528UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465528UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465528UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465528UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">316427.39 4036401.84 316428.46 4036404.54 316428.29 4036404.59 316429.53 4036407.92 316429.73 4036408.39 316432.61 4036407.16 316431.43 4036404.15 316431.68 4036404.11 316430.4 4036400.95 316430.25 4036400.58 316429.95 4036399.9 316427.1 4036401.12 316427.39 4036401.84</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465528UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">23</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465529UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316430.4 4036399.48</gml:lowerCorner>
         <gml:upperCorner>316437.12 4036408.15</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2009-08-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465529&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465529UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465529UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465529UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465529UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465529UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="11">316430.64 4036401.54 316431.68 4036404.11 316431.43 4036404.15 316432.61 4036407.16 316433.03 4036408.15 316437.12 4036406.41 316434.39 4036399.99 316434.31 4036399.92 316433.85 4036399.48 316430.4 4036400.95 316430.64 4036401.54</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465529UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">37</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465530UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316450.17 4036374.19</gml:lowerCorner>
         <gml:upperCorner>316458.68 4036382.67</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2009-08-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465530&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465530UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465530UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465530UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465530UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465530UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">316458.03 4036380.51 316458.68 4036380.27 316456.35 4036374.19 316455.61 4036374.47 316450.17 4036376.55 316452.42 4036382.67 316458.03 4036380.51</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>4_3_publicServices</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>0</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465530UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">44</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465531UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316447.9 4036365.78</gml:lowerCorner>
         <gml:upperCorner>316455.13 4036375.2</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2009-08-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465531&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465531UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465531UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465531UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465531UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465531UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9">316448.11 4036367.92 316448.31 4036368.47 316450.81 4036375.2 316455.13 4036373.62 316452.39 4036366.33 316452.19 4036365.78 316451.63 4036366 316447.9 4036367.36 316448.11 4036367.92</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465531UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">42</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465532UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316444.86 4036368.47</gml:lowerCorner>
         <gml:upperCorner>316450.81 4036377.15</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2009-08-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465532&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465532UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465532UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465532UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465532UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465532UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">316445.1 4036370.32 316446.19 4036373.11 316445.97 4036373.22 316447.19 4036376.71 316447.35 4036377.15 316450.61 4036375.96 316450.39 4036375.35 316450.81 4036375.2 316448.51 4036369.01 316448.31 4036368.47 316447.47 4036368.78 316444.86 4036369.71 316445.1 4036370.32</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465532UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">29</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465533UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316440.77 4036369.43</gml:lowerCorner>
         <gml:upperCorner>316447.19 4036378.16</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2009-08-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465533&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465533UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465533UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465533UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465533UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465533UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">316440.95 4036371.29 316442 4036373.92 316441.73 4036374.01 316442.83 4036377.11 316443.21 4036378.16 316447.19 4036376.71 316445.97 4036373.22 316446.19 4036373.11 316444.92 4036369.85 316444.86 4036369.71 316444.76 4036369.43 316440.77 4036370.85 316440.95 4036371.29</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465533UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">39</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465534UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316437.1 4036369.82</gml:lowerCorner>
         <gml:upperCorner>316442.83 4036378.09</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2009-08-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465534&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465534UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465534UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465534UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465534UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465534UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">316437.32 4036371.6 316438.66 4036374.95 316438.95 4036374.84 316440.12 4036378.09 316442.83 4036377.11 316441.73 4036374.01 316442 4036373.92 316440.77 4036370.85 316440.61 4036370.39 316440.4 4036369.82 316437.1 4036371 316437.26 4036371.45 316437.32 4036371.6</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465534UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">30</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465535UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316433.1 4036371.45</gml:lowerCorner>
         <gml:upperCorner>316440.35 4036380.37</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2009-08-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465535&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465535UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465535UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465535UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465535UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465535UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="10">316433.34 4036373.58 316435.73 4036380.37 316440.35 4036378.73 316440.12 4036378.09 316438.95 4036374.84 316438.66 4036374.95 316437.5 4036372.05 316437.26 4036371.45 316433.1 4036372.92 316433.34 4036373.58</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465535UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">37</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465536UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316396.55 4036392.4</gml:lowerCorner>
         <gml:upperCorner>316404.03 4036401.26</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465536&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465536UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465536UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465536UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465536UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465536UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9">316403.87 4036394.74 316404.03 4036394.34 316403.02 4036393.81 316399.31 4036392.4 316399.13 4036392.87 316396.55 4036399.64 316400.35 4036400.9 316401.25 4036401.26 316403.87 4036394.74</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465536UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">39</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465537UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316393.23 4036390.75</gml:lowerCorner>
         <gml:upperCorner>316399.31 4036399.64</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465537&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465537UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465537UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465537UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465537UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465537UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="15">316398.89 4036392.25 316399.06 4036391.78 316396.21 4036390.75 316396.07 4036391.15 316395.13 4036393.76 316394.8 4036393.68 316394.48 4036394.54 316393.6 4036396.95 316393.23 4036397.97 316396.14 4036399.02 316396.21 4036399.05 316396.05 4036399.48 316396.55 4036399.64 316399.31 4036392.4 316398.89 4036392.25</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465537UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">28</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465538UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316389.59 4036388.34</gml:lowerCorner>
         <gml:upperCorner>316396.56 4036396.95</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465538&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465538UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465538UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465538UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465538UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465538UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="15">316396.3 4036390.5 316396.56 4036389.75 316392.54 4036388.34 316392.27 4036389.15 316391.43 4036391.64 316391.05 4036391.58 316389.94 4036394.54 316389.82 4036394.87 316389.59 4036395.51 316393.6 4036396.95 316394.48 4036394.54 316394.8 4036393.68 316395.13 4036393.76 316396.21 4036390.75 316396.3 4036390.5</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465538UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">36</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465539UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316387.08 4036386.7</gml:lowerCorner>
         <gml:upperCorner>316392.73 4036394.87</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465539&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465539UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465539UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465539UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465539UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465539UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="14">316392.45 4036388.61 316392.54 4036388.34 316392.73 4036387.77 316389.52 4036386.7 316389.21 4036387.59 316388.06 4036390.6 316388.34 4036390.78 316387.08 4036393.91 316388.88 4036394.54 316389.82 4036394.87 316389.94 4036394.54 316391.05 4036391.58 316391.43 4036391.64 316392.45 4036388.61</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465539UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">28</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465540UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316382.49 4036386.16</gml:lowerCorner>
         <gml:upperCorner>316389.21 4036394.9</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465540&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465540UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465540UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465540UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465540UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465540UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="12">316389 4036388.15 316389.21 4036387.59 316385.12 4036386.16 316384.9 4036386.76 316382.49 4036393.36 316385.74 4036394.54 316386.73 4036394.9 316386.86 4036394.54 316387.08 4036393.91 316388.34 4036390.78 316388.06 4036390.6 316389 4036388.15</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465540UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">39</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465541UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316371.31 4036352.09</gml:lowerCorner>
         <gml:upperCorner>316376 4036360.19</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465541&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465541UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465541UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465541UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465541UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465541UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="10">316375.63 4036352.68 316375.6 4036352.09 316371.42 4036352.46 316371.45 4036352.93 316371.62 4036355.92 316371.31 4036355.91 316371.52 4036359.18 316371.51 4036360.19 316376 4036359.9 316375.63 4036352.68</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465541UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">36</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465542UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316367.77 4036351.41</gml:lowerCorner>
         <gml:upperCorner>316371.62 4036359.26</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465542&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465542UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465542UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465542UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465542UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465542UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">316367.82 4036352.54 316368.12 4036355.81 316368.46 4036355.8 316368.64 4036359.26 316371.52 4036359.18 316371.31 4036355.91 316371.62 4036355.92 316371.42 4036352.46 316371.4 4036352.21 316371.33 4036351.41 316367.77 4036351.65 316367.8 4036352.3 316367.82 4036352.54</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465542UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">31</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465543UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316363.53 4036352.3</gml:lowerCorner>
         <gml:upperCorner>316368.71 4036360.08</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465543&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465543UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465543UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465543UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465543UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465543UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">316363.6 4036353.52 316363.9 4036356.69 316364.16 4036356.65 316364.39 4036360.08 316368.71 4036359.84 316368.64 4036359.26 316368.46 4036355.8 316368.12 4036355.81 316367.89 4036353.28 316367.8 4036352.3 316363.53 4036352.46 316363.56 4036353.1 316363.6 4036353.52</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465543UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">35</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465544UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316360.54 4036352.46</gml:lowerCorner>
         <gml:upperCorner>316364.55 4036361.41</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465544&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465544UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465544UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465544UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465544UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465544UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">316360.56 4036353.69 316360.98 4036360.93 316360.97 4036361.41 316364.55 4036361.12 316364.39 4036360.08 316364.16 4036356.65 316363.9 4036356.69 316363.6 4036353.52 316363.56 4036353.1 316363.53 4036352.46 316360.54 4036352.55 316360.54 4036353.27 316360.56 4036353.69</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465544UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">30</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465545UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316355.75 4036352.55</gml:lowerCorner>
         <gml:upperCorner>316360.98 4036361.72</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465545&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465545UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465545UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465545UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465545UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465545UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="10">316355.8 4036353.83 316356.16 4036361.72 316360.97 4036361.41 316360.98 4036360.93 316360.56 4036353.69 316360.54 4036353.27 316360.54 4036352.55 316358.25 4036352.61 316355.75 4036352.64 316355.8 4036353.83</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465545UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">46</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465546UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316343.96 4036365.51</gml:lowerCorner>
         <gml:upperCorner>316348.54 4036373.49</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465546&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465546UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465546UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465546UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465546UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465546UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">316344.02 4036366.44 316344.81 4036373.49 316348.54 4036373.13 316347.8 4036366.02 316347.75 4036365.51 316343.96 4036365.9 316344.02 4036366.44</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465546UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">36</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465547UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316340.36 4036366.44</gml:lowerCorner>
         <gml:upperCorner>316344.81 4036374.49</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465547&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465547UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465547UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465547UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465547UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465547UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">316340.43 4036367.31 316340.81 4036370.09 316340.52 4036370.1 316340.9 4036373.41 316341 4036374.49 316344.35 4036374.17 316344.29 4036373.54 316344.81 4036373.49 316344.08 4036366.93 316344.02 4036366.44 316343.24 4036366.53 316340.36 4036366.79 316340.43 4036367.31</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465547UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">28</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465548UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316336.64 4036365.87</gml:lowerCorner>
         <gml:upperCorner>316340.9 4036373.77</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465548&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465548UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465548UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465548UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465548UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465548UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="10">316336.71 4036366.9 316337.37 4036373.77 316340.9 4036373.41 316340.52 4036370.1 316340.81 4036370.09 316340.36 4036366.79 316340.34 4036366.57 316340.27 4036365.87 316336.64 4036366.22 316336.71 4036366.9</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465548UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">35</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465549UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316332.83 4036366.22</gml:lowerCorner>
         <gml:upperCorner>316337.37 4036374.13</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465549&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465549UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465549UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465549UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465549UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465549UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="10">316332.89 4036367.25 316332.93 4036367.65 316333.14 4036370.85 316333.45 4036370.81 316333.8 4036374.13 316337.37 4036373.77 316336.71 4036366.9 316336.64 4036366.22 316332.83 4036366.59 316332.89 4036367.25</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465549UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">31</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465550UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316329.34 4036366.59</gml:lowerCorner>
         <gml:upperCorner>316333.91 4036375.57</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465550&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465550UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465550UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465550UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465550UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465550UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="15">316329.42 4036367.57 316330.39 4036375.07 316330.44 4036375.06 316330.49 4036375.57 316333.91 4036375.23 316333.8 4036374.13 316333.45 4036370.81 316333.14 4036370.85 316332.93 4036367.65 316332.89 4036367.25 316332.83 4036366.59 316329.88 4036366.88 316329.34 4036366.93 316329.41 4036367.51 316329.42 4036367.57</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465550UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">32</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465551UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316325.3 4036366.93</gml:lowerCorner>
         <gml:upperCorner>316330.39 4036375.52</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465551&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465551UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465551UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465551UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465551UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465551UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="8">316325.35 4036367.95 316326.15 4036375.52 316330.39 4036375.07 316329.42 4036367.57 316329.41 4036367.51 316329.34 4036366.93 316325.3 4036367.34 316325.35 4036367.95</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465551UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">33</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6465801UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316299.23 4036287.89</gml:lowerCorner>
         <gml:upperCorner>316351.4 4036338.95</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2009-08-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6465801&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6465801UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465801UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465801UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465801UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6465801UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="27">316315.45 4036325.78 316324.39 4036333.3 316325.58 4036331.85 316341.22 4036312.93 316327.25 4036301.34 316327.96 4036300.42 316329.1 4036298.95 316330.5 4036300.03 316334.32 4036295.14 316335.3 4036293.9 316335.84 4036293.27 316335.05 4036292.58 316329.62 4036287.89 316328.94 4036288.61 316323.59 4036295.14 316323.04 4036295.82 316321.98 4036297.12 316307.45 4036314.69 316305.11 4036317.48 316299.23 4036324.51 316301.24 4036326.24 316310.72 4036334.39 316311.23 4036334.83 316312.85 4036333.05 316315.16 4036330.5 316313.03 4036328.73 316315.45 4036325.78</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16">316346.14 4036324.25 316341.15 4036324.27 316337.14 4036329.13 316338.41 4036333.63 316336.06 4036336.57 316336.22 4036337.82 316337.6 4036338.79 316337.83 4036338.95 316340.98 4036335.02 316343.29 4036337.09 316351.06 4036327.69 316348.51 4036325.77 316351.4 4036322.48 316349.71 4036321.32 316348.33 4036321.47 316346.14 4036324.25</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>4_2_retail</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>0</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6465801UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">1227</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466301UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316262.7 4036522.29</gml:lowerCorner>
         <gml:upperCorner>316273.9 4036532.65</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466301&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466301UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466301UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466301UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466301UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466301UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="10">316273.48 4036527.32 316273.9 4036526.38 316265.61 4036522.29 316265.13 4036523.32 316262.7 4036528.53 316271.13 4036532.65 316271.67 4036531.54 316272.9 4036529.09 316272.71 4036529.01 316273.48 4036527.32</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>4</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>4</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466301UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">124</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466302UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316271.67 4036525.25</gml:lowerCorner>
         <gml:upperCorner>316282.82 4036535.64</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466302&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466302UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466302UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466302UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466302UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466302UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">316282.43 4036530.17 316282.82 4036529.33 316274.34 4036525.25 316274.04 4036526.02 316273.9 4036526.38 316272.71 4036529.01 316272.9 4036529.09 316271.67 4036531.54 316280.05 4036535.64 316281.54 4036532.55 316282.26 4036531.09 316282.05 4036530.98 316282.43 4036530.17</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>4</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>4</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466302UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">140</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466303UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316281.54 4036526.23</gml:lowerCorner>
         <gml:upperCorner>316292.92 4036536.64</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466303&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466303UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466303UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466303UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466303UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466303UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="12">316292.41 4036531.45 316292.92 4036530.44 316286.56 4036527.33 316284.31 4036526.23 316283.83 4036527.24 316282.82 4036529.33 316282.05 4036530.98 316282.26 4036531.09 316281.54 4036532.55 316286.56 4036535.04 316289.78 4036536.64 316292.41 4036531.45</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>4</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>4</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466303UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">128</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466304UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316294.82 4036533.76</gml:lowerCorner>
         <gml:upperCorner>316302.47 4036541.33</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466304&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466304UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466304UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466304UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466304UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466304UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">316297.33 4036533.76 316294.82 4036538.77 316295.51 4036539.11 316300.04 4036541.33 316302.47 4036536.32 316298.08 4036534.13 316297.33 4036533.76</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466304UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">35</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466305UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316296.36 4036525.5</gml:lowerCorner>
         <gml:upperCorner>316306.34 4036536.32</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466305&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466305UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466305UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466305UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466305UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466305UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">316297.33 4036533.76 316302.47 4036536.32 316306.34 4036528.56 316301.18 4036526 316300.16 4036525.5 316296.36 4036533.25 316297.33 4036533.76</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>4</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>4</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466305UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">136</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466306UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316300.16 4036516.42</gml:lowerCorner>
         <gml:upperCorner>316310.87 4036528.56</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466306&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466306UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466306UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466306UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466306UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466306UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">316300.91 4036525.87 316306.34 4036528.56 316310.87 4036519.47 316305.32 4036516.76 316304.61 4036516.42 316300.16 4036525.5 316300.91 4036525.87</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>4</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>4</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466306UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">135</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466307UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316323.88 4036538.63</gml:lowerCorner>
         <gml:upperCorner>316328.56 4036546.95</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466307&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466307UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466307UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466307UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466307UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466307UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="10">316324.06 4036540.17 316325.47 4036546.95 316328.56 4036546.3 316327.75 4036542.49 316327.9 4036542.45 316327.4 4036539.46 316327.33 4036539.05 316327.24 4036538.63 316323.88 4036539.34 316324.06 4036540.17</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466307UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">27</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466308UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316327.33 4036538.15</gml:lowerCorner>
         <gml:upperCorner>316332.89 4036546.7</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466308&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466308UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466308UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466308UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466308UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466308UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="11">316327.53 4036540.2 316327.9 4036542.45 316327.75 4036542.49 316328.56 4036546.3 316328.64 4036546.7 316332.89 4036545.84 316331.75 4036539.29 316331.7 4036539.03 316331.51 4036538.15 316327.33 4036539.05 316327.53 4036540.2</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466308UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">40</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466309UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316331.7 4036538.14</gml:lowerCorner>
         <gml:upperCorner>316337.22 4036546.8</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466309&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466309UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466309UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466309UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466309UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466309UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9">316331.87 4036539.97 316332.89 4036545.84 316333.08 4036546.8 316337.22 4036545.98 316336.07 4036539.07 316336 4036538.7 316335.88 4036538.14 316331.7 4036539.03 316331.87 4036539.97</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466309UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">35</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466310UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316336 4036538.07</gml:lowerCorner>
         <gml:upperCorner>316340.4 4036546.4</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466310&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466310UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466310UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466310UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466310UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466310UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="8">316336.15 4036539.58 316337.22 4036545.98 316337.3 4036546.4 316340.4 4036545.8 316339.24 4036538.95 316339.09 4036538.07 316336 4036538.7 316336.15 4036539.58</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466310UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">28</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466311UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316339.24 4036538.33</gml:lowerCorner>
         <gml:upperCorner>316343.63 4036546.75</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466311&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466311UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466311UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466311UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466311UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466311UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9">316339.42 4036539.96 316340.4 4036545.8 316340.56 4036546.75 316343.63 4036546.17 316342.57 4036539.34 316342.47 4036538.75 316342.41 4036538.33 316339.24 4036538.95 316339.42 4036539.96</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466311UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">29</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466312UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316342.47 4036537.95</gml:lowerCorner>
         <gml:upperCorner>316348.15 4036546.47</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466312&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466312UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466312UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466312UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466312UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466312UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="8">316342.62 4036539.71 316343.63 4036546.17 316343.68 4036546.47 316348.15 4036545.72 316346.81 4036538.95 316346.61 4036537.95 316342.47 4036538.75 316342.62 4036539.71</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466312UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">39</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466313UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316344.72 4036505.4</gml:lowerCorner>
         <gml:upperCorner>316350.14 4036513.9</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466313&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466313UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466313UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466313UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466313UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466313UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="10">316344.93 4036507.21 316347.12 4036513.9 316350.14 4036512.9 316349.14 4036509.68 316349.29 4036509.59 316348.34 4036506.09 316348.29 4036505.93 316348.11 4036505.4 316344.72 4036506.6 316344.93 4036507.21</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466313UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">30</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466314UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316348.29 4036504.61</gml:lowerCorner>
         <gml:upperCorner>316354.41 4036513.42</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466314&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466314UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466314UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466314UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466314UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466314UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16">316348.56 4036506.91 316349.29 4036509.59 316349.14 4036509.68 316350.14 4036512.9 316350.31 4036513.42 316354.41 4036512.07 316353.37 4036508.7 316353.61 4036508.61 316352.65 4036505.61 316352.51 4036505.19 316352.32 4036504.61 316348.29 4036505.93 316348.34 4036506.09 316348.35 4036506.09 316348.46 4036506.55 316348.56 4036506.91</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466314UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">40</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466315UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316352.65 4036504.31</gml:lowerCorner>
         <gml:upperCorner>316358.89 4036513.08</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466315&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466315UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466315UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466315UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466315UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466315UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="12">316352.65 4036505.61 316353.61 4036508.61 316353.37 4036508.7 316354.41 4036512.07 316354.74 4036513.08 316358.89 4036511.72 316357.77 4036508.52 316357.96 4036508.48 316356.89 4036504.98 316356.82 4036504.77 316356.67 4036504.31 316352.65 4036505.61</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466315UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">36</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466316UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316356.82 4036503.8</gml:lowerCorner>
         <gml:upperCorner>316361.92 4036512.21</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466316&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466316UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466316UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466316UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466316UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466316UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">316357.04 4036505.48 316357.96 4036508.48 316357.77 4036508.52 316358.89 4036511.72 316359.05 4036512.21 316361.92 4036511.26 316360.92 4036508.04 316361.14 4036507.97 316360.27 4036505.27 316360.11 4036504.8 316359.78 4036503.8 316356.82 4036504.77 316357.04 4036505.48</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466316UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">31</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466317UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316360.11 4036503.84</gml:lowerCorner>
         <gml:upperCorner>316365.23 4036512.2</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466317&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466317UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466317UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466317UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466317UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466317UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="12">316360.27 4036505.27 316361.14 4036507.97 316360.92 4036508.04 316361.92 4036511.26 316362.23 4036512.2 316365.23 4036511.32 316364.14 4036507.88 316364.33 4036507.79 316363.2 4036504.35 316363.03 4036503.84 316360.11 4036504.8 316360.27 4036505.27</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466317UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">29</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466318UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316363.2 4036503.02</gml:lowerCorner>
         <gml:upperCorner>316369.76 4036511.74</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466318&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466318UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466318UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466318UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466318UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466318UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="12">316363.51 4036505.28 316364.33 4036507.79 316364.14 4036507.88 316365.23 4036511.32 316365.35 4036511.74 316369.76 4036510.48 316367.63 4036503.9 316367.51 4036503.52 316367.34 4036503.02 316363.2 4036504.35 316363.38 4036504.88 316363.51 4036505.28</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466318UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">40</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466319UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316383.83 4036468.97</gml:lowerCorner>
         <gml:upperCorner>316390.03 4036477.81</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466319&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466319UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466319UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466319UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466319UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466319UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="12">316384.1 4036471.13 316384.92 4036473.76 316384.57 4036473.86 316385.79 4036477.81 316389.3 4036476.7 316390.03 4036476.49 316388.17 4036469.87 316387.91 4036468.97 316387.55 4036469.08 316387.54 4036469.06 316383.83 4036470.26 316384.1 4036471.13</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466319UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">36</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466320UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316380.51 4036469.82</gml:lowerCorner>
         <gml:upperCorner>316385.7 4036478.39</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466320&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466320UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466320UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466320UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466320UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466320UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16">316380.75 4036471.59 316381.45 4036473.89 316381.22 4036473.96 316382.52 4036478.23 316382.6 4036478.39 316385.32 4036477.61 316385.7 4036477.5 316385.64 4036477.31 316384.57 4036473.86 316384.92 4036473.76 316383.92 4036470.53 316383.83 4036470.26 316383.66 4036469.82 316383.27 4036469.93 316380.51 4036470.78 316380.75 4036471.59</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466320UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">31</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466321UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316376.93 4036469.8</gml:lowerCorner>
         <gml:upperCorner>316382.41 4036478.7</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466321&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466321UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466321UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466321UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466321UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466321UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16">316377.24 4036471.85 316378.04 4036474.33 316377.83 4036474.39 316378.94 4036477.83 316379 4036478.26 316379.13 4036478.7 316382.17 4036477.94 316382.41 4036477.88 316382.25 4036477.34 316381.22 4036473.96 316381.45 4036473.89 316380.51 4036470.78 316380.18 4036469.8 316380.01 4036469.88 316376.93 4036470.89 316377.24 4036471.85</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466321UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">33</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466322UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316372.81 4036470.38</gml:lowerCorner>
         <gml:upperCorner>316378.94 4036479.04</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466322&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466322UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466322UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466322UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466322UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466322UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="12">316372.81 4036471.57 316373.79 4036474.77 316373.47 4036474.88 316374.54 4036478.15 316374.78 4036479.04 316378.94 4036477.83 316377.83 4036474.39 316378.04 4036474.33 316377.05 4036471.25 316376.93 4036470.89 316376.83 4036470.38 316372.81 4036471.57</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466322UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">42</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466323UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316368.36 4036470.63</gml:lowerCorner>
         <gml:upperCorner>316374.54 4036479.45</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466323&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466323UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466323UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466323UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466323UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466323UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="12">316368.66 4036472.91 316369.45 4036475.5 316369.16 4036475.58 316370.2 4036478.97 316370.31 4036479.45 316374.54 4036478.15 316373.47 4036474.88 316373.79 4036474.77 316372.81 4036471.57 316372.58 4036470.63 316368.36 4036471.94 316368.66 4036472.91</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466323UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">41</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466324UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316364.89 4036471.5</gml:lowerCorner>
         <gml:upperCorner>316370.2 4036479.93</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466324&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466324UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466324UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466324UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466324UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466324UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="10">316365.15 4036473.37 316367.22 4036479.93 316370.2 4036478.97 316369.16 4036475.58 316369.45 4036475.5 316368.47 4036472.28 316368.36 4036471.94 316368.26 4036471.5 316364.89 4036472.57 316365.15 4036473.37</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466324UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">29</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466325UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316321.27 4036508.51</gml:lowerCorner>
         <gml:upperCorner>316327.68 4036516.57</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466325&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466325UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466325UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466325UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466325UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466325UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">316327.27 4036511.02 316327.68 4036510.17 316324.27 4036508.51 316323.83 4036509.45 316321.27 4036514.87 316324.62 4036516.57 316327.27 4036511.02</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466325UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">33</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466326UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316317.47 4036506.74</gml:lowerCorner>
         <gml:upperCorner>316324.27 4036514.87</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466326&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466326UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466326UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466326UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466326UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466326UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">316323.83 4036509.45 316324.27 4036508.51 316320.65 4036506.74 316320.2 4036507.62 316317.47 4036512.94 316321.27 4036514.87 316323.83 4036509.45</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466326UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">32</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466327UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316309.28 4036502.7</gml:lowerCorner>
         <gml:upperCorner>316320.65 4036512.94</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466327&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466327UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466327UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466327UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466327UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466327UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">316320.2 4036507.62 316320.65 4036506.74 316312.37 4036502.7 316311.86 4036503.73 316309.28 4036508.88 316317.47 4036512.94 316320.2 4036507.62</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>4</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>4</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466327UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">130</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466328UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316300.67 4036498.45</gml:lowerCorner>
         <gml:upperCorner>316312.37 4036508.88</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466328&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466328UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466328UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466328UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466328UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466328UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">316311.86 4036503.73 316312.37 4036502.7 316303.64 4036498.45 316303.14 4036499.5 316300.67 4036504.62 316309.28 4036508.88 316311.86 4036503.73</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>4</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>4</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466328UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">146</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466329UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316290.24 4036488.44</gml:lowerCorner>
         <gml:upperCorner>316301.64 4036498.75</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466329&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466329UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466329UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466329UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466329UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466329UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9">316301.29 4036493.29 316301.64 4036492.54 316293.41 4036488.44 316292.91 4036489.41 316290.24 4036494.56 316291.01 4036494.94 316298.69 4036498.75 316300.5 4036494.94 316301.29 4036493.29</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>4</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>4</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466329UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">130</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466330UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316281.79 4036484.17</gml:lowerCorner>
         <gml:upperCorner>316293.41 4036494.56</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466330&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466330UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466330UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466330UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466330UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466330UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9">316292.91 4036489.41 316293.41 4036488.44 316286.56 4036485.03 316284.84 4036484.17 316284.4 4036485.07 316281.79 4036490.36 316286.56 4036492.73 316290.24 4036494.56 316292.91 4036489.41</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>4</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>4</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466330UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">130</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466331UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316302.49 4036485.97</gml:lowerCorner>
         <gml:upperCorner>316310.62 4036492.71</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466331&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466331UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466331UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466331UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466331UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466331UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9">316303.63 4036490.11 316308.76 4036492.71 316309.09 4036492.08 316310.62 4036489.03 316305.4 4036486.52 316304.24 4036485.97 316302.72 4036489 316302.49 4036489.54 316303.63 4036490.11</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466331UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">32</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466332UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316304.24 4036482.08</gml:lowerCorner>
         <gml:upperCorner>316312.48 4036489.03</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466332&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466332UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466332UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466332UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466332UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466332UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="8">316305.4 4036486.52 316310.62 4036489.03 316312.19 4036485.88 316312.48 4036485.29 316307.31 4036482.65 316306.19 4036482.08 316304.24 4036485.97 316305.4 4036486.52</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466332UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">32</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466333UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316306.19 4036478.37</gml:lowerCorner>
         <gml:upperCorner>316314.37 4036485.29</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466333&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466333UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466333UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466333UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466333UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466333UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">316307.31 4036482.65 316312.48 4036485.29 316314.37 4036481.53 316309.16 4036478.92 316308.05 4036478.37 316306.19 4036482.08 316307.31 4036482.65</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466333UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">32</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466334UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316308.05 4036474.99</gml:lowerCorner>
         <gml:upperCorner>316316.13 4036481.53</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466334&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466334UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466334UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466334UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466334UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466334UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">316309.16 4036478.92 316314.37 4036481.53 316316.13 4036478.02 316310.84 4036475.51 316309.75 4036474.99 316308.05 4036478.37 316309.16 4036478.92</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466334UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">32</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466335UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316309.75 4036471.21</gml:lowerCorner>
         <gml:upperCorner>316317.94 4036478.02</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466335&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466335UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466335UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466335UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466335UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466335UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">316310.84 4036475.51 316316.13 4036478.02 316317.94 4036474.39 316312.7 4036471.74 316311.64 4036471.21 316309.75 4036474.99 316310.84 4036475.51</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466335UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">32</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466336UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316311.64 4036467.18</gml:lowerCorner>
         <gml:upperCorner>316319.97 4036474.39</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466336&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466336UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466336UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466336UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466336UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466336UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">316312.7 4036471.74 316317.94 4036474.39 316319.97 4036470.34 316314.7 4036467.7 316313.66 4036467.18 316311.64 4036471.21 316312.7 4036471.74</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466336UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">32</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466337UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316322.75 4036453.19</gml:lowerCorner>
         <gml:upperCorner>316329.63 4036461.65</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466337&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466337UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466337UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466337UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466337UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466337UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="10">316329.24 4036455.82 316329.63 4036455.01 316325.86 4036453.19 316325.5 4036453.94 316325.13 4036454.69 316323.9 4036457.17 316324.1 4036457.28 316322.75 4036459.92 316326.42 4036461.65 316329.24 4036455.82</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466337UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">33</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466338UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316318.46 4036452.99</gml:lowerCorner>
         <gml:upperCorner>316325.13 4036460.85</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466338&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466338UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466338UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466338UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466338UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466338UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">316324.81 4036455.33 316325.13 4036454.69 316321.64 4036452.99 316321.37 4036453.59 316320.48 4036455.54 316320.2 4036455.42 316319.01 4036457.88 316318.46 4036458.99 316322.29 4036460.85 316322.75 4036459.92 316324.1 4036457.28 316323.9 4036457.17 316324.81 4036455.33</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466338UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">32</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466339UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316315.7 4036450</gml:lowerCorner>
         <gml:upperCorner>316322.26 4036457.88</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466339&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466339UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466339UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466339UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466339UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466339UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="11">316321.85 4036452.56 316322.26 4036451.71 316318.73 4036450 316318.26 4036450.96 316318.16 4036451.17 316315.7 4036456.26 316319.01 4036457.88 316320.2 4036455.42 316320.48 4036455.54 316321.64 4036452.99 316321.85 4036452.56</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466339UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">34</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466340UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316306.93 4036447.19</gml:lowerCorner>
         <gml:upperCorner>316318.16 4036457.34</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466340&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466340UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466340UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466340UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466340UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466340UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="8">316317.77 4036451.97 316318.16 4036451.17 316309.99 4036447.19 316309.58 4036448.01 316306.93 4036453.29 316315.17 4036457.34 316315.7 4036456.26 316317.77 4036451.97</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>4</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>4</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466340UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">138</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466341UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316298.3 4036442.93</gml:lowerCorner>
         <gml:upperCorner>316309.99 4036453.29</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466341&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466341UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466341UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466341UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466341UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466341UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9">316309.58 4036448.01 316309.99 4036447.19 316301.77 4036443.18 316301.24 4036442.93 316300.83 4036443.78 316298.8 4036447.98 316298.3 4036449.04 316306.93 4036453.29 316309.58 4036448.01</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>4</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>4</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466341UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">138</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466342UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316295.06 4036439.7</gml:lowerCorner>
         <gml:upperCorner>316302.58 4036448.85</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466342&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466342UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466342UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466342UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466342UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466342UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17">316302.13 4036442.43 316302.29 4036442.1 316302.46 4036441.79 316302.58 4036441.61 316298.81 4036439.7 316298.66 4036439.87 316298.44 4036440.24 316298.29 4036440.55 316298.03 4036441.07 316297.45 4036442.27 316295.41 4036446.4 316295.06 4036447.22 316298.39 4036448.85 316298.8 4036447.98 316301.24 4036442.93 316301.77 4036443.18 316302.13 4036442.43</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466342UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">34</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466343UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316290.98 4036439.19</gml:lowerCorner>
         <gml:upperCorner>316298.03 4036447.74</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466343&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466343UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466343UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466343UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466343UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466343UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="14">316297.67 4036441.81 316298.03 4036441.07 316294.23 4036439.19 316293.81 4036440.16 316293.11 4036441.8 316292.88 4036441.72 316291.74 4036444.27 316291.11 4036445.69 316290.98 4036446.02 316294.74 4036447.74 316294.98 4036447.4 316295.41 4036446.4 316297.45 4036442.27 316297.67 4036441.81</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466343UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">32</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466344UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316287.79 4036436.38</gml:lowerCorner>
         <gml:upperCorner>316294.71 4036445.26</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466344&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466344UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466344UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466344UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466344UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466344UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="11">316294.23 4036439.19 316294.71 4036438.21 316290.98 4036436.38 316290.55 4036437.35 316288.18 4036442.7 316287.79 4036443.64 316291.3 4036445.26 316291.74 4036444.27 316292.88 4036441.72 316293.11 4036441.8 316294.23 4036439.19</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466344UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">34</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466345UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316282.36 4036453.92</gml:lowerCorner>
         <gml:upperCorner>316290.61 4036461.14</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466345&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466345UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466345UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466345UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466345UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466345UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">316282.36 4036458.02 316286.56 4036460.12 316288.59 4036461.14 316290.61 4036457.07 316286.56 4036455.04 316284.33 4036453.92 316282.36 4036458.02</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466345UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">31</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466346UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316280.72 4036458.02</gml:lowerCorner>
         <gml:upperCorner>316288.59 4036464.57</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466346&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466346UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466346UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466346UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466346UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466346UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">316280.72 4036461.44 316286.56 4036464.4 316286.89 4036464.57 316288.59 4036461.14 316286.56 4036460.12 316282.36 4036458.02 316280.72 4036461.44</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466346UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">31</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466347UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316279.1 4036461.44</gml:lowerCorner>
         <gml:upperCorner>316286.89 4036468.21</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466347&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466347UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466347UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466347UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466347UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466347UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="10">316279.1 4036464.81 316280.53 4036465.6 316280.4 4036465.86 316283.42 4036467.42 316285.08 4036468.21 316286.56 4036465.23 316286.89 4036464.57 316286.56 4036464.4 316280.72 4036461.44 316279.1 4036464.81</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466347UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">31</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466348UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316271.46 4036463.12</gml:lowerCorner>
         <gml:upperCorner>316282.79 4036475.18</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466348&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466348UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466348UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466348UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466348UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466348UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="10">316272.56 4036472.22 316278.63 4036475.18 316282.79 4036467.08 316280.4 4036465.86 316280.53 4036465.6 316279.1 4036464.81 316276.74 4036463.64 316275.67 4036463.12 316271.46 4036471.68 316272.56 4036472.22</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>4_2_retail</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>0</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466348UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">75</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466349UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316268.73 4036471.68</gml:lowerCorner>
         <gml:upperCorner>316278.63 4036480.68</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466349&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466349UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466349UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466349UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466349UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466349UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="8">316269.86 4036477.76 316275.81 4036480.68 316278.63 4036475.18 316272.56 4036472.22 316271.46 4036471.68 316270.97 4036472.67 316268.73 4036477.21 316269.86 4036477.76</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>4_2_retail</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>0</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466349UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">46</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466350UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316266.79 4036477.21</gml:lowerCorner>
         <gml:upperCorner>316275.81 4036484.39</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466350&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466350UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466350UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466350UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466350UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466350UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9">316267.93 4036481.73 316272.95 4036484.26 316273.1 4036483.97 316273.9 4036484.39 316275.81 4036480.68 316269.86 4036477.76 316268.73 4036477.21 316266.79 4036481.15 316267.93 4036481.73</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>4_2_retail</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>0</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466350UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">30</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466351UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316264.84 4036490.02</gml:lowerCorner>
         <gml:upperCorner>316273.08 4036497.12</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466351&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466351UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466351UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466351UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466351UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466351UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="10">316270.07 4036496.65 316271.02 4036497.12 316272.09 4036494.94 316272.52 4036494.07 316273.08 4036493.02 316272 4036492.5 316266.85 4036490.02 316266.59 4036490.53 316264.84 4036494.07 316270.07 4036496.65</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>2</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>2</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466351UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">72</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466352UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316262.76 4036494.07</gml:lowerCorner>
         <gml:upperCorner>316271.02 4036501.44</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466352&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466352UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466352UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466352UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466352UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466352UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="12">316267.97 4036500.96 316268.88 4036501.44 316269.2 4036500.8 316270.89 4036497.38 316271.02 4036497.12 316270.07 4036496.65 316264.84 4036494.07 316264.75 4036494.24 316264.4 4036494.94 316263.09 4036497.59 316262.76 4036498.25 316267.97 4036500.96</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>2</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>2</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466352UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">76</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466353UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316258.32 4036498.25</gml:lowerCorner>
         <gml:upperCorner>316268.88 4036510.18</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466353&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466353UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466353UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466353UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466353UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466353UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">316263.53 4036509.68 316264.57 4036510.18 316268.88 4036501.44 316267.97 4036500.96 316262.76 4036498.25 316258.32 4036507.18 316263.53 4036509.68</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>4</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>4</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466353UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">142</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466354UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316254.1 4036507.18</gml:lowerCorner>
         <gml:upperCorner>316264.57 4036518.76</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466354&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466354UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466354UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466354UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466354UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466354UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="8">316259.39 4036518.32 316260.33 4036518.76 316264.57 4036510.18 316263.53 4036509.68 316258.32 4036507.18 316254.25 4036515.37 316254.1 4036515.73 316259.39 4036518.32</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>4</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>4</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466354UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">134</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466355UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316251.59 4036514.93</gml:lowerCorner>
         <gml:upperCorner>316259.39 4036521.8</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466355&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466355UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466355UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466355UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466355UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466355UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="11">316256.88 4036521.4 316257.69 4036521.8 316259.39 4036518.32 316258.69 4036517.97 316254.1 4036515.73 316254.25 4036515.37 316253.33 4036514.93 316251.59 4036518.51 316253.93 4036519.74 316253.82 4036519.9 316256.88 4036521.4</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466355UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">32</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6466356UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316248.86 4036518.08</gml:lowerCorner>
         <gml:upperCorner>316256.88 4036525.12</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1967-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1967-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6466356&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6466356UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6466356UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6466356UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6466356UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6466356UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="10">316254.27 4036524.74 316255.02 4036525.12 316256.88 4036521.4 316256.08 4036521 316253.82 4036519.9 316253.93 4036519.74 316251.59 4036518.51 316250.71 4036518.08 316248.86 4036522.05 316254.27 4036524.74</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6466356UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">33</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6467601UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316347.63 4036564.73</gml:lowerCorner>
         <gml:upperCorner>316362.87 4036581.12</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1970-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>2016-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6467601&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6467601UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6467601UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6467601UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6467601UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6467601UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">316362.87 4036576.92 316360.86 4036574.28 316360.32 4036574.69 316356.8 4036570.06 316356.56 4036569.86 316352.52 4036564.73 316347.63 4036568.44 316350.49 4036572.2 316348.8 4036573.49 316353.6 4036579.8 316355.33 4036578.49 316357.33 4036581.12 316362.87 4036576.92</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6467601UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">155</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6467602UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316360.16 4036537.33</gml:lowerCorner>
         <gml:upperCorner>316373.17 4036555.58</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1970-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1970-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6467602&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6467602UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6467602UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6467602UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6467602UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6467602UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="18">316366.62 4036555.58 316366.43 4036553.39 316373.17 4036552.35 316372.84 4036548.51 316369.52 4036548.93 316369.16 4036544.13 316370.08 4036543.94 316369.5 4036540.3 316369.5 4036540.18 316369.07 4036540.19 316368.73 4036537.33 316362.52 4036538.21 316362.97 4036541.37 316362.35 4036541.42 316363.46 4036549.29 316360.16 4036549.31 316360.76 4036553.09 316366.62 4036555.58</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6467602UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">130</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6467603UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316374.75 4036513.48</gml:lowerCorner>
         <gml:upperCorner>316385.66 4036526.87</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1970-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1970-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6467603&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6467603UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6467603UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6467603UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6467603UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6467603UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="12">316384.29 4036522.14 316383.49 4036517.62 316382.76 4036513.48 316376.74 4036514.44 316377.04 4036516.23 316374.75 4036516.64 316375.94 4036523.79 316378.06 4036523.4 316378.62 4036526.87 316385.66 4036525.83 316385.08 4036522.04 316384.29 4036522.14</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6467603UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">93</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6468407UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316328.93 4036678.96</gml:lowerCorner>
         <gml:upperCorner>316349.81 4036695.41</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-06-01T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1970-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>2009-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6468407&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6468407UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6468407UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6468407UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6468407UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6468407UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17">316347.66 4036686.3 316348.41 4036684.86 316337.08 4036678.96 316336.09 4036680.86 316333.99 4036679.77 316328.93 4036689.55 316332.04 4036691.16 316331.58 4036692.05 316333.79 4036693.2 316334.26 4036692.32 316337.11 4036693.8 316337.7 4036692.67 316342.95 4036695.41 316344.27 4036692.86 316346.4 4036693.97 316349.81 4036687.42 316347.66 4036686.3</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6468407UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">207</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6468408UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316273.92 4036652.6</gml:lowerCorner>
         <gml:upperCorner>316319.59 4036683.12</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1985-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1985-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6468408&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6468408UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6468408UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6468408UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6468408UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6468408UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="8">316282.38 4036665.54 316277.86 4036672.78 316273.92 4036679.27 316279.79 4036683.12 316283.68 4036676.75 316280.8 4036674.74 316285.3 4036667.33 316282.38 4036665.54</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="23">316295.73 4036670.23 316294.61 4036672.21 316300.06 4036675.18 316301.2 4036673.16 316305.58 4036675.57 316310.5 4036666.26 316307.56 4036664.68 316309.61 4036661.17 316303.08 4036657.56 316303.24 4036657.23 316299.77 4036655.49 316297.76 4036659.19 316295.19 4036657.79 316295.39 4036657.41 316290.82 4036654.99 316286.57 4036662.69 316285.42 4036664.77 316286.57 4036665.39 316291.53 4036668.08 316290.94 4036669.24 316293.11 4036670.41 316293.8 4036669.13 316295.73 4036670.23</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                <gml:interior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5">316292.79 4036662.46 316294.11 4036660.18 316296.72 4036661.7 316295.4 4036663.98 316292.79 4036662.46</gml:posList>
                    </gml:LinearRing>
                </gml:interior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="8">316319.59 4036654.79 316315.49 4036652.6 316312.51 4036658.17 316312.15 4036657.99 316310.39 4036661.43 316314.75 4036663.82 316316.59 4036660.31 316319.59 4036654.79</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6468408UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">450</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6468409UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316309.05 4036622.68</gml:lowerCorner>
         <gml:upperCorner>316322.52 4036638.51</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-06-01T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>2009-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>2009-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6468409&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6468409UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6468409UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6468409UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6468409UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6468409UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17">316319.95 4036628.72 316321.91 4036625.39 316317.31 4036622.68 316315.36 4036626 316312.51 4036624.32 316311.04 4036626.81 316309.05 4036630.19 316310.18 4036630.86 316309.16 4036632.59 316310.91 4036633.62 316309.75 4036635.59 316314.71 4036638.51 316317.42 4036633.9 316319.86 4036635.34 316322.52 4036630.82 316319.69 4036629.16 316319.95 4036628.72</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6468409UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">239</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6468410UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316321.75 4036598.08</gml:lowerCorner>
         <gml:upperCorner>316335.88 4036614.11</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-23T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>2001-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>2001-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6468410&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6468410UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6468410UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6468410UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6468410UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6468410UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="24">316327.75 4036613.75 316328.35 4036614.1 316330.8 4036609.89 316332.15 4036610.67 316333.39 4036611.39 316335.88 4036607.07 316334.64 4036606.36 316332.79 4036605.29 316333.46 4036604.11 316333.33 4036604.04 316332.8 4036603.74 316334.64 4036600.53 316330.9 4036598.38 316330.25 4036598.08 316328.54 4036601.02 316325.5 4036599.25 316325.28 4036599.13 316321.9 4036604.79 316323.33 4036605.64 316321.75 4036608.28 316323.54 4036609.35 316322.5 4036611.08 316327.54 4036614.11 316327.75 4036613.75</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6468410UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">232</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6468414UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316310.51 4036666.23</gml:lowerCorner>
         <gml:upperCorner>316330.44 4036685.55</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>2003-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>2003-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6468414&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6468414UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6468414UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6468414UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6468414UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6468414UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="13">316317.12 4036666.23 316310.51 4036678.34 316314.99 4036680.74 316315.28 4036679.95 316320.18 4036682.53 316319.75 4036683.26 316323.97 4036685.55 316330.44 4036673.38 316326.2 4036670.99 316325.01 4036673.14 316320.13 4036670.54 316321.2 4036668.51 316317.12 4036666.23</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6468414UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">434</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6468601UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316361.91 4036658.38</gml:lowerCorner>
         <gml:upperCorner>316376.9 4036671.98</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-04-07T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>2021-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>2021-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6468601&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6468601UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6468601UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6468601UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6468601UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6468601UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="18">316362.47 4036664.24 316362.77 4036665.71 316362.9 4036666.39 316366.49 4036665.66 316367.39 4036670.09 316367.77 4036671.98 316373.7 4036670.78 316373.32 4036668.89 316372.77 4036666.17 316376.6 4036665.4 316376.9 4036665.34 316376.72 4036664.44 316375.47 4036658.38 316371.38 4036659.22 316365.11 4036660.48 316365.18 4036660.83 316361.91 4036661.48 316362.47 4036664.24</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6468601UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">406</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6468602UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316360.8 4036638.38</gml:lowerCorner>
         <gml:upperCorner>316376.63 4036652.75</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-07-31T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>2011-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>2011-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6468602&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6468602UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6468602UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6468602UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6468602UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6468602UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="27">316364.04 4036647.36 316365.75 4036652.64 316368.24 4036651.91 316368.48 4036652.75 316371.43 4036651.88 316371.07 4036650.65 316373.59 4036649.92 316376.63 4036649.02 316376.25 4036647.6 316375.82 4036645.94 316375.53 4036644.87 316372.46 4036645.78 316370.94 4036646.22 316369.89 4036642.68 316370.62 4036642.46 316371.34 4036642.25 316370.19 4036638.38 316369.43 4036638.59 316367.77 4036639.05 316368.39 4036640.94 316367.81 4036641.13 316364.95 4036642.07 316365.4 4036643.44 316363.02 4036644.21 316360.8 4036644.93 316361.83 4036648.07 316364.04 4036647.36</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6468602UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">182</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6468605UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316326.67 4036629.41</gml:lowerCorner>
         <gml:upperCorner>316344.29 4036647.67</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-06-01T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>2001-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>2001-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6468605&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6468605UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6468605UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6468605UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6468605UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6468605UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">316327.11 4036642.91 316326.67 4036647.67 316331.41 4036646.28 316335.57 4036645.11 316333.08 4036641.43 316330.39 4036643.53 316327.11 4036642.91</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">316340.56 4036639.56 316344.29 4036636.71 316338.07 4036629.41 316334.86 4036632.51 316330.41 4036637 316335.44 4036643.47 316340.56 4036639.56</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6468605UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">146</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6468606UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316337.13 4036646.37</gml:lowerCorner>
         <gml:upperCorner>316355.22 4036662.65</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1985-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>2016-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6468606&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6468606UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6468606UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6468606UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6468606UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6468606UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="11">316351.57 4036662.65 316355.22 4036656.78 316343.51 4036649.51 316344.4 4036648.07 316341.67 4036646.37 316337.13 4036653.68 316339.86 4036655.38 316338.86 4036656.99 316345.39 4036661.04 316346.39 4036659.43 316351.57 4036662.65</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6468606UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">161</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6566601UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316480.04 4036423.14</gml:lowerCorner>
         <gml:upperCorner>316509.8 4036453.47</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2023-07-18T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>2008-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>2016-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6566601&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6566601UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6566601UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6566601UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6566601UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6566601UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="8">316506.33 4036438.91 316509.8 4036434.08 316493.18 4036423.14 316490.01 4036427.76 316480.04 4036442.28 316494.59 4036452.58 316495.85 4036453.47 316506.33 4036438.91</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>4_2_retail</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>0</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6566601UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">445</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6568210UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316406.83 4036673.18</gml:lowerCorner>
         <gml:upperCorner>316423.23 4036687.34</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-06-01T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>2004-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>2004-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6568210&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6568210UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6568210UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6568210UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6568210UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6568210UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="15">316409.52 4036687.22 316414.37 4036687.34 316414.49 4036686.85 316418.06 4036686.88 316423.23 4036686.83 316423.23 4036675.72 316423.23 4036673.18 316412.28 4036673.18 316412.28 4036675.52 316412.24 4036682.52 316409.99 4036682.45 316409.52 4036682.46 316406.83 4036682.5 316406.83 4036687.22 316409.52 4036687.22</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6568210UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">336</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6568215UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316392.42 4036517.77</gml:lowerCorner>
         <gml:upperCorner>316416.92 4036564.48</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-06-01T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>1969-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>1995-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6568215&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6568215UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6568215UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6568215UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6568215UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6568215UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="17">316397.14 4036560.18 316396.45 4036563.06 316400.41 4036563.88 316400.51 4036563.62 316404.97 4036564.48 316405.43 4036562.06 316405.62 4036562.08 316407.63 4036553.05 316409.57 4036543.77 316404.86 4036542.73 316403.52 4036548.8 316402.12 4036548.37 316402.56 4036546.15 316395.79 4036544.47 316394.91 4036548.03 316392.42 4036559.24 316397.14 4036560.18</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5">316414.38 4036519.73 316416.53 4036520.15 316416.92 4036518.15 316414.94 4036517.77 316414.38 4036519.73</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>1_residential</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>1</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6568215UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">364</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6568501UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316506.11 4036724.57</gml:lowerCorner>
         <gml:upperCorner>316519.32 4036739.36</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-06-01T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>2001-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>2001-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6568501&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6568501UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6568501UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6568501UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6568501UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6568501UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="7">316514.18 4036726.27 316513.42 4036724.57 316506.11 4036727.37 316507.25 4036730.34 316507.5 4036730.23 316507.11 4036728.86 316514.18 4036726.27</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5">316516.62 4036732.98 316510.51 4036735.45 316511.85 4036739.36 316518.07 4036737.23 316516.62 4036732.98</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5">316516.86 4036732.22 316519.32 4036731.23 316517.02 4036725.48 316514.53 4036726.48 316516.86 4036732.22</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>4_3_publicServices</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>0</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6568501UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">3199</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.SDGC.BU.6768104UF1366N">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316478.38 4036478.09</gml:lowerCorner>
         <gml:upperCorner>316604.99 4036613.76</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2020-04-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning>2000-01-01T00:00:00</bu-core2d:beginning>
          <bu-core2d:end>2000-01-01T00:00:00</bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem><![CDATA[https://www1.sedecatastro.gob.es/CYCBienInmueble/OVCListaBienes.aspx?rc1=6768104&rc2=UF1366N]]></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>6768104UF1366N</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6768104UF1366N</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6768104UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6768104UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.SDGC.BU.6768104UF1366N" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="58">316481.13 4036560.06 316480.05 4036562.24 316484.86 4036573.61 316489.06 4036576.32 316487.37 4036578.94 316491.66 4036581.71 316489.82 4036584.56 316494.07 4036587.3 316490.01 4036593.6 316504.09 4036602.67 316508.15 4036596.37 316515.3 4036600.97 316516 4036601.42 316520.05 4036595.12 316520.11 4036595.03 316526.5 4036599.14 316541.36 4036608.71 316549.2 4036613.76 316551.24 4036610.59 316564.79 4036589.54 316596.76 4036539.89 316600.01 4036541.98 316603.2 4036537.02 316599.95 4036534.93 316604.99 4036527.11 316578.87 4036510.23 316575.4 4036515.62 316577.17 4036516.75 316574.56 4036520.8 316572.92 4036519.74 316572.13 4036520.97 316570.83 4036522.99 316572.47 4036524.05 316540.4 4036573.86 316527.63 4036565.65 316523.1 4036572.69 316518.73 4036569.87 316520.08 4036567.77 316515.04 4036564.52 316513.69 4036566.63 316509.23 4036563.76 316545.78 4036506.98 316545.84 4036506.9 316547.56 4036508.01 316548.84 4036506.01 316549.65 4036504.76 316548.01 4036503.7 316554.09 4036494.27 316529.71 4036478.6 316524.6 4036486.49 316521.36 4036484.4 316521.21 4036484.64 316518.29 4036489.16 316518.2 4036489.31 316521.44 4036491.4 316489.33 4036541.28 316478.38 4036558.28 316481.13 4036560.06</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="10">316567.16 4036478.09 316559.79 4036489.48 316561.01 4036491.95 316561.39 4036492.23 316560.55 4036493.69 316576.27 4036503.52 316585.35 4036489.61 316569.61 4036479.51 316569.47 4036479.68 316567.16 4036478.09</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
 	      <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
 	      <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
 	      <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse>4_2_retail</bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>0</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround xsi:nil="true" nilReason="other:unpopulated"></bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink>http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/OVCFotoFachada.svc/RecuperarFotoFachadaGet?ReferenciaCatastral=6768104UF1366N</bu-ext2d:documentLink>
          <bu-ext2d:format>jpeg</bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">25294</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
</gml:FeatureCollection>
