<?xml version="1.0" encoding="ISO-8859-1"?>
<!--Edificios de la D.G. del Catastro.-->
<gml:FeatureCollection gml:id="ES.SDGC.BU"  xmlns:ad="urn:x-inspire:specification:gmlas:Addresses:3.0" xmlns:base="urn:x-inspire:specification:gmlas:BaseTypes:3.2" xmlns:bu-base="http://inspire.jrc.ec.europa.eu/schemas/bu-base/3.0" xmlns:bu-core2d="http://inspire.jrc.ec.europa.eu/schemas/bu-core2d/2.0" xmlns:bu-ext2d="http://inspire.jrc.ec.europa.eu/schemas/bu-ext2d/2.0" xmlns:cp="urn:x-inspire:specification:gmlas:CadastralParcels:3.0" xmlns:el-bas="http://inspire.jrc.ec.europa.eu/schemas/el-bas/2.0" xmlns:el-cov="http://inspire.jrc.ec.europa.eu/schemas/el-cov/2.0" xmlns:el-tin="http://inspire.jrc.ec.europa.eu/schemas/el-tin/2.0" xmlns:el-vec="http://inspire.jrc.ec.europa.eu/schemas/el-vec/2.0" xmlns:gco="http://www.isotc211.org/2005/gco" xmlns:gmd="http://www.isotc211.org/2005/gmd" xmlns:gml="http://www.opengis.net/gml/3.2" xmlns:gmlcov="http://www.opengis.net/gmlcov/1.0" xmlns:gn="urn:x-inspire:specification:gmlas:GeographicalNames:3.0" xmlns:gsr="http://www.isotc211.org/2005/gsr" xmlns:gss="http://www.isotc211.org/2005/gss" xmlns:gts="http://www.isotc211.org/2005/gts" xmlns:swe="http://www.opengis.net/swe/2.0" xmlns:xlink="http://www.w3.org/1999/xlink"  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://inspire.jrc.ec.europa.eu/schemas/bu-ext2d/2.0 http://inspire.ec.europa.eu/draft-schemas/bu-ext2d/2.0/BuildingExtended2D.xsd">
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6063503UF1366S_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315962.0152 4036147.7426</gml:lowerCorner>
         <gml:upperCorner>315971.71685 4036167.32685</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2018-06-04T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6063503UF1366S_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6063503UF1366S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6063503UF1366S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6063503UF1366S_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="40"> 315963.01 4036164.01 315963 4036164.53 315963.04 4036164.85 315963.1 4036165.13 315963.19 4036165.41 315963.32 4036165.69 315963.52 4036166.02 315963.76 4036166.33 315964.04 4036166.61 315964.29 4036166.8 315964.62 4036167 315964.85 4036167.1 315965.18 4036167.22 315965.4 4036167.27 315965.67 4036167.31 315966.09 4036167.33 315966.34 4036167.31 315966.67 4036167.25 315966.95 4036167.17 315967.25 4036167.05 315967.5 4036166.92 315967.7 4036166.8 315967.93 4036166.62 315968.15 4036166.41 315968.37 4036166.16 315968.55 4036165.9 315968.71 4036165.61 315968.79 4036165.41 315968.87 4036165.17 315968.92 4036164.97 315968.95 4036164.82 315968.97 4036164.65 315969.97 4036164.76 315971.72 4036148.6 315971.47 4036148.58 315964.01 4036147.77 315963.76 4036147.74 315962.04 4036163.65 315962.02 4036163.9 315963.01 4036164.01</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6063504UF1366S_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315996.0145 4036169.4035</gml:lowerCorner>
         <gml:upperCorner>316009.0045 4036182.1835</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6063504UF1366S_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6063504UF1366S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6063504UF1366S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6063504UF1366S_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="191"> 315997.45 4036177.78 315997.37 4036177.92 315997.31 4036178.07 315997.27 4036178.23 315997.24 4036178.39 315997.23 4036178.55 315997.23 4036178.71 315997.24 4036178.87 315997.28 4036179.03 315997.32 4036179.19 315997.38 4036179.34 315997.46 4036179.49 315997.54 4036179.6 315997.64 4036179.71 315997.73 4036179.81 315997.84 4036179.91 315997.94 4036180 315998.06 4036180.09 315998.17 4036180.17 315998.29 4036180.25 315998.42 4036180.32 315998.54 4036180.39 315998.68 4036180.45 315998.79 4036180.47 315998.91 4036180.48 315999.02 4036180.48 315999.14 4036180.48 315999.26 4036180.46 315999.37 4036180.44 315999.48 4036180.41 315999.59 4036180.36 315999.7 4036180.31 315999.8 4036180.25 316000.97 4036179.58 316001.2 4036179.42 316001.45 4036179.3 316001.72 4036179.21 316001.99 4036179.16 316002.27 4036179.15 316002.55 4036179.17 316002.82 4036179.23 316003.09 4036179.33 316003.33 4036179.46 316003.56 4036179.62 316003.77 4036179.82 316005.12 4036181.53 316005.32 4036181.75 316005.56 4036181.93 316005.83 4036182.07 316006.12 4036182.15 316006.42 4036182.18 316006.72 4036182.15 316007.01 4036182.06 316007.27 4036181.93 316007.51 4036181.74 316007.71 4036181.51 316007.87 4036181.26 316007.95 4036181.09 316007.99 4036180.92 316008 4036180.74 316007.96 4036180.56 316007.89 4036180.39 316007.78 4036180.24 316007.65 4036180.12 316007.49 4036180.03 316007.32 4036179.98 316007.13 4036179.97 316006.96 4036180 316006.82 4036179.89 316006.71 4036179.76 316006.63 4036179.61 316006.58 4036179.45 316006.58 4036179.28 316006.61 4036179.11 316006.68 4036178.96 316006.79 4036178.82 316006.92 4036178.71 316007.07 4036178.64 316007.24 4036178.6 316007.87 4036178.64 316008.02 4036178.61 316008.16 4036178.57 316008.3 4036178.51 316008.43 4036178.43 316008.55 4036178.34 316008.66 4036178.23 316008.76 4036178.12 316008.84 4036177.99 316008.91 4036177.85 316008.95 4036177.7 316008.99 4036177.56 316009 4036177.31 316009 4036177.06 316008.98 4036176.82 316008.95 4036176.58 316008.9 4036176.34 316008.83 4036176.1 316008.75 4036175.87 316008.65 4036175.64 316008.54 4036175.42 316008.41 4036175.22 316008.27 4036175.02 316008.19 4036174.89 316008.1 4036174.78 316008 4036174.68 316007.89 4036174.59 316007.76 4036174.51 316007.63 4036174.46 316007.49 4036174.41 316007.35 4036174.38 316007.21 4036174.37 316007.07 4036174.38 316006.93 4036174.41 316005.4 4036174.52 316005.07 4036174.55 316004.74 4036174.56 316004.42 4036174.52 316004.1 4036174.45 316003.79 4036174.34 316003.5 4036174.2 316003.22 4036174.03 316002.96 4036173.83 316002.73 4036173.6 316002.53 4036173.34 316002.36 4036173.07 316002.23 4036172.91 316002.11 4036172.75 316002 4036172.59 316001.9 4036172.41 316001.81 4036172.24 316001.73 4036172.05 316001.66 4036171.87 316001.6 4036171.67 316001.56 4036171.48 316001.53 4036171.28 316001.51 4036171.09 316001.47 4036170.9 316001.41 4036170.71 316001.34 4036170.54 316001.25 4036170.37 316001.14 4036170.21 316001.01 4036170.06 316000.87 4036169.93 316000.72 4036169.82 316000.56 4036169.71 316000.39 4036169.63 316000.21 4036169.57 316000.07 4036169.52 315999.94 4036169.48 315999.81 4036169.45 315999.67 4036169.43 315999.53 4036169.41 315999.39 4036169.41 315999.25 4036169.4 315999.12 4036169.41 315998.98 4036169.42 315998.84 4036169.44 315998.71 4036169.47 315997.01 4036170.16 315996.85 4036170.19 315996.71 4036170.24 315996.57 4036170.31 315996.44 4036170.4 315996.33 4036170.51 315996.23 4036170.63 315996.15 4036170.76 315996.08 4036170.9 315996.04 4036171.05 315996.01 4036171.2 315996.01 4036171.36 315996.02 4036171.51 315996.05 4036171.66 315996.1 4036171.8 315996.17 4036171.94 315996.25 4036172.07 315996.36 4036172.18 315996.47 4036172.28 315996.6 4036172.37 315996.74 4036172.44 315997.59 4036172.96 315997.82 4036173.22 315998.03 4036173.51 315998.19 4036173.83 315998.32 4036174.17 315998.4 4036174.51 315998.44 4036174.87 315998.43 4036175.22 315998.38 4036175.58 315998.29 4036175.92 315998.16 4036176.25 315997.45 4036177.78</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6064403UF1366S_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315954.8488 4036328.26005</gml:lowerCorner>
         <gml:upperCorner>315966.6775 4036334.6025</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-06-01T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6064403UF1366S_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6064403UF1366S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6064403UF1366S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6064403UF1366S_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="28"> 315964.9 4036328.26 315954.85 4036328.29 315954.86 4036332.93 315963.85 4036332.99 315964.1 4036333.3 315964.12 4036333.57 315964.21 4036333.84 315964.35 4036334.08 315964.54 4036334.28 315964.76 4036334.44 315965.02 4036334.55 315965.29 4036334.6 315965.57 4036334.59 315965.84 4036334.52 315966.09 4036334.4 315966.31 4036334.22 315966.48 4036334 315966.6 4036333.75 315966.67 4036333.48 315966.68 4036333.21 315966.63 4036332.93 315966.52 4036332.68 315966.35 4036332.45 315966.15 4036332.26 315965.91 4036332.13 315965.21 4036332.06 315964.93 4036331.89 315964.9 4036328.26</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6064404UF1366S_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315956.4 4036284.02</gml:lowerCorner>
         <gml:upperCorner>315964.48 4036298.18</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-07-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6064404UF1366S_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6064404UF1366S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6064404UF1366S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6064404UF1366S_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="52"> 315962.14 4036284.09 315961.61 4036284.02 315961.08 4036284.04 315960.57 4036284.17 315960.09 4036284.38 315958.78 4036285.58 315958.1 4036286.93 315957.69 4036287.92 315957.19 4036289.56 315956.82 4036291.01 315956.53 4036292.83 315956.4 4036294.33 315956.44 4036294.88 315956.49 4036295.14 315956.56 4036295.42 315956.75 4036295.94 315957.02 4036296.42 315957.35 4036296.86 315957.75 4036297.25 315958.2 4036297.57 315958.68 4036297.84 315959.2 4036298.03 315959.74 4036298.14 315960.3 4036298.18 315961.04 4036298.08 315961.76 4036297.83 315962.42 4036297.44 315962.97 4036296.93 315963.21 4036296.63 315963.41 4036296.32 315963.58 4036295.98 315963.71 4036295.47 315963.66 4036294.66 315963.34 4036293.92 315963.12 4036293.31 315963.03 4036292.88 315962.98 4036292.46 315962.97 4036291.59 315963.08 4036290.74 315963.31 4036289.9 315963.47 4036289.5 315963.89 4036288.75 315964.38 4036287.64 315964.48 4036286.84 315964.43 4036286.72 315964.33 4036286.18 315964.15 4036285.69 315963.88 4036285.23 315963.53 4036284.83 315963.12 4036284.49 315962.64 4036284.25 315962.14 4036284.09</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6064404UF1366S_PI.2">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315963.8 4036277.96</gml:lowerCorner>
         <gml:upperCorner>315969 4036283.17</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-07-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6064404UF1366S_PI.2</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6064404UF1366S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6064404UF1366S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6064404UF1366S_PI.2" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="34"> 315966.24 4036277.96 315965.79 4036278.03 315965.36 4036278.18 315964.96 4036278.39 315964.45 4036278.84 315964.18 4036279.2 315963.98 4036279.61 315963.85 4036280.04 315963.8 4036280.63 315963.85 4036281.08 315964.07 4036281.72 315964.31 4036282.11 315964.6 4036282.45 315964.96 4036282.73 315965.35 4036282.95 315966.01 4036283.14 315966.46 4036283.17 315966.91 4036283.12 315967.55 4036282.9 315967.94 4036282.66 315968.28 4036282.36 315968.56 4036282.01 315968.78 4036281.61 315968.97 4036280.96 315969 4036280.62 315968.93 4036279.95 315968.78 4036279.52 315968.68 4036279.31 315968.43 4036278.94 315968.12 4036278.61 315967.75 4036278.34 315967.35 4036278.14 315966.91 4036278.01 315966.24 4036277.96</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6066404UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315949.8123 4036437.0788</gml:lowerCorner>
         <gml:upperCorner>315958.6445 4036447.11585</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2016-10-06T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6066404UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6066404UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6066404UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6066404UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="20"> 315952.79 4036437.65 315952.6 4036437.43 315952.37 4036437.26 315952.1 4036437.15 315951.82 4036437.09 315951.54 4036437.1 315951.26 4036437.17 315951.01 4036437.3 315950.79 4036437.49 315950.62 4036437.72 315950.5 4036437.97 315950.44 4036438.25 315950.44 4036438.54 315950.51 4036438.82 315950.64 4036439.08 315949.81 4036439.64 315954.82 4036447.12 315958.64 4036444.55 315953.63 4036437.08 315952.79 4036437.65</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6066405UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315971.8685 4036390.852</gml:lowerCorner>
         <gml:upperCorner>315981.6185 4036397.672</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6066405UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6066405UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6066405UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6066405UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9"> 315981.16 4036394.54 315981.62 4036392.88 315981.09 4036392.75 315973.11 4036390.85 315972.13 4036394.54 315971.87 4036395.52 315980.32 4036397.67 315981.15 4036394.58 315981.16 4036394.54</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6165801UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315976.678 4036350.2025</gml:lowerCorner>
         <gml:upperCorner>315985.808 4036361.9625</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6165801UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6165801UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6165801UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6165801UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9"> 315980.96 4036361.33 315982.23 4036361.96 315983.27 4036359.86 315982.24 4036359.35 315985.81 4036352.45 315981.17 4036350.2 315981.02 4036350.49 315976.68 4036359.2 315980.96 4036361.33</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6165802UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316024.75 4036329.35</gml:lowerCorner>
         <gml:upperCorner>316034.02 4036344.75</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2013-10-08T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6165802UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6165802UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6165802UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6165802UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="36"> 316027.07 4036344.67 316027.51 4036344.75 316027.96 4036344.73 316028.39 4036344.6 316028.79 4036344.38 316029.12 4036344.08 316029.38 4036343.71 316029.55 4036343.3 316030.45 4036343.57 316034.02 4036332.29 316033.01 4036331.97 316033.1 4036331.56 316033.11 4036331.13 316033.03 4036330.72 316032.86 4036330.34 316032.61 4036330 316032.3 4036329.71 316031.93 4036329.51 316031.53 4036329.38 316031.11 4036329.35 316030.69 4036329.4 316030.3 4036329.54 316029.94 4036329.77 316029.64 4036330.06 316029.41 4036330.41 316029.26 4036330.81 316028.18 4036330.48 316024.75 4036341.88 316025.75 4036342.17 316025.66 4036342.61 316025.67 4036343.06 316025.79 4036343.49 316026 4036343.89 316026.29 4036344.23 316026.65 4036344.49 316027.07 4036344.67</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6165804UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316071.737 4036288.3215</gml:lowerCorner>
         <gml:upperCorner>316086.3775 4036300.1315</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-10-30T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6165804UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6165804UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6165804UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6165804UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 316083.42 4036300.13 316086.38 4036294.25 316074.61 4036288.32 316071.74 4036294.25 316083.42 4036300.13</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6166302UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315977.381 4036501.671</gml:lowerCorner>
         <gml:upperCorner>315986.021 4036511.771</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6166302UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6166302UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6166302UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6166302UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9"> 315985.01 4036505.75 315986.02 4036503.61 315984.91 4036503.07 315981.99 4036501.67 315977.38 4036511 315978.43 4036511.51 315979.03 4036510.26 315982.18 4036511.77 315985.01 4036505.75</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6166305UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316002.43565 4036404.6515</gml:lowerCorner>
         <gml:upperCorner>316009.689 4036415.5156</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-06-01T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6166305UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6166305UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6166305UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6166305UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="14"> 316006.51 4036415.52 316008.25 4036413.49 316008.32 4036411.76 316008.48 4036410.88 316008.67 4036410 316008.89 4036409.17 316009.33 4036407.86 316009.69 4036406.55 316009.51 4036406.19 316008.63 4036405.85 316005.67 4036404.65 316004.74 4036407.31 316002.44 4036413.89 316006.51 4036415.52</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6167901UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315970.882 4036561.6405</gml:lowerCorner>
         <gml:upperCorner>315977.792 4036569.4805</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6167901UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6167901UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6167901UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6167901UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="33"> 315971.73 4036564.94 315972.75 4036566.41 315973.34 4036566.78 315974.09 4036567.21 315974.73 4036567.7 315975.19 4036568.36 315975.63 4036569.04 315976.24 4036569.47 315976.72 4036569.48 315977.28 4036569.18 315977.68 4036568.64 315977.79 4036568.02 315977.71 4036566.48 315977.31 4036564.89 315976.73 4036563.34 315976.19 4036562.73 315975.46 4036562.23 315974.66 4036561.92 315973.85 4036561.74 315973.01 4036561.64 315972.46 4036561.68 315972.11 4036561.72 315971.78 4036561.85 315971.49 4036562.03 315971.24 4036562.28 315971.05 4036562.57 315970.93 4036562.9 315970.88 4036563.24 315970.9 4036563.59 315971 4036563.92 315971.17 4036564.23 315971.4 4036564.5 315971.73 4036564.94</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6167902UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>315981.502 4036568.4105</gml:lowerCorner>
         <gml:upperCorner>315992.2625 4036576.1305</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2021-12-02T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6167902UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6167902UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6167902UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6167902UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="34"> 315981.5 4036570.38 315981.5 4036570.79 315981.59 4036571.19 315981.76 4036571.57 315982.02 4036571.89 315982.34 4036572.16 315982.38 4036572.42 315983.06 4036573.11 315986.47 4036574.56 315989.77 4036576.08 315989.97 4036576.13 315990.18 4036576.13 315990.38 4036576.05 315990.47 4036575.99 315990.61 4036575.82 315992.26 4036572.24 315992.21 4036571.92 315992.07 4036571.63 315991.85 4036571.4 315991.72 4036571.32 315991.42 4036571.21 315991.11 4036571.2 315984.69 4036568.42 315984.51 4036568.41 315984.33 4036568.44 315984.09 4036568.56 315983.96 4036568.68 315983.1 4036568.72 315982.7 4036568.82 315982.34 4036569.01 315982.02 4036569.27 315981.76 4036569.6 315981.59 4036569.97 315981.5 4036570.38</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6167904UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316035.122 4036556.39</gml:lowerCorner>
         <gml:upperCorner>316047.8525 4036561.69</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6167904UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6167904UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6167904UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6167904UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="71"> 316042.91 4036556.81 316039.92 4036556.57 316039.08 4036556.43 316038.25 4036556.39 316037.45 4036556.41 316036.73 4036556.64 316036.48 4036556.72 316036.25 4036556.83 316036.04 4036556.97 316035.84 4036557.13 316035.66 4036557.32 316035.51 4036557.52 316035.38 4036557.74 316035.27 4036557.97 316035.2 4036558.22 316035.15 4036558.47 316035.14 4036558.73 316035.12 4036559.81 316035.34 4036560.58 316035.47 4036560.75 316035.61 4036560.92 316035.78 4036561.08 316035.95 4036561.21 316036.14 4036561.34 316036.34 4036561.44 316036.54 4036561.53 316036.75 4036561.6 316036.97 4036561.65 316037.19 4036561.68 316037.42 4036561.69 316038.19 4036561.44 316038.9 4036561.05 316039.29 4036560.86 316039.69 4036560.72 316040.11 4036560.6 316040.53 4036560.53 316040.96 4036560.49 316041.39 4036560.48 316041.83 4036560.51 316042.25 4036560.58 316042.67 4036560.68 316043.08 4036560.82 316043.48 4036561 316044.76 4036561.53 316045.02 4036561.64 316045.24 4036561.67 316045.47 4036561.69 316045.69 4036561.69 316045.92 4036561.67 316046.14 4036561.63 316046.36 4036561.57 316046.58 4036561.49 316046.78 4036561.39 316046.98 4036561.28 316047.16 4036561.14 316047.34 4036561 316047.51 4036560.77 316047.66 4036560.51 316047.76 4036560.24 316047.83 4036559.96 316047.85 4036559.67 316047.83 4036559.38 316047.77 4036559.09 316047.66 4036558.82 316047.52 4036558.57 316047.34 4036558.34 316047.14 4036558.14 316046.25 4036557.52 316045.46 4036557.26 316044.25 4036557.01 316042.91 4036556.81</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6265301UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316111.1785 4036370.538</gml:lowerCorner>
         <gml:upperCorner>316121.65 4036380.652</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-08-28T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6265301UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6265301UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6265301UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6265301UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="43"> 316121.65 4036378.19 316120.44 4036378.05 316120.15 4036377.41 316119.83 4036376.27 316119.94 4036375.38 316120.26 4036374.78 316120.72 4036373.92 316121.08 4036373.23 316120.94 4036372.53 316120.44 4036371.46 316119.09 4036370.68 316118.16 4036370.54 316117.06 4036371.11 316116.59 4036371.71 316116.41 4036372.57 316115.74 4036372.28 316115.77 4036371.71 316114.95 4036371.14 316113.6 4036370.75 316112.1 4036371.21 316111.32 4036372.25 316111.18 4036373.28 316111.43 4036374.35 316112.64 4036375.77 316113.42 4036376.52 316113.57 4036376.98 316113.49 4036377.63 316113.47 4036377.87 316114.95 4036378.52 316115.35 4036378.09 316115.88 4036377.98 316116.24 4036378.12 316116.34 4036378.52 316116.81 4036379.37 316117.27 4036379.9 316117.98 4036380.37 316118.8 4036380.65 316119.73 4036380.51 316120.47 4036380.19 316120.9 4036379.87 316121.4 4036379.3 316121.58 4036378.66 316121.65 4036378.19</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6265701UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316157.718 4036298.6805</gml:lowerCorner>
         <gml:upperCorner>316169.928 4036307.7505</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6265701UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6265701UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6265701UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6265701UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="98"> 316165.85 4036302.68 316166.4 4036302.17 316166.57 4036301.94 316166.72 4036301.7 316166.82 4036301.44 316166.9 4036301.16 316166.93 4036300.88 316166.93 4036300.6 316166.89 4036300.32 316166.8 4036300.05 316166.69 4036299.79 316166.54 4036299.55 316166.36 4036299.34 316166.09 4036299.11 316165.8 4036298.93 316165.48 4036298.8 316165.14 4036298.71 316164.8 4036298.68 316164.45 4036298.71 316164.11 4036298.78 316163.79 4036298.91 316163.49 4036299.09 316163.23 4036299.31 316163 4036299.57 316162.67 4036300.28 316162.59 4036301.11 316162.58 4036301.38 316160.89 4036301.78 316160.71 4036301.76 316160.54 4036301.73 316160.37 4036301.69 316160.21 4036301.64 316160.05 4036301.57 316159.89 4036301.5 316159.74 4036301.4 316159.6 4036301.3 316159.47 4036301.19 316159.35 4036301.07 316159.24 4036300.94 316159.03 4036300.76 316158.59 4036300.96 316158.35 4036301.21 316158.15 4036301.49 316157.98 4036301.8 316157.85 4036302.12 316157.77 4036302.46 316157.72 4036302.8 316157.72 4036303.15 316157.76 4036303.49 316157.84 4036303.83 316157.96 4036304.16 316158.12 4036304.47 316158.3 4036304.73 316158.51 4036304.97 316158.74 4036305.18 316159 4036305.36 316159.28 4036305.52 316159.58 4036305.64 316159.88 4036305.73 316160.19 4036305.79 316160.51 4036305.81 316160.83 4036305.79 316161.15 4036305.74 316161.92 4036305.84 316162.29 4036306.16 316162.44 4036306.67 316162.71 4036307.45 316163.1 4036307.75 316163.51 4036307.71 316164.29 4036307.45 316165.27 4036307.48 316167.66 4036307.6 316168.01 4036307.56 316168.36 4036307.47 316168.69 4036307.33 316169 4036307.13 316169.27 4036306.9 316169.5 4036306.62 316169.69 4036306.31 316169.82 4036305.98 316169.91 4036305.62 316169.93 4036305.26 316169.91 4036304.91 316169.5 4036304.09 316169.01 4036303.62 316168.84 4036303.52 316168.67 4036303.44 316168.5 4036303.37 316168.32 4036303.32 316168.13 4036303.28 316167.94 4036303.27 316167.76 4036303.27 316167.57 4036303.28 316167.38 4036303.31 316167.2 4036303.36 316167.03 4036303.43 316166.56 4036303.71 316165.85 4036302.68</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6267301UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316028.5325 4036457.6435</gml:lowerCorner>
         <gml:upperCorner>316142.298 4036637.5085</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2026-07-22T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6267301UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6267301UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6267301UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6267301UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="30"> 316100.35 4036474.97 316099.96 4036475.77 316095.32 4036485.22 316092.9 4036490.14 316083.31 4036509.46 316075.57 4036525.04 316069.67 4036536.98 316069.68 4036536.98 316069.58 4036537.18 316067.08 4036542.26 316052.17 4036572.12 316044.34 4036588.01 316041.91 4036592.91 316040.7 4036595.34 316039.65 4036597.45 316028.53 4036621.45 316046.65 4036632.04 316058.75 4036637.51 316065.24 4036624.62 316079.65 4036595.34 316086.16 4036582.48 316130.47 4036494.94 316142.3 4036471.58 316135.28 4036467.97 316133.96 4036470.54 316108.85 4036457.64 316107.83 4036459.7 316107.29 4036460.79 316106.45 4036462.52 316100.35 4036474.97</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                <gml:interior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="9"> 316088.19 4036533.96 316093.99 4036536.9 316088.33 4036548.05 316087.85 4036547.8 316087.54 4036548.41 316082.73 4036545.96 316083.04 4036545.36 316082.54 4036545.1 316088.19 4036533.96</gml:posList>
                    </gml:LinearRing>
                </gml:interior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6268803UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316134.1445 4036640.988</gml:lowerCorner>
         <gml:upperCorner>316146.1345 4036654.698</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6268803UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6268803UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6268803UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6268803UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="64"> 316140.45 4036654.7 316141.18 4036653.42 316142.06 4036652.2 316142.54 4036651.5 316142.99 4036650.82 316143.6 4036649.71 316144.59 4036647.83 316144.88 4036647 316145.58 4036645.36 316146.13 4036644.06 316145.54 4036643.86 316144.95 4036643.65 316144.37 4036643.42 316143.8 4036643.17 316143.24 4036642.91 316142.69 4036642.63 316142.14 4036642.33 316141.61 4036642.02 316141.08 4036641.69 316140.56 4036641.34 316140.06 4036640.99 316137.98 4036643.9 316137.46 4036644.44 316137.32 4036644.55 316137.17 4036644.64 316137 4036644.69 316136.82 4036644.72 316136.65 4036644.72 316136.47 4036644.69 316136.31 4036644.62 316136.16 4036644.53 316136.03 4036644.41 316135.92 4036644.27 316135.84 4036644.12 316135.6 4036644.02 316135.08 4036645.44 316135.81 4036645.77 316135.94 4036645.89 316136.06 4036646.04 316136.15 4036646.19 316136.23 4036646.37 316136.27 4036646.54 316136.29 4036646.73 316136.29 4036646.91 316136.26 4036647.1 316136.2 4036647.27 316136.12 4036647.44 316136.02 4036647.6 316135.65 4036648.46 316134.93 4036650.04 316134.35 4036651.15 316134.14 4036651.52 316134.7 4036651.72 316135.26 4036651.94 316135.82 4036652.17 316136.37 4036652.42 316136.91 4036652.67 316137.45 4036652.94 316137.98 4036653.22 316138.51 4036653.52 316139.03 4036653.82 316139.54 4036654.14 316140.05 4036654.47 316140.45 4036654.7</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6268805UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316164.9025 4036543.1185</gml:lowerCorner>
         <gml:upperCorner>316178.2425 4036557.2385</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6268805UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6268805UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6268805UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6268805UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="103"> 316167.09 4036549.56 316166.11 4036550.13 316165.8 4036550.43 316165.53 4036550.76 316165.3 4036551.13 316165.13 4036551.53 316165 4036551.94 316164.93 4036552.36 316164.9 4036552.79 316164.94 4036553.22 316165.02 4036553.65 316165.16 4036554.06 316165.35 4036554.45 316165.49 4036554.73 316165.67 4036555.01 316165.87 4036555.26 316166.1 4036555.49 316166.35 4036555.69 316166.62 4036555.87 316166.91 4036556.03 316167.21 4036556.15 316167.52 4036556.24 316167.84 4036556.3 316168.17 4036556.33 316169.08 4036556.51 316169.23 4036556.94 316169.65 4036557.2 316170.32 4036557.24 316171.1 4036556.98 316173 4036556.13 316173.49 4036555.61 316173.43 4036555.28 316173.04 4036554.67 316173.08 4036554.19 316173.4 4036553.91 316174.01 4036553.74 316174.92 4036553.69 316176.69 4036553.75 316176.67 4036552.21 316175.7 4036552.35 316175.32 4036552.32 316175.2 4036552.31 316175.09 4036552.28 316174.99 4036552.23 316174.91 4036552.16 316174.84 4036552.07 316174.79 4036551.97 316174.77 4036551.86 316174.77 4036551.74 316174.79 4036551.63 316174.84 4036551.53 316174.91 4036551.44 316174.99 4036551.37 316175.09 4036551.32 316175.2 4036551.29 316175.31 4036551.28 316175.43 4036551.31 316176.28 4036550.86 316176.75 4036550.53 316177.17 4036550.14 316177.53 4036549.69 316177.82 4036549.19 316178.04 4036548.66 316178.18 4036548.1 316178.24 4036547.53 316178.21 4036546.95 316178.1 4036546.39 316177.91 4036545.85 316177.65 4036545.34 316177.34 4036544.87 316176.98 4036544.44 316176.57 4036544.07 316176.12 4036543.75 316175.62 4036543.49 316175.1 4036543.3 316174.56 4036543.17 316174 4036543.12 316173.45 4036543.14 316172.9 4036543.23 316172.37 4036543.4 316171.46 4036544.02 316170.82 4036544.57 316170.2 4036545.15 316169.44 4036545.56 316168.62 4036545.8 316168.02 4036545.9 316168.24 4036547.13 316169.88 4036546.94 316170.02 4036546.94 316170.16 4036546.98 316170.29 4036547.06 316170.39 4036547.15 316170.48 4036547.27 316170.53 4036547.41 316170.55 4036547.55 316170.54 4036547.7 316170.49 4036547.84 316170.42 4036547.96 316170.32 4036548.07 316170.2 4036548.15 316169.05 4036548.81 316167.72 4036549.32 316167.09 4036549.56</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6364101UF1366S_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316195.726 4036201.121</gml:lowerCorner>
         <gml:upperCorner>316205.906 4036211.771</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6364101UF1366S_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6364101UF1366S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6364101UF1366S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6364101UF1366S_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="119"> 316201.76 4036203.09 316200.91 4036204.23 316200.76 4036204.18 316200.54 4036203.5 316200.38 4036203.07 316200.14 4036202.68 316199.84 4036202.35 316199.47 4036202.08 316199.06 4036201.88 316198.62 4036201.77 316198.17 4036201.75 316197.72 4036201.82 316197.29 4036201.97 316196.9 4036202.2 316196.57 4036202.51 316196.26 4036202.79 316196.02 4036203.13 316195.84 4036203.51 316195.75 4036203.92 316195.73 4036204.34 316195.79 4036204.75 316195.94 4036205.15 316196.15 4036205.5 316196.43 4036205.81 316196.77 4036206.06 316197.15 4036206.25 316198.12 4036206.73 316198.3 4036206.88 316198.37 4036206.92 316198.43 4036206.97 316198.48 4036207.04 316198.51 4036207.11 316198.53 4036207.2 316198.52 4036207.28 316198.5 4036207.36 316198.46 4036207.43 316198.41 4036207.49 316198.34 4036207.54 316198.27 4036207.58 316198.19 4036207.6 316197.73 4036207.75 316197.34 4036207.93 316197.04 4036208.12 316196.78 4036208.35 316196.56 4036208.63 316196.4 4036208.94 316196.29 4036209.28 316196.23 4036209.63 316196.24 4036209.98 316196.31 4036210.32 316196.44 4036210.65 316196.62 4036210.96 316196.85 4036211.23 316197.07 4036211.4 316197.31 4036211.54 316197.57 4036211.65 316197.84 4036211.73 316198.12 4036211.77 316198.4 4036211.77 316198.68 4036211.74 316198.96 4036211.67 316199.22 4036211.57 316199.47 4036211.43 316199.7 4036211.27 316200.68 4036210.51 316201.59 4036209.82 316201.71 4036209.77 316201.85 4036209.73 316201.99 4036209.71 316202.12 4036209.7 316202.26 4036209.7 316202.4 4036209.72 316202.53 4036209.75 316202.67 4036209.8 316202.79 4036209.86 316202.91 4036209.92 316203.03 4036210.01 316203.14 4036210.08 316204.08 4036208.34 316203.85 4036208.37 316203.62 4036208.36 316203.4 4036208.29 316203.2 4036208.18 316203.03 4036208.02 316202.91 4036207.83 316202.83 4036207.61 316202.8 4036207.38 316202.82 4036207.16 316202.9 4036206.94 316203.03 4036206.75 316203.35 4036206.54 316204.08 4036206.35 316204.59 4036206.15 316205.1 4036205.71 316205.31 4036205.47 316205.49 4036205.22 316205.64 4036204.94 316205.76 4036204.65 316205.85 4036204.34 316205.9 4036204.03 316205.91 4036203.72 316205.89 4036203.4 316205.83 4036203.09 316205.73 4036202.79 316205.61 4036202.51 316205.47 4036202.28 316205.31 4036202.06 316205.13 4036201.86 316204.94 4036201.69 316204.72 4036201.53 316204.49 4036201.4 316204.25 4036201.29 316203.99 4036201.21 316203.74 4036201.15 316203.47 4036201.12 316203.21 4036201.12 316202.46 4036201.17 316202.48 4036202.1 316201.76 4036203.09</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6364501UF1366S_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316279.2185 4036306.029</gml:lowerCorner>
         <gml:upperCorner>316286.6785 4036312.959</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2009-08-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6364501UF1366S_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6364501UF1366S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6364501UF1366S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6364501UF1366S_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="48"> 316283.87 4036312.96 316284.41 4036312.82 316284.93 4036312.6 316285.4 4036312.3 316285.81 4036311.92 316286.16 4036311.47 316286.42 4036310.97 316286.56 4036310.56 316286.6 4036310.44 316286.68 4036309.88 316286.67 4036309.32 316286.56 4036308.77 316286.37 4036308.25 316286.09 4036307.77 316285.75 4036307.34 316285.35 4036306.95 316284.9 4036306.63 316284.41 4036306.37 316283.89 4036306.19 316283.35 4036306.07 316282.8 4036306.03 316282.25 4036306.07 316281.71 4036306.19 316281.2 4036306.38 316279.7 4036307.49 316279.49 4036307.88 316279.34 4036308.31 316279.25 4036308.74 316279.22 4036309.19 316279.25 4036309.64 316279.33 4036310.08 316279.48 4036310.5 316279.68 4036310.9 316279.93 4036311.27 316280.23 4036311.6 316280.57 4036311.9 316280.79 4036312.06 316281.03 4036312.22 316281.28 4036312.36 316281.53 4036312.48 316281.79 4036312.6 316282.06 4036312.69 316282.33 4036312.77 316282.61 4036312.84 316282.89 4036312.89 316283.17 4036312.93 316283.46 4036312.95 316283.87 4036312.96</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6364501UF1366S_PI.2">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316263.198 4036290.689</gml:lowerCorner>
         <gml:upperCorner>316285.6585 4036315.019</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2009-08-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6364501UF1366S_PI.2</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6364501UF1366S&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6364501UF1366S&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6364501UF1366S_PI.2" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="168"> 316268.48 4036295.14 316267.87 4036295.63 316267.07 4036296.06 316266.24 4036296.32 316265.83 4036296.45 316265.49 4036296.64 316265.16 4036296.85 316264.86 4036297.1 316264.58 4036297.37 316264.33 4036297.66 316264.1 4036297.98 316263.9 4036298.31 316263.72 4036298.66 316263.58 4036299.02 316263.47 4036299.39 316263.4 4036299.78 316263.22 4036301.65 316263.2 4036302.53 316263.24 4036303.42 316263.45 4036304.34 316263.71 4036305.19 316264 4036305.99 316264.02 4036306.83 316263.74 4036307.34 316263.36 4036308.12 316263.33 4036308.84 316263.6 4036309.52 316264.61 4036310.78 316266.86 4036312.41 316267.72 4036312.72 316268.53 4036312.91 316269.34 4036313.03 316270.15 4036313.08 316270.78 4036313.08 316270.99 4036313.07 316271.21 4036313.04 316271.42 4036312.99 316271.63 4036312.91 316271.82 4036312.8 316272 4036312.67 316272.16 4036312.52 316272.3 4036312.35 316272.42 4036312.17 316272.51 4036311.97 316272.59 4036311.77 316272.56 4036311.29 316272.53 4036311.17 316272.53 4036311.04 316272.56 4036310.93 316272.62 4036310.82 316272.7 4036310.73 316272.79 4036310.66 316272.91 4036310.61 316273.03 4036310.59 316273.15 4036310.6 316273.26 4036310.64 316273.37 4036310.7 316273.46 4036310.79 316274.6 4036311.16 316275.8 4036311.99 316277.77 4036313.3 316280.76 4036315.02 316281.62 4036313.54 316280.11 4036312.8 316279.76 4036312.61 316279.44 4036312.39 316279.14 4036312.15 316278.86 4036311.88 316278.6 4036311.58 316278.38 4036311.27 316278.18 4036310.93 316278.01 4036310.58 316277.88 4036310.21 316277.78 4036309.84 316277.72 4036309.46 316277.68 4036308.96 316277.71 4036308.46 316277.82 4036307.97 316277.98 4036307.5 316278.21 4036307.05 316278.5 4036306.64 316278.85 4036306.28 316279.23 4036305.96 316279.66 4036305.71 316280.12 4036305.51 316280.61 4036305.38 316282.46 4036305.06 316283.9 4036305.01 316284.67 4036304.93 316284.88 4036304.82 316285.07 4036304.68 316285.24 4036304.52 316285.39 4036304.33 316285.5 4036304.12 316285.59 4036303.9 316285.64 4036303.67 316285.66 4036303.43 316285.64 4036303.2 316285.59 4036302.97 316285.51 4036302.75 316285.33 4036302.25 316285.29 4036301.43 316285.53 4036300.69 316285.54 4036299.52 316285.48 4036299.13 316285.4 4036298.76 316285.3 4036298.39 316285.18 4036298.02 316285.04 4036297.67 316284.88 4036297.32 316284.7 4036296.98 316284.5 4036296.65 316284.28 4036296.34 316284.04 4036296.03 316283.79 4036295.75 316283.14 4036295.14 316282.55 4036294.58 316279.65 4036292.45 316277.84 4036291.36 316276.44 4036290.84 316275.82 4036290.75 316275.68 4036290.71 316275.54 4036290.69 316275.4 4036290.7 316275.27 4036290.73 316275.14 4036290.78 316275.02 4036290.85 316274.91 4036290.94 316274.82 4036291.04 316274.75 4036291.16 316274.7 4036291.29 316274.67 4036291.43 316274.53 4036292.89 316274.17 4036295.14 316273.99 4036296.28 316273.57 4036296.65 316273.33 4036296.78 316273.08 4036296.86 316272.82 4036296.89 316272.55 4036296.87 316272.3 4036296.79 316272.06 4036296.66 316271.86 4036296.48 316271.7 4036296.27 316271.59 4036296.03 316271.52 4036295.77 316271.52 4036295.51 316271.71 4036295.14 316271.95 4036294.7 316272.5 4036294.22 316272.9 4036293.61 316273.08 4036293.13 316273.12 4036292.96 316273.15 4036292.79 316273.14 4036292.62 316273.11 4036292.46 316273.05 4036292.3 316272.96 4036292.15 316272.85 4036292.02 316272.72 4036291.91 316272.58 4036291.82 316272.42 4036291.75 316272.26 4036291.72 316271.66 4036291.75 316271.15 4036292.07 316270.62 4036292.79 316269.15 4036294.54 316268.48 4036295.14</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6368301UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316225.1355 4036676.1665</gml:lowerCorner>
         <gml:upperCorner>316239.0955 4036696.3765</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2018-11-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6368301UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6368301UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6368301UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6368301UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="30"> 316225.14 4036688.4 316227.2 4036695.65 316227.35 4036695.74 316228.4 4036696.38 316230.64 4036695.74 316235.68 4036694.3 316235.73 4036694.13 316233.9 4036688.38 316231.97 4036688.78 316231.91 4036688.73 316232.24 4036688.18 316233.33 4036686.27 316233.92 4036685.26 316234.57 4036687.11 316237.66 4036686.24 316236.18 4036681.02 316237.89 4036677.89 316239.1 4036677.55 316238.76 4036676.17 316237.36 4036676.6 316237.68 4036677.72 316235.79 4036681.08 316230.66 4036682.6 316231.62 4036685.67 316233.64 4036685.14 316231.71 4036688.57 316231.61 4036688.43 316231.16 4036686.86 316231 4036686.79 316225.14 4036688.4</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6368301UF1366N_PI.2">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316174.085 4036648.4575</gml:lowerCorner>
         <gml:upperCorner>316188.0245 4036668.707</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2018-11-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6368301UF1366N_PI.2</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6368301UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6368301UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6368301UF1366N_PI.2" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="28"> 316174.09 4036660.72 316176.17 4036667.97 316177.37 4036668.71 316184.65 4036666.61 316184.7 4036666.44 316182.85 4036660.68 316180.92 4036661.08 316180.87 4036661.03 316181.19 4036660.48 316182.28 4036658.57 316182.87 4036657.56 316183.51 4036659.41 316186.61 4036658.54 316185.11 4036653.32 316186.81 4036650.18 316188.02 4036649.84 316187.68 4036648.46 316186.28 4036648.9 316186.6 4036650.01 316184.72 4036653.38 316179.59 4036654.9 316180.56 4036657.97 316182.59 4036657.44 316180.66 4036660.87 316180.57 4036660.73 316180.11 4036659.16 316179.95 4036659.1 316174.09 4036660.72</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6368301UF1366N_PI.3">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316293.3335 4036560.6265</gml:lowerCorner>
         <gml:upperCorner>316305.9835 4036575.7265</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2018-11-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6368301UF1366N_PI.3</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6368301UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6368301UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6368301UF1366N_PI.3" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="23"> 316303.96 4036573.72 316302.28 4036567.8 316300.44 4036568.29 316300.25 4036568.16 316302.13 4036564.84 316302.27 4036564.94 316302.79 4036566.83 316305.98 4036565.87 316304.6 4036561.04 316304.23 4036560.76 316303.85 4036560.63 316303.42 4036560.66 316299.04 4036561.92 316299.87 4036565.13 316301.66 4036564.73 316301.75 4036564.83 316299.9 4036568.1 316299.83 4036568.03 316299.43 4036566.2 316293.33 4036568.07 316295.34 4036574.91 316296.97 4036575.73 316303.96 4036573.72</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6368301UF1366N_PI.4">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316207.804 4036586.6275</gml:lowerCorner>
         <gml:upperCorner>316221.7635 4036606.8575</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2018-11-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6368301UF1366N_PI.4</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6368301UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6368301UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6368301UF1366N_PI.4" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="30"> 316219.93 4036595.34 316218.85 4036591.49 316220.55 4036588.36 316221.76 4036588.02 316221.42 4036586.63 316220.02 4036587.07 316220.34 4036588.18 316218.45 4036591.55 316213.32 4036593.07 316214.03 4036595.34 316214.28 4036596.14 316216.3 4036595.61 316214.37 4036599.04 316214.28 4036598.9 316213.83 4036597.33 316213.66 4036597.26 316207.8 4036598.87 316209.86 4036606.12 316211.07 4036606.86 316218.35 4036604.77 316218.4 4036604.6 316216.57 4036598.85 316214.64 4036599.25 316214.58 4036599.2 316214.9 4036598.65 316216 4036596.74 316216.58 4036595.73 316217.23 4036597.58 316220.32 4036596.71 316219.93 4036595.34</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6368301UF1366N_PI.5">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316259.0045 4036614.8165</gml:lowerCorner>
         <gml:upperCorner>316273.0945 4036634.8965</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2018-11-27T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6368301UF1366N_PI.5</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6368301UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6368301UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6368301UF1366N_PI.5" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="28"> 316259 4036626.88 316260.96 4036634.15 316262.16 4036634.9 316269.46 4036632.91 316269.52 4036632.74 316267.76 4036626.97 316265.82 4036627.34 316265.77 4036627.29 316266.1 4036626.75 316267.22 4036624.85 316267.82 4036623.85 316268.44 4036625.71 316271.54 4036624.88 316270.13 4036619.64 316271.88 4036616.53 316273.09 4036616.2 316272.77 4036614.82 316271.37 4036615.24 316271.67 4036616.35 316269.74 4036619.69 316264.59 4036621.15 316265.51 4036624.23 316267.54 4036623.73 316265.56 4036627.13 316265.47 4036626.99 316265.04 4036625.41 316264.87 4036625.35 316259 4036626.88</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6465552UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316374.6595 4036329.0075</gml:lowerCorner>
         <gml:upperCorner>316380.6795 4036335.0375</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2009-08-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465552UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465552UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465552UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6465552UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="33"> 316377.67 4036335.04 316378.27 4036334.98 316378.84 4036334.8 316379.37 4036334.51 316379.83 4036334.12 316380.21 4036333.65 316380.48 4036333.11 316380.64 4036332.53 316380.68 4036331.93 316380.6 4036331.33 316380.41 4036330.77 316380.1 4036330.25 316379.7 4036329.8 316379.22 4036329.44 316378.67 4036329.18 316378.09 4036329.04 316377.49 4036329.01 316376.89 4036329.11 316376.33 4036329.32 316375.82 4036329.64 316375.38 4036330.06 316375.04 4036330.55 316374.8 4036331.1 316374.67 4036331.69 316374.66 4036332.29 316374.78 4036332.88 316375.01 4036333.44 316375.34 4036333.94 316375.77 4036334.37 316376.27 4036334.7 316376.83 4036334.92 316377.42 4036335.03 316377.67 4036335.04</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6465801UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316343.499 4036300.838</gml:lowerCorner>
         <gml:upperCorner>316370.549 4036324.8875</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2009-08-13T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6465801UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6465801UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6465801UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6465801UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 316370.55 4036315.55 316350.52 4036300.84 316343.5 4036310.43 316363.57 4036324.89 316370.55 4036315.55</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6467601UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316351.1255 4036555.863</gml:lowerCorner>
         <gml:upperCorner>316360.3805 4036563.1055</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6467601UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6467601UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6467601UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6467601UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 316352.85 4036555.86 316351.13 4036559.87 316358.66 4036563.11 316360.38 4036559.1 316352.85 4036555.86</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6468408UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316300.615 4036643.666</gml:lowerCorner>
         <gml:upperCorner>316311.815 4036657.0655</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6468408UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6468408UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6468408UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6468408UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 316305.93 4036657.07 316311.82 4036646.69 316306.52 4036643.67 316300.62 4036654.18 316305.93 4036657.07</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6468409UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316321.84 4036617.79</gml:lowerCorner>
         <gml:upperCorner>316326.8 4036625.67</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-06-01T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6468409UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6468409UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6468409UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6468409UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="16"> 316323 4036617.85 316322.3 4036618.2 316321.84 4036619.35 316322.94 4036622 316322.71 4036623.11 316322.65 4036624.45 316323.53 4036625.38 316324.23 4036625.67 316324.87 4036625.56 316326.1 4036624.51 316326.8 4036622.81 316326.8 4036621 316326.16 4036619.14 316324.93 4036618.26 316323.82 4036617.79 316323 4036617.85</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6468410UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316336.7845 4036594.246</gml:lowerCorner>
         <gml:upperCorner>316342.3045 4036603.0255</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2007-03-12T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6468410UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6468410UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6468410UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6468410UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="41"> 316337.3 4036597.36 316337.83 4036597.93 316338.05 4036598.4 316338.15 4036598.92 316338.12 4036599.44 316337.7 4036600.58 316337.65 4036600.92 316337.72 4036601.6 316337.84 4036601.92 316338.02 4036602.22 316338.23 4036602.49 316338.49 4036602.71 316339.11 4036603.03 316339.72 4036602.99 316340.58 4036602.68 316341.07 4036602.31 316341.46 4036601.83 316342.01 4036600.66 316342.2 4036600 316342.3 4036599.32 316342.3 4036598.63 316342.2 4036597.95 316342.01 4036597.29 316341.72 4036596.66 316341.35 4036596.08 316340.91 4036595.56 316340.39 4036595.11 316339.49 4036594.5 316339.13 4036594.33 316338.74 4036594.25 316338.34 4036594.25 316337.96 4036594.34 316337.6 4036594.51 316337.29 4036594.76 316337.04 4036595.08 316336.87 4036595.43 316336.78 4036595.82 316336.78 4036596.22 316336.86 4036596.61 316337.03 4036596.98 316337.3 4036597.36</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6468414UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316318.0955 4036660.7955</gml:lowerCorner>
         <gml:upperCorner>316326.5655 4036667.5655</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2004-06-24T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6468414UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6468414UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6468414UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6468414UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 316318.1 4036663.96 316324.77 4036667.57 316326.57 4036664.44 316319.83 4036660.8 316318.1 4036663.96</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6468601UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316380.866 4036662.9765</gml:lowerCorner>
         <gml:upperCorner>316385.062 4036669.1</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2022-04-07T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6468601UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6468601UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6468601UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6468601UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5"> 316381.98 4036669.1 316385.06 4036668.48 316383.95 4036662.98 316380.87 4036663.6 316381.98 4036669.1</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6468605UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316340.46 4036622.9</gml:lowerCorner>
         <gml:upperCorner>316348.99 4036632.16</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-06-01T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6468605UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6468605UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6468605UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6468605UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="11"> 316344.47 4036622.9 316340.46 4036626.03 316345.25 4036632.16 316346.3 4036631.28 316346.83 4036631.92 316347.59 4036631.86 316348.29 4036631.34 316348.46 4036630.52 316348.16 4036629.72 316348.99 4036629.12 316344.47 4036622.9</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6468606UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316348.8085 4036648.781</gml:lowerCorner>
         <gml:upperCorner>316356.874 4036655.1255</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2019-11-29T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6468606UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6468606UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6468606UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6468606UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="10"> 316356.05 4036654.9 316356.87 4036653.54 316356.84 4036653.05 316356.65 4036652.62 316350.28 4036648.78 316348.81 4036651.23 316355.07 4036655.01 316355.46 4036655.13 316355.85 4036655.04 316356.05 4036654.9</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6568210UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316401.17 4036671.62</gml:lowerCorner>
         <gml:upperCorner>316409.03 4036677.71</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-06-01T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6568210UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6568210UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6568210UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6568210UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="14"> 316401.37 4036675.97 316402.24 4036677.1 316403.42 4036677.56 316405.11 4036677.71 316406.34 4036677.41 316407.41 4036676.89 316407.57 4036676.59 316409.03 4036676.46 316408.84 4036671.62 316407.57 4036671.67 316403.98 4036672.85 316401.61 4036673.26 316401.17 4036674.44 316401.37 4036675.97</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
  <gml:featureMember>
    <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.6568215UF1366N_PI.1">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>316397.58 4036526.47</gml:lowerCorner>
         <gml:upperCorner>316406.3 4036543.4</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion>2015-06-01T00:00:00</bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>6568215UF1366N_PI.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-core2d:addresses xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsAD.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetadByRefcat&amp;refcat=6568215UF1366N&amp;srsname=EPSG::25830"></bu-core2d:addresses>
      <bu-core2d:cadastralParcels xlink:href="http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?service=wfs&amp;version=2&amp;request=GetFeature&amp;STOREDQUERIE_ID=GetParcel&amp;refcat=6568215UF1366N&amp;srsname=EPSG::25830"></bu-core2d:cadastralParcels>
      <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature>
      <bu-ext2d:geometry>
            <gml:Polygon gml:id="Polygon_ES.SDGC.BU.6568215UF1366N_PI.1" srsName="urn:ogc:def:crs:EPSG::25830">
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="20"> 316402.85 4036543.4 316406.3 4036529.22 316405.65 4036529.04 316405.72 4036528.59 316405.7 4036528.13 316405.57 4036527.7 316405.35 4036527.3 316405.04 4036526.96 316404.67 4036526.71 316404.24 4036526.54 316403.79 4036526.47 316403.34 4036526.51 316402.91 4036526.65 316402.52 4036526.88 316402.19 4036527.2 316401.94 4036527.58 316401.79 4036528.01 316401.02 4036527.81 316397.58 4036541.84 316402.85 4036543.4</gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
              </gml:Polygon>
      </bu-ext2d:geometry>
    </bu-ext2d:OtherConstruction>
  </gml:featureMember>
</gml:FeatureCollection>
